# AgenticHack

Signal-driven bug bounty agent framework for OpenCode. Web2 only. Low-hanging bugs welcome. Informational bugs rejected.

## Philosophy
- Router → Signal Table → Reference (lazy loading)
- Deterministic technique selection, not LLM whim
- Hard validation gate: no 7-question pass = no report
- Chain or kill: every Low/Medium finding must escalate or die

## Quick Start
1. Clone this repo to `~/agentichack`
2. Symlink: `ln -s ~/agentichack/skills ~/.config/opencode/skills/agentichack`
3. Run `opencode serve` and load `@orchestrator`
4. Provide `subdomains.txt` and `httpx_output.json` when prompted

## Skill Graph

```
@orchestrator (entry)
    ├── @methodology (discipline, 7 rules, target scoring)
    ├── @recon (5-stage pipeline: subdomains → HTTP → content → JS → API)
    ├── @web/ROUTER.md (signal table: 12 observable signals → technique)
    ├── @web/vuln-classes (26 Web2 bug classes with root cause, bypass, chains)
    ├── @arsenal (payloads, bypass tables, wordlists, gf patterns)
    ├── @validate (7-Question Gate + always-rejected + chain table)
    ├── @chaining (15 proven patterns A–O, escalation ladders, 30-min clock)
    ├── @report (H1/Bugcrowd/Intigriti/Immunefi templates, impact-first writing)
    └── @tooling (recon tools, browser MCP, Caido, WAF encoder, SQLMap tampers)
```

## Pipeline

```
Input (subdomains.txt + httpx_output.json)
    │
    ▼
Methodology ──► Create working folder, score target, log hypothesis
    │
    ▼
Recon ──► 5 stages → surface.json + hypothesis-log.md
    │
    ▼ (gate: recon_status: complete)
Router ──► Signal table maps observable → technique → reference
    │
    ▼
Vuln Classes ──► Root cause, bypass tables, exploit payloads, chains
    │
    ▼
Validate ──► 7-Question Gate (Q1=HTTP request, Q2=scope, Q3=in-scope, Q4=repro, Q5=dup, Q6=impact, Q7=evidence)
    │         Always-rejected list kill
    │         Chain table check
    │         CVSS vector
    │
    ▼ (if Low/Medium)
Chaining ──► 10-question filter → 15 patterns A–O → escalation ladder → prove chain end-to-end
    │
    ▼
Report ──► Impact-first templates, human tone, no "could potentially", pre-submit checklist
```

## Key References

| Skill | Key Files |
|-------|-----------|
| `recon` | `references/subdomain-deep.md`, `http-probe.md`, `content-discovery.md`, `js-analysis.md`, `api-surface.md` |
| `web/vuln-classes` | 26 references: `idor.md`, `broken-auth.md`, `xss.md`, `ssrf.md`, `business-logic.md`, `race-conditions.md`, `sqli.md`, `oauth.md`, `file-upload.md`, `graphql.md`, `llm-ai.md`, `api-misconfig.md`, `ato.md`, `ssti.md`, `subdomain-takeover.md`, `cloud-infra.md`, `http-smuggling.md`, `cache-poisoning.md`, `mfa-bypass.md`, `saml.md`, `error-disclosure.md`, `css-injection.md`, `lfi-rce.md`, `deserialization.md`, `dependency-confusion.md`, `padding-oracle.md` |
| `arsenal` | Payloads for XSS/SSRF/SQLi/XXE/NoSQLi/CMDi/SSTI/IDOR/Path-trav/Smuggling/WS/MFA; bypass tables; gf patterns; always-rejected; conditional-chain |
| `validate` | `seven-question-gate.md`, `always-rejected.md`, `chain-table.md`, `cvss-quickref.md`, `pre-submit-checklist.md` |
| `chaining` | 10-Q filter, 15 patterns A–O, conditional chain table, escalation ladders, payout tiers, 30-min clock |
| `report` | H1/Bugcrowd/Intigriti/Immunefi templates, title formula, severity guide, downgrade counters |
| `tooling` | `recon-tools.md`, `browser-mcp.md`, `sqlmap-tampers.md` |

## Hard Gates (Non-Negotiable)

1. **No recon → no Router** (`recon_status: complete` required)
2. **No Validate → no report** (7-Question Gate must pass)
3. **Always-rejected = kill** (no exceptions)
4. **Chain required = prove it** (end-to-end HTTP requests)
5. **5-minute rule** (no signal → move on)
6. **Impact first** (worst consequences tested first)

## Output Structure

```
targets/<target-name>/
├── scope.md
├── recon/
│   ├── subdomains.txt, live-hosts.txt, urls.txt, js-bundles.txt
│   ├── api-endpoints.txt, nuclei.txt, interesting-params.txt
│   └── surface.json
├── hypothesis-log.md
├── findings/
│   └── <bug-class>-<endpoint>/
│       ├── hackerone-report.md
│       ├── submission-notes.md
│       └── evidence/
└── session-notes.md
```

## License
MIT