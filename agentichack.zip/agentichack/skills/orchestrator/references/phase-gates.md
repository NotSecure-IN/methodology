# Phase Gates

| Gate | Condition | Blocked Until |
|---|---|---|
| G1 Recon done | `recon/` has `surface.json` + `session-notes.md` says `recon_status: complete` | Cannot load `web/ROUTER.md` |
| G2 Validation | Candidate finding exists | Cannot write report |
| G3 HITL | Destructive step about to run | Cannot proceed without Telegram Approve |
