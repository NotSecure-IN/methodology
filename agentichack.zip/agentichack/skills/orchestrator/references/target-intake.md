# Target Intake Format

## subdomains.txt
Plain text, one host per line. No scheme.

## httpx_output.json
Required fields per line (from `httpx -json -o httpx.json`):
- `input` — original host
- `url` — full URL
- `status_code`
- `title`
- `tech` — array of detected technologies
- `content_type`
- `webserver` — server header

If `tech` is empty, do not assume no framework. Mark `tech_unknown: true`
and let JS analysis fill the gap.
