---
name: orchestrator
description: >
  AgenticHack entry point. Load when the user provides a target (VDP URL or domain)
  and asks to start a hunt. Routes to methodology first, then recon for surface
  mapping, then web/ROUTER.md for technique selection, then web/vuln-classes for
  exploit details. Never allows exploitation before recon is complete.
license: MIT
compatibility: opencode>=1.5.0
metadata:
  framework: agentichack
  version: "1.0.0"
  tags: "agentichack,orchestrator,routing"
  allowed-tools: "read,bash,skill"
---

# AgenticHack Orchestrator

## Input Contract

User provides target in one of these formats:
```
https://www.notsecure.in/vdp
https://target.com
target.com
```

Agent parses this to extract root domain, fetches program page, and populates scope.
If input is ambiguous, ask once for clarification. Do not start without parsed scope.

## Mandatory Sequence

1. Load `methodology/SKILL.md` + `references/workflow.md` — create working folder, parse input, populate `scope.md` and `scope.sqlite`.
2. Load `recon/SKILL.md` — execute full 6-stage recon pipeline, populate `scope.sqlite` at each stage.
3. Only after `recon_status: complete` in `session-notes.md`, load `web/ROUTER.md`.
4. For each signal from Router, load `web/vuln-classes/references/<class>.md` for exploit details.
5. For each candidate finding, load `validate/SKILL.md` before writing anything.
6. If finding is Low/Medium, load `chaining/SKILL.md` to escalate before reporting.
7. Load `report/SKILL.md` to write submission.
8. Use `tooling/references/telegram-mcp.md` for milestone notifications.

## Hard Gates

- If `recon_status: complete` is not written in `session-notes.md`, **do not load `web/ROUTER.md`**.
- If `validate` 7-Question Gate fails, **kill the finding immediately**.
- If finding is on `always-rejected` list without a proven chain, **kill it**.
- Never write a report before `validate` and `chaining` (if needed) pass.
- **SQLite database must be populated** at each recon stage before proceeding.