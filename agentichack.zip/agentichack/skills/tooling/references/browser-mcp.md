# Browser MCP

## Runtime
Arthur Runtime (no Docker):

```bash
uvx arthur-runtime mcp --transport streamable-http --host 0.0.0.0 --port 8000
```

Or Obscura (native binary, no Chrome).

## URL Allowlist
**Before any navigation**, verify target host is in `scope.md`.
If out of scope → **do not navigate**. No exceptions.

## Capabilities
- Full headless Chromium control
- DOM inspection and manipulation
- Network interception (request/response)
- Console logs and JavaScript errors
- Screenshots and PDF generation
- Authentication handling (cookies, localStorage, sessionStorage)
- Shadow DOM / iframe traversal

## Common Use Cases

### DOM XSS Confirmation
```python
# Navigate to page with reflected input
# Inject payload in URL param
# Check if payload executes in page context
# Screenshot console showing alert(1) or fetch() to collaborator
```

### Blind XSS / Stored XSS Verification
```python
# Submit payload in form (profile, ticket, comment)
# Navigate to admin/view page where payload renders
# Confirm execution via callback to collaborator
```

### OAuth Flow Testing
```python
# Automate OAuth authorization flow
# Capture redirect_uri with auth code
# Test open redirect chains in OAuth context
```

### CSP Bypass Verification
```python
# Check CSP headers via network interception
# Test nonce reflection
# Verify CSP allows attacker-controlled script execution
```

### PostMessage Testing
```python
# Load target page in iframe
# Send postMessage from parent
# Monitor for DOM mutations / XSS execution
```

## Rate Limits
- Max 5 concurrent browser sessions
- 30s timeout per navigation
- Respect target's rate limits (add delays)

## Evidence Collection
Always save:
- Screenshot of vulnerability trigger
- Network log (HAR) showing request/response
- Console output showing execution
- Video recording for complex chains