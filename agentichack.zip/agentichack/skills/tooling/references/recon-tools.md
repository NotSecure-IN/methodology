# Recon Tools Reference

| Tool | Command | When |
|---|---|---|
| subfinder | `subfinder -d <domain> -silent` | Passive subdomain enum |
| subdominator | `subdominator -d <domain> -silent` | Fast passive subdomain enum (Rust) |
| assetfinder | `assetfinder --subs-only <domain>` | Passive subdomain enum |
| chaos | `curl -H "Authorization: \$CHAOS_API_KEY" "https://dns.projectdiscovery.io/dns/<domain>/subdomains"` | Chaos API subdomain enum |
| dnsx | `dnsx -l subdomains.txt -silent -a -cname` | Resolve + CNAME |
| httpx | `httpx -l subdomains.txt -json -o httpx.json -status-code -title -tech-detect -content-type -web-server -location` | Live host probe |
| katana | `katana -list live.txt -jc -d 3` | Crawl + JS collect |
| gau | `gau <domain> --subs` | Historical URLs |
| gauplus | `gauplus -d <domain> -subs` | More historical sources |
| waybackurls | `echo <domain> \| waybackurls` | Wayback Machine URLs |
| arjun | `arjun -i urls.txt -oJ params.json` | Parameter mining |
| nuclei | `nuclei -l live.txt -tags cve,exposure,misconfig -severity critical,high,medium` | Known CVE scan |
| ffuf | `ffuf -u https://target.com/FUZZ -w wordlist.txt -mc 200,201,204,301,302,307,401,403 -t 40` | Directory fuzzing |
| naabu | `naabu -l live.txt -port 80,443,8080,8443,3000,8000,8888,9000,9200,6379` | Port scanning |
| dalfox | `dalfox url https://target.com/search?q=FUZZ --waf-evasion` | XSS scanning |
| sqlmap | `sqlmap -u "https://target.com/page?id=1" --batch --level=3` | SQLi exploitation |
| trufflehog | `trufflehog filesystem --only-verified ./recon/` | Verified secret scanning |
| git-dumper | `git-dumper https://target.com/.git/ ./dump` | Exposed .git extraction |
| ds_store_exp | `python3 ds_store_exp.py https://target.com/.DS_Store` | .DS_Store recursion |
| LinkFinder | `python3 linkfinder.py -i https://target.com -d` | Endpoints in JS |
| SecretFinder | `python3 SecretFinder.py -i https://target.com/app.js` | Secrets in JS |
| interactsh-client | `interactsh-client -oob-server oob.example.com` | OOB listener for blind vulns |

---

## API Keys (Set in ~/.zshrc / ~/.bashrc)

```bash
export CHAOS_API_KEY="your-key"           # chaos.projectdiscovery.io
export VT_API_KEY="your-key"              # virustotal.com
export CENSYS_API_ID="your-id"            # censys.io
export CENSYS_API_SECRET="your-secret"    # censys.io
export SHODAN_API_KEY="your-key"          # shodan.io
export SECURITYTRAILS_KEY="your-key"      # securitytrails.com
```

---

## Wordlists (in ~/wordlists/)

```
common.txt         # Common directories and files
params.txt         # Parameter names (id, user_id, file, etc.)
api-endpoints.txt  # API endpoint paths (/api/v1/users, etc.)
dirs.txt           # Directory names
sensitive.txt      # Sensitive paths (.env, config.json, backup, etc.)
```

---

## GF Patterns (tomnomnom/gf)

```bash
gf xss          # XSS parameters
gf ssrf         # SSRF parameters
gf idor         # IDOR parameters
gf sqli         # SQL injection parameters
gf redirect     # Open redirect parameters
gf lfi          # Local file inclusion
gf rce          # Remote code execution parameters
gf ssti         # Template injection parameters
gf debug_logic  # Debug/logic parameters
gf secrets      # Secret/token patterns
gf upload-fields # File upload parameters
gf cors         # CORS-related parameters
```