# Caido Proxy Integration (Headless)

> All HTTP traffic routes through Caido for request/response analysis, collaboration, and replay.

---

## Installation & Setup

### Install Caido CLI
```bash
# Linux
curl -fsSL https://caido.io/cli/install.sh | sh

# Or download binary
wget https://github.com/caido/caido/releases/latest/download/caido-cli-linux-x64 -O caido-cli
chmod +x caido-cli
sudo mv caido-cli /usr/local/bin/
```

### Verify Installation
```bash
caido-cli --version
```

---

## Headless Configuration

### Start Caido Headless (Background Service)
```bash
# Start Caido in headless mode on port 8080
caido-cli serve --headless --port 8080 --host 0.0.0.0 &

# Or with explicit config
caido-cli serve --headless \
  --port 8080 \
  --host 0.0.0.0 \
  --project-path "targets/$TARGET/caido-project" \
  --log-level info \
  --allow-insecure &

CAIDO_PID=$!
echo "Caido started on PID: $CAIDO_PID"

# Wait for ready
sleep 5
curl -s http://localhost:8080/health || echo "Waiting for Caido..."
```

### Environment Variables
```bash
export CAIDO_HOST="localhost"
export CAIDO_PORT="8080"
export CAIDO_PROXY="http://localhost:8080"
export CAIDO_API_KEY=""  # If auth enabled
```

---

## Proxy Configuration for All Tools

### httpx (via Caido)
```bash
# Route all httpx traffic through Caido
cat recon/resolved.txt | httpx -silent \
  -proxy "http://localhost:8080" \
  -status-code -title -tech-detect -cdn -follow-redirects \
  -ports 80,443,8080,8443,3000,5000,8000,8008,8088,8888 \
  -threads 200 -timeout 10 -retries 2 \
  -o recon/httpx_live.txt
```

### nuclei (via Caido)
```bash
nuclei -l recon/resolved.txt \
  -proxy "http://localhost:8080" \
  -t ~/nuclei-templates/takeovers/ \
  -t ~/nuclei-templates/cves/ \
  -t ~/nuclei-templates/misconfigurations/ \
  -severity critical,high,medium \
  -rate-limit 150 -retries 2 -timeout 10 \
  -o recon/nuclei.txt
```

### katana (via Caido)
```bash
# Katana crawl through Caido
cat recon/httpx_urls.txt | katana -silent \
  -proxy "http://localhost:8080" \
  -d 3 -jc -kf all \
  -o recon/urls.txt
```

### gau / waybackurls (via Caido)
```bash
# Historical URLs through Caido
gau "$TARGET" --subs --proxy "http://localhost:8080" | anew recon/urls.txt
echo "$TARGET" | waybackurls | anew recon/urls.txt
```

### subfinder / puredns / dnsx (Direct - No Proxy Needed)
```bash
# DNS tools don't need HTTP proxy
subfinder -d "$TARGET" -silent | anew recon/subdomains.txt
puredns resolve recon/subdomains.txt -r resolvers_fresh.txt -w recon/resolved.txt --rate-limit 2000
dnsx -l recon/resolved.txt -cname -resp -threads 200 -o recon/cname_detailed.txt
```

### curl / Manual Requests (via Caido)
```bash
# All manual curl through Caido
curl -x "http://localhost:8080" -s -k -L "https://target.com"

# With headers preserved
curl -x "http://localhost:8080" -H "User-Agent: Mozilla/5.0" -s -k -L "https://target.com/api"
```

### ffuf (via Caido)
```bash
ffuf -u "https://target.com/FUZZ" -w wordlist.txt \
  -x "http://localhost:8080" \
  -mc 200,201,204,301,302,307,401,403 \
  -t 40 -ac
```

### sqlmap (via Caido)
```bash
sqlmap -u "https://target.com/page?id=1" \
  --proxy "http://localhost:8080" \
  --batch --level=3 --risk=2
```

### interactsh-client (via Caido for callbacks)
```bash
# OOB callbacks through Caido
interactsh-client -proxy "http://localhost:8080" -o canary.log
```

---

## Caido API for Request/Response Analysis

### Get All Requests
```bash
# Fetch all captured requests
curl -s "http://localhost:8080/api/v1/requests" | jq '.requests[] | {id, method, url, status_code, timestamp}'

# Filter by target domain
curl -s "http://localhost:8080/api/v1/requests" | jq '.requests[] | select(.url | contains("notsecure.in"))'
```

### Get Request Details
```bash
# Get full request/response by ID
REQUEST_ID="req_abc123"
curl -s "http://localhost:8080/api/v1/requests/$REQUEST_ID" | jq '{request: .request, response: .response}'

# Extract headers
curl -s "http://localhost:8080/api/v1/requests/$REQUEST_ID" | jq '.request.headers, .response.headers'
```

### Search Requests
```bash
# Search for specific patterns
curl -s "http://localhost:8080/api/v1/requests/search?q=secret" | jq '.requests[] | {url, method}'

# Find requests with specific status codes
curl -s "http://localhost:8080/api/v1/requests" | jq '.requests[] | select(.status_code == 403 or .status_code == 401)'
```

### Export for Analysis
```bash
# Export all requests as HAR
curl -s "http://localhost:8080/api/v1/export/har" > "targets/$TARGET/caido-export.har"

# Export as CSV
curl -s "http://localhost:8080/api/v1/export/csv" > "targets/$TARGET/caido-export.csv"
```

---

## Project Management

### Create Project per Target
```bash
# Create isolated project for each target
caido-cli project create --name "$TARGET" --path "targets/$TARGET/caido-project"

# List projects
caido-cli project list

# Switch project
caido-cli project switch --name "$TARGET"
```

### Project Structure
```
targets/notsecure.in/
├── caido-project/
│   ├── project.json
│   ├── requests.db          # SQLite with all requests
│   ├── responses.db
│   ├── scopes.json          # In-scope patterns
│   └── filters.json         # Custom filters
```

---

## Scope Configuration in Caido

### Define In-Scope Patterns
```bash
# Create scope file
cat > "targets/$TARGET/caido-scope.json" << 'EOF'
{
  "in_scope": [
    "*.notsecure.in",
    "*.notsec.in",
    "*.notsecure.com"
  ],
  "out_of_scope": [
    "dev.notsecure.in"
  ]
}
EOF

# Import into Caido
caido-cli scope import --file "targets/$TARGET/caido-scope.json" --project "$TARGET"
```

---

## Advanced Analysis Workflows

### 1. Find All 403/401 Endpoints for Bypass Testing
```bash
curl -s "http://localhost:8080/api/v1/requests" | \
  jq -r '.requests[] | select(.status_code == 403 or .status_code == 401) | "\(.method) \(.url)"' | \
  sort -u > "targets/$TARGET/bypass_candidates.txt"
```

### 2. Extract All API Endpoints
```bash
curl -s "http://localhost:8080/api/v1/requests" | \
  jq -r '.requests[] | select(.url | contains("/api/") or contains("/v1/") or contains("/graphql")) | "\(.method) \(.url)"' | \
  sort -u > "targets/$TARGET/api_endpoints.txt"
```

### 3. Find Parameter Injection Points
```bash
curl -s "http://localhost:8080/api/v1/requests" | \
  jq -r '.requests[] | select(.url | contains("?")) | .url' | \
  grep -oE '[?&][^=]+=' | sort -u > "targets/$TARGET/parameters.txt"
```

### 4. Detect JavaScript Files
```bash
curl -s "http://localhost:8080/api/v1/requests" | \
  jq -r '.requests[] | select(.url | endswith(".js")) | .url' | \
  sort -u > "targets/$TARGET/js_files.txt"
```

### 5. Find Potential Takeover Targets
```bash
curl -s "http://localhost:8080/api/v1/requests" | \
  jq -r '.requests[] | select(.response.body | test("NoSuchBucket|No such app|Repository not found|DEPLOYMENT_NOT_FOUND")) | "\(.url) -> \(.response.body[0:100])"' > "targets/$TARGET/takeover_hits.txt"
```

### 6. Extract Secrets from Responses
```bash
curl -s "http://localhost:8080/api/v1/requests" | \
  jq -r '.requests[] | .response.body' | \
  grep -oE '(api_key|apiKey|secret|token|password|aws_access_key|aws_secret)[\"']?\s*[:=]\s*[\"']?[a-zA-Z0-9_\-]{20,}' | \
  sort -u > "targets/$TARGET/secrets_found.txt"
```

---

## Automation: Run All Analysis

```bash
#!/bin/bash
# caido-analysis.sh - Run after recon completes
TARGET="notsecure.in"
CAIDO_API="http://localhost:8080/api/v1"

mkdir -p "targets/$TARGET/analysis"

echo "[+] Fetching all requests from Caido..."
curl -s "$CAIDO_API/requests" > "targets/$TARGET/analysis/all_requests.json"

echo "[+] Analyzing..."
# 403/401 bypass targets
jq -r '.requests[] | select(.status_code == 403 or .status_code == 401) | "\(.method) \(.url) [\(.status_code)]"' "targets/$TARGET/analysis/all_requests.json" | sort -u > "targets/$TARGET/analysis/bypass_targets.txt"

# API endpoints
jq -r '.requests[] | select(.url | contains("/api/") or contains("/v1/") or contains("/graphql")) | "\(.method) \(.url)"' "targets/$TARGET/analysis/all_requests.json" | sort -u > "targets/$TARGET/analysis/api_endpoints.txt"

# Parameters
jq -r '.requests[] | select(.url | contains("?")) | .url' "targets/$TARGET/analysis/all_requests.json" | grep -oE '[?&][^=]+=' | sort -u > "targets/$TARGET/analysis/parameters.txt"

# JS files
jq -r '.requests[] | select(.url | endswith(".js")) | .url' "targets/$TARGET/analysis/all_requests.json" | sort -u > "targets/$TARGET/analysis/js_files.txt"

# Takeover indicators
jq -r '.requests[] | select(.response.body | test("NoSuchBucket|No such app|Repository not found|DEPLOYMENT_NOT_FOUND|The app you are looking for")) | "\(.url) | \(.response.body[0:200])"' "targets/$TARGET/analysis/all_requests.json" > "targets/$TARGET/analysis/takeover_indicators.txt"

# Secrets
jq -r '.requests[] | .response.body' "targets/$TARGET/analysis/all_requests.json" | grep -oE '(api_key|apiKey|secret|token|password|aws_access_key|aws_secret)[\"']?\s*[:=]\s*[\"']?[a-zA-Z0-9_\-]{20,}' | sort -u > "targets/$TARGET/analysis/secrets.txt"

echo "[+] Analysis complete. Files in targets/$TARGET/analysis/"
ls -la "targets/$TARGET/analysis/"
```

---

## Cleanup

```bash
# Stop Caido
kill $CAIDO_PID 2>/dev/null

# Or gracefully
caido-cli shutdown

# Archive project
tar -czf "targets/$TARGET/caido-project-$(date +%s).tar.gz" "targets/$TARGET/caido-project/"
```

---

## Integration with Recon Pipeline

### In recon/subdomain-deep.md (Stage 3 - HTTP Probe)
Add Caido proxy to httpx command:
```bash
cat recon/resolved.txt | httpx -silent \
  -proxy "http://localhost:8080" \
  -status-code -title -tech-detect -cdn -follow-redirects \
  -ports 80,443,8080,8443,3000,5000,8000,8008,8088,8888 \
  -threads 200 -timeout 10 -retries 2 \
  -o recon/httpx_live.txt
```

### In recon/content-discovery.md
Add Caido proxy to katana, gau:
```bash
katana -list recon/httpx_urls.txt -proxy "http://localhost:8080" -d 3 -jc -kf all -silent -o recon/urls.txt
gau "$TARGET" --subs --proxy "http://localhost:8080" | anew recon/urls.txt
```

### In validation/hunting
All manual curl, ffuf, sqlmap, nuclei through Caido proxy.

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Caido not starting | Check port 8080 free: `lsof -i :8080` |
| Requests not showing | Verify proxy env: `echo $HTTP_PROXY` |
| SSL errors | Use `-k` flag or import Caido CA cert |
| High memory | Limit project scope, restart periodically |
| API not responding | Check `caido-cli serve --headless` logs |

---

## Security Notes

- Caido runs locally — no external data exfiltration
- Project isolation per target prevents cross-contamination
- All request/response data stays in `targets/<target>/caido-project/`
- Use `--allow-insecure` only for testing targets with invalid certs