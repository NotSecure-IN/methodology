---
name: tooling
description: >
  Tool and MCP integration reference. Load when the agent needs to call a
  CLI tool, browser MCP, Caido, or Telegram. No script files — only correct
  commands and when to use them.
license: MIT
compatibility: opencode>=1.5.0
metadata:
  framework: agentichack
  version: "1.0.0"
  tags: "agentichack,tooling,mcp"
  allowed-tools: "read,bash"
---

# Tooling

| Need | Reference |
|---|---|
| CLI recon tools | `references/recon-tools.md` |
| Browser automation | `references/browser-mcp.md` |
| Caido proxy | `references/caido-integration.md` |
| Telegram notify / HITL | `references/telegram-mcp.md` |
| WAF encoder | `bughunter/tools/waf_encoder.py` |
| Multipart mutator | `bughunter/tools/multipart_mutator.py` |
| Bypass 403 | `bughunter/tools/bypass_403.sh` |
| SQLMap tamper scripts | `references/sqlmap-tampers.md` |