---
name: methodology
description: >
  AgenticHack discipline layer. Load immediately after orchestrator and
  before any recon or exploitation. Enforces working-folder structure,
  hypothesis logging, the "map wide → hypothesize wide → confirm strict"
  loop, target scoring, 5-minute rule, and the 7 Rules.
license: MIT
compatibility: opencode>=1.5.0
metadata:
  framework: agentichack
  version: "1.0.0"
  tags: "agentichack,methodology,workflow"
  allowed-tools: "read,bash"
---

# Methodology

Read `references/workflow.md` first. Create the working folder before
sending any request. Never skip the hypothesis log.

---

## The 7 Rules (Run Every Session, No Exceptions)

| # | Rule | Why |
|---|---|---|
| 1 | **Read full scope first** | Only test what the program authorizes |
| 2 | **Real bugs only** | "Can an attacker do this RIGHT NOW?" — if no, stop |
| 3 | **Kill weak findings** | A 30-second check saves hours of wasted reporting |
| 4 | **Never go out of scope** | One wrong request can get you banned |
| 5 | **5-minute rule** | No progress after 5 minutes? Move on |
| 6 | **Validate before report** | `/validate` before spending 30 minutes writing |
| 7 | **Impact first** | Test the bugs with the worst consequences first |

---

## Target Scoring — GO / NO-GO

Score before spending time. Skip if score < 4.

| Criterion | Points |
|---|---|
| Max bounty >= $5K | +2 |
| Large user base (>100K) or handles money | +2 |
| Program launched < 60 days ago | +2 |
| Complex features: API, OAuth, file upload, GraphQL | +1 |
| Recent code/feature changes (GitHub, changelog) | +1 |
| Private program (less competition) | +1 |
| Tech stack you know | +1 |
| Source code available | +1 |
| Prior disclosed reports to study | +1 |

**< 4:** Skip
**4-5:** Only if nothing better available
**6-8:** Good — spend 1-3 days
**>= 9:** Excellent — spend up to 1 week

### Pre-Dive Hard Kill Signals
1. Max bounty < $500 → not worth your time
2. All recent reports are N/A or duplicate → hunters saturated it
3. Scope is only a static marketing page → no attack surface
4. Company < 5 employees with no revenue → won't pay
5. Explicitly excludes your planned bug class in rules

---

## The Loop

1. **Map wide** — collect every observable signal (tech, headers, endpoints, JS).
2. **Hypothesize wide** — from signals, list plausible vulnerability classes.
3. **Confirm strict** — only proceed to a reference if the one-line test is defined.

## Anti-Patterns
- Jumping to exploitation before recon is complete.
- Testing a technique because it is "popular" without a signal.
- Writing a report before validation gate passes.
- Burning hours on a target that scored < 4.