# Per-Target Workflow

## Input Format

User provides target in one of these formats:
```
https://www.notsecure.in/vdp
https://target.com
target.com
```

The agent parses this to extract:
- **Root domain**: `notsecure.in`
- **Program name**: `NotSecure-IN` (from VDP URL or GitHub org)
- **Scope**: in-scope, out-of-scope, GitHub org from program page

## Create Before Any Request

```
targets/<target-name>/
├── scope.md                    # parsed in-scope, out-of-scope, github, notes
├── scope.sqlite                # SQLite database with all gathered data
├── recon/
│   ├── subdomains.txt          # all discovered subdomains
│   ├── resolved.txt            # DNS-resolved subdomains
│   ├── cname_detailed.txt      # CNAME chains
│   ├── httpx_live.txt          # live HTTP services
│   ├── httpx_urls.txt          # extracted URLs
│   ├── urls.txt                # all discovered URLs (crawl + historical)
│   ├── js-bundles.txt          # JavaScript files
│   ├── api-endpoints.txt       # API endpoints
│   ├── nuclei.txt              # nuclei scan results
│   ├── interesting-params.txt  # high-value parameters
│   ├── surface.json            # structured surface data
│   └── takeover/               # subdomain takeover artifacts
├── hypothesis-log.md           # every test: tried / confirmed / refuted
├── findings/                   # one file per candidate
│   └── <bug-class>-<endpoint>/
│       ├── hackerone-report.md
│       ├── submission-notes.md
│       └── evidence/
└── session-notes.md            # phase status, gates passed
```

## SQLite Database Schema (scope.sqlite)

```sql
-- Core tables
CREATE TABLE targets (
    id INTEGER PRIMARY KEY,
    root_domain TEXT UNIQUE NOT NULL,
    program_name TEXT,
    vdp_url TEXT,
    github_org TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE scope_in (
    id INTEGER PRIMARY KEY,
    target_id INTEGER REFERENCES targets(id),
    pattern TEXT NOT NULL,           -- *.notsecure.in
    type TEXT DEFAULT 'wildcard',    -- wildcard, exact, cidr
    source TEXT,                     -- program_page, github, manual
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE scope_out (
    id INTEGER PRIMARY KEY,
    target_id INTEGER REFERENCES targets(id),
    pattern TEXT NOT NULL,           -- dev.notsecure.in
    reason TEXT,                     -- explicitly excluded
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Recon tables
CREATE TABLE subdomains (
    id INTEGER PRIMARY KEY,
    target_id INTEGER REFERENCES targets(id),
    subdomain TEXT NOT NULL,
    source TEXT,                     -- crt.sh, subfinder, chaos, etc.
    discovered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(target_id, subdomain)
);

CREATE TABLE dns_records (
    id INTEGER PRIMARY KEY,
    subdomain_id INTEGER REFERENCES subdomains(id),
    record_type TEXT,                -- A, AAAA, CNAME, NS, MX, TXT
    value TEXT,
    ttl INTEGER,
    resolved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE cname_chains (
    id INTEGER PRIMARY KEY,
    subdomain_id INTEGER REFERENCES subdomains(id),
    cname_target TEXT,
    chain_depth INTEGER,
    is_dangling BOOLEAN DEFAULT 0,
    provider TEXT,                   -- aws, github, azure, etc.
    takeover_candidate BOOLEAN DEFAULT 0,
    fingerprint TEXT,                -- matched fingerprint
    checked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE http_services (
    id INTEGER PRIMARY KEY,
    subdomain_id INTEGER REFERENCES subdomains(id),
    url TEXT NOT NULL,
    status_code INTEGER,
    title TEXT,
    tech TEXT,                       -- JSON array of technologies
    webserver TEXT,
    cdn TEXT,
    content_type TEXT,
    headers TEXT,                    -- JSON
    csp TEXT,
    response_size INTEGER,
    probed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE urls (
    id INTEGER PRIMARY KEY,
    target_id INTEGER REFERENCES targets(id),
    url TEXT NOT NULL,
    source TEXT,                     -- katana, gau, waybackurls, js-analysis
    has_params BOOLEAN DEFAULT 0,
    param_names TEXT,                -- JSON array
    classified_as TEXT,              -- xss, ssrf, idor, sqli, etc.
    discovered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE js_files (
    id INTEGER PRIMARY KEY,
    url_id INTEGER REFERENCES urls(id),
    js_url TEXT NOT NULL,
    has_secrets BOOLEAN DEFAULT 0,
    secrets_found TEXT,              -- JSON array
    endpoints_found TEXT,            -- JSON array
    analyzed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE api_endpoints (
    id INTEGER PRIMARY KEY,
    url_id INTEGER REFERENCES urls(id),
    method TEXT,
    path TEXT,
    params TEXT,                     -- JSON
    auth_required BOOLEAN DEFAULT 0,
    graphql BOOLEAN DEFAULT 0,
    discovered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE nuclei_findings (
    id INTEGER PRIMARY KEY,
    target_id INTEGER REFERENCES targets(id),
    template_id TEXT,
    template_name TEXT,
    severity TEXT,                   -- critical, high, medium, low, info
    matched_url TEXT,
    matched_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    raw_output TEXT
);

CREATE TABLE takeover_findings (
    id INTEGER PRIMARY KEY,
    target_id INTEGER REFERENCES targets(id),
    subdomain TEXT,
    cname_target TEXT,
    provider TEXT,
    takeover_type TEXT,              -- cname, ns, a_record, mx, srv, axfr
    fingerprint_matched TEXT,
    evidence_file TEXT,
    canary_triggered BOOLEAN DEFAULT 0,
    severity TEXT,                   -- critical, high, medium, low
    chain_potential TEXT,            -- cookies, oauth, csp, secrets
    verified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Origin IP Discovery tables
CREATE TABLE origin_candidates (
    id INTEGER PRIMARY KEY,
    target_id INTEGER REFERENCES targets(id),
    ip TEXT NOT NULL,
    family TEXT,                     -- IPv4, IPv6
    hostname TEXT,                   -- associated hostname
    role TEXT,                       -- Direct origin, Load balancer, Reverse proxy, K8s ingress, CDN upstream, etc.
    relation TEXT,                   -- SAN_match, historical_A_record, favicon_match, etc.
    asn TEXT,                        -- AS12345
    provider TEXT,                   -- AWS, GCP, Azure, Cloudflare, etc.
    tls_evidence TEXT,               -- JSON: JARM, cert_SAN_match, etc.
    http_evidence TEXT,              -- JSON: matching_favicon, matching_server_header, etc.
    dns_source TEXT,                 -- SecurityTrails, crt.sh, etc.
    ct_source TEXT,                  -- crt.sh SAN match, etc.
    exposure_source TEXT,            -- Shodan, Censys, etc.
    first_seen TIMESTAMP,
    last_seen TIMESTAMP,
    contradiction TEXT,              -- any contradictory evidence
    confidence TEXT,                 -- weak, moderate, strong, confirmed
    status TEXT,                     -- candidate, eliminated, verified
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE origin_evidence (
    id INTEGER PRIMARY KEY,
    candidate_id INTEGER REFERENCES origin_candidates(id),
    source TEXT,                     -- crt.sh, SecurityTrails, Shodan, etc.
    source_type TEXT,                -- certificate_transparency, passive_dns, exposure, etc.
    collected_at TIMESTAMP,
    observed_at TIMESTAMP,
    hostname TEXT,
    ip TEXT,
    relation TEXT,
    dns_state TEXT,
    asn_at_collection TEXT,
    provider_at_collection TEXT,
    cert_validity TEXT,
    http_tls_fingerprint TEXT,
    historical_or_current TEXT,
    contradiction TEXT,
    confidence TEXT,
    raw_data TEXT                    -- JSON blob of raw source data
);

CREATE TABLE origin_gates (
    id INTEGER PRIMARY KEY,
    candidate_id INTEGER REFERENCES origin_candidates(id),
    gate_1_identified BOOLEAN DEFAULT 0,
    gate_2_app_association BOOLEAN DEFAULT 0,
    gate_3_role_supported BOOLEAN DEFAULT 0,
    gate_4_direct_access BOOLEAN DEFAULT 0,
    gate_5_impact_demonstrated BOOLEAN DEFAULT 0,
    class TEXT,                      -- 1-8 per classification
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE hypothesis_log (
    id INTEGER PRIMARY KEY,
    target_id INTEGER REFERENCES targets(id),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    host TEXT,
    technique TEXT,
    payload TEXT,
    result TEXT,                     -- confirmed, refuted, error
    evidence TEXT,
    notes TEXT
);

CREATE TABLE findings (
    id INTEGER PRIMARY KEY,
    target_id INTEGER REFERENCES targets(id),
    bug_class TEXT,
    endpoint TEXT,
    severity TEXT,
    cvss_vector TEXT,
    status TEXT,                     -- draft, validated, chained, reported, killed
    report_path TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for performance
CREATE INDEX idx_subdomains_target ON subdomains(target_id);
CREATE INDEX idx_dns_subdomain ON dns_records(subdomain_id);
CREATE INDEX idx_cname_subdomain ON cname_chains(subdomain_id);
CREATE INDEX idx_http_subdomain ON http_services(subdomain_id);
CREATE INDEX idx_urls_target ON urls(target_id);
CREATE INDEX idx_findings_target ON findings(target_id);
CREATE INDEX idx_hypothesis_target ON hypothesis_log(target_id);
CREATE INDEX idx_origin_candidates_target ON origin_candidates(target_id);
CREATE INDEX idx_origin_candidates_ip ON origin_candidates(ip);
CREATE INDEX idx_origin_candidates_status ON origin_candidates(status);
CREATE INDEX idx_origin_evidence_candidate ON origin_evidence(candidate_id);
CREATE INDEX idx_origin_gates_candidate ON origin_gates(candidate_id);
```

## Database Population Commands

```bash
TARGET="notsecure.in"
DB="targets/$TARGET/scope.sqlite"

# Initialize database
sqlite3 "$DB" < /path/to/schema.sql

# Insert target
sqlite3 "$DB" "INSERT INTO targets (root_domain, program_name, vdp_url, github_org) 
VALUES ('notsecure.in', 'NotSecure-IN', 'https://www.notsecure.in/vdp', 'NotSecure-IN');"

# Get target_id
TARGET_ID=$(sqlite3 "$DB" "SELECT id FROM targets WHERE root_domain='$TARGET';")

# Insert scope
sqlite3 "$DB" "INSERT INTO scope_in (target_id, pattern, type, source) VALUES 
($TARGET_ID, '*.notsecure.in', 'wildcard', 'program_page'),
($TARGET_ID, '*.notsec.in', 'wildcard', 'program_page'),
($TARGET_ID, '*.notsecure.com', 'wildcard', 'program_page');"

sqlite3 "$DB" "INSERT INTO scope_out (target_id, pattern, reason) VALUES 
($TARGET_ID, 'dev.notsecure.in', 'explicitly excluded from scope');"

# Insert subdomains (from recon)
while read sub; do
    sqlite3 "$DB" "INSERT OR IGNORE INTO subdomains (target_id, subdomain, source) 
    VALUES ($TARGET_ID, '$sub', 'subfinder');"
done < recon/subdomains.txt

# Insert DNS records
# (parse dnsx output and insert into dns_records)

# Insert CNAME chains
# (parse cname_detailed.txt and insert into cname_chains)

# Insert HTTP services
# (parse httpx_live.txt and insert into http_services)

# Insert URLs
# (parse urls.txt and insert into urls)

# Insert nuclei findings
# (parse nuclei.txt and insert into nuclei_findings)

# Insert takeover findings
# (parse takeover results and insert into takeover_findings)

# Insert origin candidates (from origin IP discovery)
# (parse recon/origin/candidates.json and insert into origin_candidates)

# Insert origin evidence
# (parse recon/origin/evidence.jsonl and insert into origin_evidence)

# Insert origin gates
# (parse recon/origin/gates.json and insert into origin_gates)
```

## Hypothesis Log Format

```
| Timestamp | Host | Technique | Payload | Result | Evidence |
|---|---|---|---|---|---|
| ... | api.example.com | PP | __proto__ json spaces | refuted | no indent change |
| ... | api.example.com | IDOR | user_id=456 | confirmed | victim order data in response |
```

Also logged to SQLite `hypothesis_log` table.

## Recon Status

Write `recon_status: complete` in `session-notes.md` only after:
- `surface.json` has at least one live host with endpoints
- JS list is populated (if JS exists)
- At least one hypothesis logged per in-scope host
- `nuclei.txt` scan run (critical/high/medium)
- SQLite database populated with all recon data

## Session Notes Format

```markdown
# Session Notes: notsecure.in

## Phase Status
- recon_status: complete
- validate_gate: passed/failed/killed
- chain_proven: yes/no
- report_written: yes/no

## Gates Passed
- [ ] Q1-Q7 all YES
- [ ] Not on always-rejected list
- [ ] Chain requirement satisfied
- [ ] CVSS vector written
- [ ] Pre-submit checklist complete

## Kill Signals (if any)
- 5-minute rule triggered at 00:15
- Target score: 3/10 (skip reason: max bounty $200)
```

## 30-Minute Recon Protocol

### Minutes 0-5: Parse Input & Read Program Page
```
Input: https://www.notsecure.in/vdp
Parse:
- Root domain: notsecure.in
- VDP URL: https://www.notsecure.in/vdp
- Program: NotSecure-IN

Fetch program page, extract:
- ALL in-scope assets (every domain listed)
- Out-of-scope list (read carefully — common trap)
- GitHub org: github.com/NotSecure-IN/
- Safe harbor statement
- Impact types accepted
- Average bounty amount
```

### Minutes 5-15: Asset Discovery
Run the standard recon pipeline. Focus on live-hosts.txt output.

### Minutes 15-25: Surface Map
Run gf patterns and the interesting-params grep.

### Minutes 25-30: Manual Exploration
Open Burp Suite. Browse the app with proxy on:
1. Register an account
2. Perform main user actions (create/read/update/delete resources)
3. Note all API calls in Burp history
4. Look for endpoints not in your URL list

### After 30 min: Prioritize
```
Priority 1: API endpoints with ID parameters → IDOR candidates
Priority 2: File upload features → XSS/RCE candidates
Priority 3: OAuth/SSO flows → auth bypass candidates
Priority 4: Search/filter with user input → SQLi/SSRF/SSTI candidates
Priority 5: Admin/debug endpoints → auth bypass candidates
```