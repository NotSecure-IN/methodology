# Mindset

## Loop
1. **Map wide** — collect every observable signal (tech, headers, endpoints, JS).
2. **Hypothesize wide** — from signals, list plausible vulnerability classes.
3. **Confirm strict** — only proceed to a reference if the one-line test is defined.

## Anti-Patterns
- Jumping to exploitation before recon is complete.
- Testing a technique because it is "popular" without a signal.
- Writing a report before validation gate passes.
