# Reporting Standard

A report is only written after `validate` returns PASS.

## Required Sections
1. Title (vulnerability class + affected endpoint)
2. Summary (1–2 sentences, impact-focused)
3. Steps to Reproduce (numbered, raw HTTP where possible)
4. Evidence (request + response, redacted only if PII)
5. Impact (what an attacker gains)
6. Remediation (specific, actionable)
7. CVSS 3.1 vector (from `validate/references/cvss-quickref.md`)
