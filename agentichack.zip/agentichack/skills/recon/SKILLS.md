---
name: recon
description: >
  Web2 recon pipeline — subdomain enumeration, live host discovery, URL crawling,
  JS analysis, directory fuzzing, source disclosure extraction. Produces surface.json,
  scope.sqlite, and session-notes.md with recon_status: complete. Does not perform vulnerability testing.
license: MIT
compatibility: opencode>=1.5.0
metadata:
  framework: agentichack
  version: "1.0.0"
  tags: "agentichack,recon,surface,web2,sqlite"
  allowed-tools: "read,bash,skill"
---

# Web2 Recon Pipeline

## Entry Condition

User provides target in one of these formats:
```
https://www.notsecure.in/vdp
https://target.com
target.com
```

Agent parses this to extract:
- **Root domain**: `notsecure.in`
- **Program name**: from VDP page or GitHub org
- **VDP URL**: original input
- **GitHub org**: from program page

If missing, ask once. Do not start without parsed scope.

## Mandatory Sequence

1. **Parse Input** → extract root domain, fetch program page, populate `scope.md` and `scope.sqlite`
2. **Stage 1: Subdomain Deep Mapping** (10+ sources + GitHub source code recon)
3. **Stage 2: DNS Resolution + CNAME Chains** (puredns, dnsx, wildcard filtering)
4. **Stage 3: HTTP Probe & Tech Fingerprint** (httpx 10 ports, CDN detection)
5. **Stage 4: Content Discovery & Parameter Mining** (katana, gau, waybackurls, arjun, gf)
6. **Stage 5: JavaScript Analysis** (LinkFinder, SecretFinder, trufflehog, source maps)
7. **Stage 6: API Surface Mapping** (GraphQL, REST, mass assignment)
8. **Stage 7: Origin IP Discovery** (passive-first, 15-phase methodology)
9. **Populate SQLite** → all recon data in `scope.sqlite`
10. **Completion Gate** → `recon_status: complete`

---

## 6-Stage Pipeline

### Stage 1: Subdomain Deep Mapping
**References:** `references/subdomain-deep.md`
- Passive sources: subfinder, subdominator, assetfinder, crt.sh, Chaos API, Wayback, AnubisDB, VT, ThreatCrowd
- **GitHub source code recon** from program's GitHub org
- Resolution: dnsx (A, CNAME chains)
- **Scope filtering**: in-scope patterns vs out-of-scope exclusions
- Signals: third-party CNAMEs → takeover candidates; wildcard DNS → noise filter

### Stage 2: DNS Resolution + CNAME Chains
**References:** `references/subdomain-deep.md` (Steps 1-3)
- Fresh resolvers (trickest + massdns filter)
- puredns high-throughput resolution (2000 req/s)
- Multi-threaded CNAME extraction (dnsx 200 threads)
- **CNAME chain analysis** with provider detection (AWS, GitHub, Azure, Netlify, Vercel, Heroku, etc.)
- Takeover candidate flagging in SQLite

### Stage 3: HTTP Probe & Tech Fingerprint
**References:** `references/http-probe.md`
- httpx with: status-code, title, tech-detect, content-type, web-server, location, headers, CSP, CDN
- 10 ports: 80,443,8080,8443,3000,5000,8000,8008,8088,8888
- Extract per host: status_code, tech stack, content_type, webserver, CDN, CSP
- Filter: 403/401 → bypass targets; 200/301/302 → attack surface

### Stage 4: Content Discovery & Parameter Mining
**References:** `references/content-discovery.md`
- Crawl: katana (depth 3, JS crawling)
- Historical: gau, waybackurls
- Parameters: arjun
- Classify with gf: xss, ssrf, idor, sqli, redirect, lfi, rce, ssti, debug_logic, secrets, upload-fields, cors

### Stage 5: JavaScript Analysis
**References:** `references/js-analysis.md`
- LinkFinder: endpoints hidden in JS bundles
- SecretFinder: API keys, tokens in JS
- trufflehog: verified secrets in downloaded JS
- Catalog: .js.map files → source recovery

### Stage 6: API Surface Mapping
**References:** `references/api-surface.md`
- GraphQL introspection (if enabled)
- Swagger/OpenAPI endpoints
- REST API version enumeration
- Mass assignment parameter discovery

### Stage 7: Origin IP Discovery
**References:** `references/origin-ip.md`
- **Phase 0**: Pre-flight authorization + evidence model
- **Phase 1**: Passive domain + certificate + historical DNS
- **Phase 2**: DNS edge-case analysis (CNAME chains, HTTPS/SVCB, NS history, split-horizon)
- **Phase 3**: Application-layer correlation (Alt-Svc, HTTP/2, redirects, canonical, cookies, CORS, CDN headers)
- **Phase 4**: Passive exposure + fingerprint intelligence (Shodan/Censys, favicon hash, JARM, HTTP/2 fingerprints)
- **Phase 5**: ASN/BGP/cloud attribution (ASN org, BGP history, cloud range exclusion)
- **Phase 6**: Application component decomposition (frontend, auth, API, GraphQL, WS, static, upload, download, regional, admin)
- **Phase 7**: Advanced leakage channels (JS source maps, mobile bundles, public errors)
- **Phase 8**: Infrastructure role classification (origin, LB, reverse proxy, K8s ingress, CDN upstream, etc.)
- **Phase 9**: Temporal evidence + independence analysis (timestamps, deduplication, contradiction tracking)
- **Phase 10**: Shared infrastructure + multi-tenancy analysis
- **Phase 11**: Dedicated IPv6 investigation
- **Phase 12**: Candidate ranking + false-positive elimination (confidence scoring, elimination criteria)
- **Phase 13**: Authorized active validation (--resolve, cert-on-IP, differential response)
- **Phase 14**: Evidence gates (5-gate separation, 8-class classification)
- **Phase 15**: Reporting + remediation checklist

---

## SQLite Database (Mandatory)

**File:** `targets/<target>/recon/scope.sqlite`

**Schema:** See `references/workflow.md` for complete schema with tables:
- `targets` — root domain, program name, VDP URL, GitHub org
- `scope_in` / `scope_out` — in-scope/out-of-scope patterns
- `subdomains` — all discovered subdomains with source
- `dns_records` — A, AAAA, CNAME, NS, MX, TXT records
- `cname_chains` — CNAME targets, provider detection, takeover flags
- `http_services` — live HTTP services with tech fingerprint
- `urls` — all discovered URLs with classification
- `js_files` — JS bundles with secrets/endpoints
- `api_endpoints` — API endpoints with params
- `nuclei_findings` — nuclei scan results
- `takeover_findings` — subdomain takeover results
- `origin_candidates` — IP candidates with evidence, confidence, role, status
- `origin_evidence` — individual evidence records per candidate
- `origin_gates` — gate status per candidate (1-5)
- `hypothesis_log` — every test attempted
- `findings` — validated bug candidates

**Population:** After each stage, relevant data written to SQLite.

---

## Completion Gate

Write `recon_status: complete` in `session-notes.md` ONLY after:
- `surface.json` has ≥1 live host with endpoints
- JS bundle list populated (if JS exists)
- At least one hypothesis logged per in-scope host in `hypothesis-log.md`
- `nuclei.txt` scan run (critical/high/medium)
- **SQLite database fully populated** with all recon data

---

## Output Structure

```
targets/<target-name>/
├── scope.md                    # human-readable scope
├── scope.sqlite                # SQLite database with ALL data
├── recon/
│   ├── subdomains.txt          # all discovered subdomains
│   ├── subdomains_in_scope.txt # scope-filtered
│   ├── resolved.txt            # DNS-resolved subdomains
│   ├── cname_detailed.txt      # CNAME chains
│   ├── cname_records.txt       # quick CNAME
│   ├── httpx_live.txt          # live HTTP services
│   ├── httpx_urls.txt          # extracted URLs
│   ├── urls.txt                # all discovered URLs
│   ├── js-bundles.txt          # JavaScript files
│   ├── api-endpoints.txt       # API endpoints
│   ├── nuclei.txt              # nuclei scan results
│   ├── interesting-params.txt  # high-value parameters
│   ├── surface.json            # structured surface data
│   ├── takeover/               # subdomain takeover artifacts
│   └── origin/                 # origin IP discovery artifacts
│       ├── candidates.json     # candidate IPs with evidence
│       ├── evidence.jsonl      # individual evidence records
│       ├── gates.json          # gate status per candidate
│       ├── ranking.json        # ranked candidates with confidence
│       ├── eliminated.json     # eliminated candidates with reasons
│       └── validation.json     # active validation results (if authorized)
├── hypothesis-log.md
├── findings/
└── session-notes.md
```

---

## 5-Minute Rule

If a target shows nothing interesting after 5 minutes of recon (all subdomains 403/static, no API endpoints, no JS endpoints, nuclei 0 medium/high), document kill signal in session-notes.md and move on.