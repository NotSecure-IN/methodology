# JavaScript Analysis (via Caido Proxy)

## Prerequisites
Caido must be running headless on `http://localhost:8080`.

## LinkFinder (Endpoints in JS via Caido)

```bash
# Activate venv
source ~/tools/LinkFinder/.venv/bin/activate

# Single JS file via Caido proxy (set HTTP_PROXY env)
export HTTP_PROXY="http://localhost:8080"
export HTTPS_PROXY="http://localhost:8080"

# Single JS file
python3 ~/tools/LinkFinder/linkfinder.py -i "https://target.com/static/js/main.js" -o cli

# Crawl from HTML (finds JS in pages)
python3 ~/tools/LinkFinder/linkfinder.py -i "https://target.com" -d -o cli

unset HTTP_PROXY HTTPS_PROXY
deactivate
```

## SecretFinder (Secrets in JS via Caido)

```bash
source ~/tools/SecretFinder/.venv/bin/activate
export HTTP_PROXY="http://localhost:8080"
export HTTPS_PROXY="http://localhost:8080"

# Scan single JS
python3 ~/tools/SecretFinder/SecretFinder.py -i "https://target.com/static/js/main.js" -o cli

# Batch scan all JS URLs
cat recon/urls.txt | grep "\.js$" | head -50 | while read url; do
  echo "=== $url ==="
  python3 ~/tools/SecretFinder/SecretFinder.py -i "$url" -o cli 2>/dev/null
done

unset HTTP_PROXY HTTPS_PROXY
deactivate
```

## trufflehog (Verified Secrets)

```bash
# Scan downloaded JS directory (local - no proxy needed)
trufflehog filesystem --only-verified recon/js-files/ 2>/dev/null

# Scan git repo if source disclosed (local)
trufflehog git file:///tmp/dump-target --only-verified
```

## Source Map Recovery (.js.map via Caido)

```bash
# Find .js.map references in JS
grep -r "\.js\.map" recon/js-files/ | sed 's/.*\/\/.*sourceMappingURL=//' | sort -u

# Download and parse via Caido
curl -x "http://localhost:8080" -s "https://target.com/static/js/main.js.map" -o recon/main.js.map
# Use source-map-explorer or manual parsing to recover original source
```

## Download JS Files for Local Analysis (via Caido)

```bash
# Download all JS files through Caido for local analysis
mkdir -p recon/js-files/
cat recon/urls.txt | grep "\.js$" | head -100 | while read url; do
  filename=$(echo "$url" | sed 's|https\?://||' | sed 's|/|_|g')
  curl -x "http://localhost:8080" -s -L "$url" -o "recon/js-files/$filename" 2>/dev/null
done
```

## Signals for surface.json

| Finding | Signal | Next Step |
|---------|--------|-----------|
| API keys (AWS, Stripe, SendGrid, etc.) | `secret_leak` | Validate key works → Critical |
| Internal endpoints not in crawl | `hidden_endpoint` | Add to recon/urls.txt, test auth |
| JWT signing keys | `jwt_key_leak` | Forge tokens → Auth bypass |
| Source maps → full source | `source_disclosure` | White-box review (Pattern A) |
| Hardcoded credentials in config objects | `hardcoded_creds` | Test login/reuse |
| Prototype pollution sinks (`merge`, `clone`, `assign`) | `pp_sink` | Test PP payloads |
| postMessage listeners without origin check | `postmessage_sink` | Test DOM XSS via iframe |
| DOM XSS sinks (`innerHTML`, `eval`, `document.write`) | `dom_xss_sink` | Trace source → test payload |

## Quick Grep Patterns on Downloaded JS

```bash
wget -q -r -l 1 -A "*.js" -P recon/js-files/ "https://${TARGET}" 2>/dev/null

# Prototype pollution sinks
grep -rn "merge\|clone\|assign\|extend\|defaults" recon/js-files/ --include="*.js"

# DOM XSS sinks
grep -rn "innerHTML\|outerHTML\|document\.write\|eval(\|setTimeout(\|setInterval(\|new Function(\|location\.href\|\.src\s*=" recon/js-files/

# postMessage
grep -rn "addEventListener.*message" recon/js-files/

# Secrets
grep -rn "api_key\|apiKey\|client_secret\|access_token\|private_key\|AWS_SECRET\|AKIA" recon/js-files/
```