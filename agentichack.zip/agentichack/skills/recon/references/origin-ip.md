# Origin IP Discovery — Advanced Runbook

> Complete methodology for discovering real origin IPs behind CDNs/WAFs.
> Passive-first. Active validation gated by explicit approval.
> All HTTP traffic via Caido proxy (`-x "http://localhost:8080"`).

---

## Phase 0 — Pre-Flight

### Authorization & Evidence Model

```bash
TARGET_DOMAIN="notsecure.in"
AUTHORIZED_COMPONENTS="frontend, API, auth, static, mobile, regional"
APPROVED_PASSIVE_SOURCES="crt.sh, SecurityTrails, DNSDB, Shodan, Censys, Netlas, FOFA, ZoomEye, subfinder, amass, dnsx, dig, ViewDNS, DomainTools, VirusTotal, Censys, RIPE Stat, cloud provider ranges"
APPROVED_ACTIVE_VALIDATION="curl --resolve, openssl s_client, differential response analysis"
RATE_LIMITS="Respect provider limits. Stop on 429/503."
LEGAL_CONTACT="[Your contact]"
```

### Evidence Record Schema

```json
{
  "evidence_id": "ORIGIN-2026-001",
  "source": "crt.sh",
  "source_type": "certificate_transparency",
  "collected_at": "2026-11-22T10:00:00Z",
  "observed_at": "2024-01-15T00:00:00Z",
  "hostname": "api.notsecure.in",
  "ip": "192.0.2.100",
  "relation": "SAN_match",
  "dns_state_at_collection": "A=192.0.2.100",
  "asn_at_collection": "AS12345",
  "provider_at_collection": "AWS",
  "cert_validity": "2024-01-01 to 2025-01-01",
  "http_tls_fingerprint": "JARM:abc123...",
  "historical_or_current": "historical",
  "contradiction": "none",
  "confidence": "moderate"
}
```

**Core Principle**: No candidate IP is an origin without independently corroborated ownership evidence.

---

## Phase 1 — Passive Domain + Certificate + Historical DNS

### 1A. Domain Inventory (via Caido)

```bash
TARGET="notsecure.in"

# Basic DNS records via Caido
for type in A AAAA CNAME NS MX TXT SOA CAA; do
  echo "=== $type ==="
  dig +short $type $TARGET @8.8.8.8
done
```

### 1B. Subdomain Enumeration

```bash
# Passive enumeration
subfinder -d notsecure.in -all -silent > subs_raw.txt
amass enum -passive -d notsecure.in >> subs_raw.txt
sort -u subs_raw.txt > subs_unique.txt

# DNS resolution
dnsx -l subs_unique.txt -a -aaaa -cname -resp -silent > subs_resolved.txt

# Categorize
# production / staging / dev / legacy / API / auth / static / upload / download / regional / admin / infrastructure
```

### 1C. Certificate Transparency (via Caido)

```bash
# crt.sh
curl -x "http://localhost:8080" -s "https://crt.sh/?q=%25.notsecure.in&output=json" | \
  jq -r '.[] | "\(.name_value) | \(.issuer_name) | \(.not_before) | \(.not_after)"' > certs_raw.txt

# Extract: Subject CN, SAN entries, Issuer, SHA-256, Not-Before/Not-After, first observed
```

### 1D. Historical DNS Reconstruction

```bash
# SecurityTrails, DNSDB, ViewDNS, DomainTools, VirusTotal, Censys
# Timeline: DATE | HOSTNAME | RECORD_TYPE | VALUE | SOURCE | CONFIDENCE

# Questions:
# - What IPs served the hostname before CDN adoption?
# - Did CNAME chains change during migration?
# - Do historical A records point to a different provider?

# Do not assume old IPs remain origins. Reassignment is the norm.
```

---

## Phase 2 — DNS Edge-Case Analysis

### 2A. CNAME Chains, Loops, Flattening

```bash
# Full trace
dig +trace notsecure.in

# Specific CNAMEs
dig CNAME www.notsecure.in
dig CNAME api.notsecure.in

# Look for:
# - Flattened CNAMEs (A records at apex where CNAME expected)
# - Chain termination at CDN vs hosting provider
# - Loops indicating misconfiguration
```

### 2B. ALIAS / ANAME Records

```bash
# Query authoritative NS directly
dig @ns1.provider.com notsecure.in ANY
```

### 2C. HTTPS and SVCB Records

```bash
dig HTTPS notsecure.in
dig SVCB notsecure.in

# Can expose:
# - Alternate endpoints
# - ALPN hints
# - ipv4hint / ipv6hint parameters
# - echconfig that masks SNI
```

### 2D. NS Delegation, Glue, Nameserver History

```bash
dig NS notsecure.in
dig +trace notsecure.in

# Historical NS changes: SecurityTrails NS history, Passive DNS
```

### 2E. Wildcard DNS Behavior

```bash
# Test random labels
for i in {1..5}; do
  RAND=$(cat /dev/urandom | tr -dc 'a-z0-9' | fold -w 12 | head -1)
  dig ${RAND}.notsecure.in @8.8.8.8
  dig ${RAND}.notsecure.in @1.1.1.1
done
```

### 2F. Split-Horizon / Resolver-Dependent Responses

```bash
for resolver in 8.8.8.8 1.1.1.1 9.9.9.9; do
  echo "=== $resolver ==="
  dig notsecure.in @$resolver
done

# Also query authoritative NS directly
```

### 2G. A/AAAA/CNAME Inconsistencies

```bash
# Compare across record types and resolvers
# Inconsistencies = correlation clues, not proof
```

---

## Phase 3 — Application-Layer Infrastructure Correlation

Collect from authorized, publicly observable responses (via Caido):

```bash
# Alt-Svc advertisements
curl -x "http://localhost:8080" -sS -D - -o /dev/null "https://notsecure.in/" | grep -i alt-svc

# HTTP/2 behavior (SETTINGS frames, server push)
curl -x "http://localhost:8080" --http2 -v "https://notsecure.in/" 2>&1 | grep -i "SETTINGS\|PUSH_PROMISE"

# Redirect chains
curl -x "http://localhost:8080" -sS -D - -o /dev/null -L "https://notsecure.in/" | grep -i "location:"

# Canonical host behavior
curl -x "http://localhost:8080" -s "https://notsecure.in/" | grep -i "canonical"

# Absolute asset/API URLs in HTML/JS/CSS
curl -x "http://localhost:8080" -s "https://notsecure.in/" | grep -oE 'https?://[^"'"'"'< >]+'

# WebSocket/gRPC hostnames
curl -x "http://localhost:8080" -s "https://notsecure.in/" | grep -iE 'ws://|wss://|grpc'

# Cookie domain attributes
curl -x "http://localhost:8080" -sS -D - -o /dev/null "https://notsecure.in/" | grep -i "set-cookie" | grep -i "domain="

# CORS configuration
curl -x "http://localhost:8080" -sS -D - -o /dev/null -H "Origin: https://attacker.example" "https://notsecure.in/" | grep -i "access-control-allow-origin"

# Host-dependent response differences
for host in "notsecure.in" "www.notsecure.in" "api.notsecure.in" "attacker.example"; do
  echo "=== Host: $host ==="
  curl -x "http://localhost:8080" -sS -D - -o /dev/null -H "Host: $host" "https://notsecure.in/" | head -20
done

# CDN-added vs application-generated headers
curl -x "http://localhost:8080" -sS -D - -o /dev/null "https://notsecure.in/" | grep -iE 'server:|via:|x-cache:|cf-ray:|x-amz-cf-id:|x-amzn-trace-id:'
```

---

## Phase 4 — Passive Internet Exposure + Fingerprint Intelligence

### 4A. Shodan / Censys / Netlas / FOFA / ZoomEye (via Caido for web UI)

```bash
# Query patterns (run in provider web UI or API):
# ssl:"notsecure.in"
# ssl.cert.subject.CN:"notsecure.in"
# http.title:"NotSecure"
# http.favicon.hash:<hash>

# Collect: IP, ASN, reverse DNS, TLS cert, HTTP headers, banner, first/last seen
```

### 4B. Favicon Hash Correlation

```bash
# Compute favicon hash
curl -x "http://localhost:8080" -s "https://notsecure.in/favicon.ico" | python3 -c "import sys, mmh3; print(mmh3.hash(sys.stdin.buffer.read()))"

# Search Shodan for same hash
# Non-CDN IPs with same favicon = CANDIDATES
```

### 4C. JARM + TLS Fingerprinting

```bash
# JARM on candidate IPs only (not fronted domain)
# JARM clusters TLS server stacks
# CDN terminates TLS at edge → JARM on fronted domain = CDN, not origin

# Use on candidate IPs to cluster by TLS configuration
```

### 4D. HTTP/2 + JA3/JA4

```bash
# JA3/JA4 = client side
# Akamai HTTP/2 fingerprint (SETTINGS + priority + pseudo-header order)
# Can reveal shared reverse-proxy / load-balancer stack
# Use as CLUSTERING SIGNALS only
```

---

## Phase 5 — ASN, BGP, and Cloud Attribution

### 5A. ASN + Network Attribution

```bash
# For each candidate IP
whois 192.0.2.100
dig -x 192.0.2.100
curl -s https://rdap.org/ip/192.0.2.100

# Record: ASN, org, prefix, country, hosting category
# Classify: CDN edge / cloud / dedicated / shared / enterprise / ISP / load balancer
```

### 5B. BGP Route History

```bash
# RIPE Stat
curl -s "https://stat.ripe.net/data/routing-history/data.json?resource=192.0.2.0/24"

# Look for:
# - Origin ASN changes on candidate prefix
# - Prefix announcements around migration window
# - Anycast vs unicast origin
# Temporal correlation = STRONG signal
```

### 5C. Cloud Provider Detection + Range Exclusion

```bash
# Download cloud ranges
curl -s https://ip-ranges.amazonaws.com/ip-ranges.json > aws_ranges.json
curl -s https://www.gstatic.com/ipranges/cloud.json > gcp_ranges.json
# Azure: Service Tags
# Cloudflare: https://www.cloudflare.com/ips-v4 / ips-v6

# Exclude known CDN/cloud edge ranges before ranking
# For cloud candidates, determine SERVICE:
# AWS: EC2 vs ELB vs CloudFront vs S3 (DNS patterns + headers)
# GCP: Compute vs Load Balancer vs CDN
# Azure: VM vs Front Door vs CDN

# Metadata endpoints (169.254.169.254, metadata.google.internal) BLOCKED externally
```

---

## Phase 6 — Application Component Decomposition

Decompose into independent infrastructure groups:

```bash
COMPONENTS=(
  "frontend:notsecure.in,www.notsecure.in"
  "auth:auth.notsecure.in,login.notsecure.in"
  "api:api.notsecure.in,api-v1.notsecure.in"
  "graphql:graphql.notsecure.in"
  "websocket:ws.notsecure.in,wss.notsecure.in"
  "mobile:mobile-api.notsecure.in"
  "static:static.notsecure.in,assets.notsecure.in"
  "upload:upload.notsecure.in"
  "download:download.notsecure.in"
  "regional:eu.notsecure.in,us.notsecure.in"
  "admin:admin.notsecure.in,legacy.notsecure.in"
)

# For each: enumerate hostnames, certificates, CDN/WAF, candidate sets independently
# Frontend and API origins may live in different providers
```

---

## Phase 7 — Advanced Leakage Channels (Public Only)

### 7A. JavaScript Source Map Analysis

```bash
# Check for sourceMappingURL
curl -x "http://localhost:8080" -s "https://notsecure.in/static/js/app.js" | tail -c 200

# If .map present
curl -x "http://localhost:8080" -s "https://notsecure.in/static/js/app.js.map" | \
  jq -r '.sources[]' | grep -vE '^webpack://|^node_modules/'

# Look for:
# - Internal hostnames
# - Private IPs
# - API base URLs pointing to non-CDN infrastructure
# - Deployment metadata
```

### 7B. Mobile Application Bundle Analysis (if authorized)

```bash
# strings app.apk | grep -Ei 'https?://|api\.|origin|backend'
# Look for hardcoded API endpoints, non-CDN hostnames, internal IP ranges
```

### 7C. Public Error / Metadata Disclosure

```bash
# Error pages leaking internal hostnames
# Misconfigured redirects to internal infrastructure
# Public deployment manifests
# CORS headers revealing allowed origins
```

---

## Phase 8 — Infrastructure Role Classification

Classify each candidate as exactly one role:

```bash
ROLES=(
  "Direct application origin"
  "Load balancer"
  "Reverse proxy"
  "Kubernetes ingress or gateway"
  "Shared hosting endpoint"
  "CDN upstream or parent proxy"
  "Regional application endpoint"
  "Static-content endpoint"
  "Object-storage endpoint"
  "Unknown infrastructure role"
)

# Do not label IP as origin until role adequately supported by evidence
# A load balancer is not an application server
```

---

## Phase 9 — Temporal Evidence + Evidence Independence

### 9A. Temporal Evidence Management

```bash
# For every observation preserve:
# - Collection timestamp
# - Source and source type
# - DNS state at collection time
# - IP-to-ASN relationship
# - Hosting-provider attribution
# - Certificate validity period
# - Relevant HTTP/TLS fingerprints
# - Historical vs. current status

# Account for IP reassignment, migration, evidence expiration
```

### 9B. Evidence Independence and Contradiction Analysis

```bash
# For each candidate:
# - Identify original source of each observation
# - Detect duplicated/derivative intelligence
# - Separate independent evidence from repeated copies
# - Record contradictory observations
# - Evaluate source reliability and freshness
# - Recalculate confidence when evidence changes

# Do NOT increase confidence because multiple services reproduce same underlying observation
```

---

## Phase 10 — Shared Infrastructure and Multi-Tenancy

```bash
# Determine if candidate belongs to:
# - Shared cloud infrastructure
# - Shared reverse-proxy infrastructure
# - Multi-tenant hosting
# - Shared load-balancing services
# - CDN or edge networks

# Matching cert, favicon, HTTP response, or TLS fingerprint alone
# does NOT establish application ownership on shared infrastructure
```

---

## Phase 11 — Dedicated IPv6 Investigation

```bash
# Evaluate separately from IPv4:
# - Historical AAAA records
# - IPv6-specific service exposure
# - IPv4/IPv6 response differences
# - IPv6 certificate observations
# - IPv6 ASN and hosting attribution
# - Whether IPv6 and IPv4 serve the same application

# Do not assume IPv4 and IPv6 infrastructure have identical security configurations
```

---

## Phase 12 — Candidate Ranking + False-Positive Elimination

### Candidate Schema

```json
{
  "candidate_id": "ORIGIN-001",
  "ip": "192.0.2.100",
  "family": "IPv4",
  "hostname": "api.notsecure.in",
  "role": "Direct application origin",
  "relation": "SAN_match + historical_A_record",
  "asn": "AS12345",
  "provider": "AWS",
  "tls_evidence": "JARM:abc123, cert_SAN_match",
  "http_evidence": "matching_favicon, matching_server_header",
  "dns_source": "SecurityTrails historical",
  "ct_source": "crt.sh SAN match",
  "exposure_source": "Shodan: matching_favicon",
  "first_seen": "2023-06-15",
  "last_seen": "2026-11-20",
  "contradiction": "none",
  "confidence": "moderate",
  "status": "candidate"
}
```

### Confidence Levels

| Level | Criteria |
|-------|----------|
| WEAK | Same ASN, same cloud, similar server header, similar favicon |
| MODERATE | Historical DNS association, shared cert, multiple hostname relationships, matching app metadata |
| STRONG | Multiple INDEPENDENT passive sources agree, consistent historical timeline, current hostname relationship, application identity correlation |
| CONFIRMED | Owner-provided asset inventory, provider configuration, owner confirmation |

### Eliminate/Quarantine

```bash
ELIMINATE=(
  "CDN edge IPs"
  "Shared hosting with no unique application evidence"
  "Reassigned historical IPs (BGP history + Shodan last-seen)"
  "Mail-only infrastructure"
  "DNS provider anycast addresses"
  "Third-party SaaS endpoints"
  "Unrelated certificate matches"
  "Stale DNS records"
  "Reverse proxy mistaken for application server"
  "Load balancer mistaken for individual origin"
)

# Document rejection reason for every eliminated candidate
```

---

## Phase 13 — Authorized Active Validation

**Only if explicitly permitted**

### 13A. Confirm-by-Host-Header

```bash
curl -k -s --resolve notsecure.in:443:192.0.2.100 https://notsecure.in/ \
  -o /dev/null -w "%{http_code} %{size_download}\n"

# Compare: status, size, first-1KB body hash, TLS certificate presented
```

### 13B. Certificate-on-IP Check

```bash
openssl s_client -connect 192.0.2.100:443 -servername notsecure.in </dev/null 2>/dev/null | \
  openssl x509 -noout -subject -issuer -fingerprint -sha256
```

### 13C. Differential Response Analysis

```bash
# Compare fronted vs. direct-origin
FRONTED_HASH=$(curl -x "http://localhost:8080" -s "https://notsecure.in/" | sha256sum)
CANDIDATE_HASH=$(curl -k -s --resolve notsecure.in:443:192.0.2.100 https://notsecure.in/ | sha256sum)

# Compare:
# FRONTED_HASH vs CANDIDATE_HASH
# FRONTED_HEADERS vs CANDIDATE_HEADERS
# FRONTED_COOKIES vs CANDIDATE_COOKIES

# Differences may reveal:
# - Origin-level debug headers
# - Missing WAF headers
# - Different server versions
# - Alternate auth behavior
```

### 13D. Record Everything

```bash
# timestamp, source IP, target IP, Host header, TLS cert fingerprint,
# response status, size, hash, contradictions

# A successful direct connection is NOT evidence of a WAF bypass
# A confirmed origin IP alone is NOT a vulnerability
```

---

## Phase 14 — Final Evidence and Impact Gates

### Gate Separation

```
GATE 1: Candidate IP identified
GATE 2: Application association supported
GATE 3: Current infrastructure role supported
GATE 4: Direct accessibility demonstrated
GATE 5: Security impact demonstrated

Do not collapse Gate 1 into Gate 5.
An IP address discovery alone is not proof of a vulnerability.
```

### Final Classification

| Class | Description |
|-------|-------------|
| 1 | CDN EDGE |
| 2 | UNKNOWN INFRASTRUCTURE |
| 3 | HISTORICAL ORIGIN CANDIDATE |
| 4 | CURRENT ORIGIN CANDIDATE |
| 5 | CORROBORATED ORIGIN |
| 6 | OWNER-VERIFIED ORIGIN |
| 7 | OWNER-VERIFIED ORIGIN WITH PUBLIC EXPOSURE |
| 8 | OWNER-VERIFIED ORIGIN WITH DEMONSTRATED SECURITY WEAKNESS |

---

## Phase 15 — Reporting

```
TARGET:
COMPONENT:
CANDIDATE IP:
ADDRESS FAMILY:
PROVIDER:
ROLE:
ORIGIN STATUS:
EVIDENCE SOURCES (independent):
OBSERVATION TIMELINE:
APPLICATION CORRELATION:
DIRECT ACCESS VALIDATION:
INTENDED SECURITY CONTROL:
ACTUAL BEHAVIOR:
DEMONSTRATED IMPACT:
FALSE-POSITIVE REVIEW:
REMEDIATION:
```

### Remediation Checklist

```bash
REMEDIATION=(
  "Restrict origin ingress to trusted edge networks only"
  "Enforce CDN-to-origin authentication (mTLS / secret header / authenticated origin pulls)"
  "Review alternate hostnames for the same origin"
  "Apply identical policy to IPv4 and IPv6"
  "Protect secondary/failover origins"
  "Retire legacy infrastructure still reachable directly"
  "Monitor for unexpected direct-origin requests"
)
```

---

## Tool Stack (2026)

```bash
# Passive DNS: SecurityTrails, DNSDB, ViewDNS, DomainTools
# Certificates: crt.sh, Censys, OpenSSL
# Exposure: Shodan, Censys, Netlas, FOFA, ZoomEye
# Subdomains: subfinder, amass, dnsx
# DNS edge cases: dig (+trace, HTTPS/SVCB queries), multiple resolvers
# Favicon: favup
# JARM/TLS: jarm, JA3/JA4 tools, OpenSSL
# HTTP/2 fingerprint: JA4H, Akamai HTTP/2 fingerprint libraries
# BGP history: RIPE Stat Routing History
# Cloud ranges: AWS ip-ranges.json, GCP cloud.json, Azure service tags, Cloudflare IPs
# Correlation: Python, jq, SQLite, CSV/JSON
```

---

## One-Line Truth

> The most advanced approach is not one tool or one query. It is:
> broad passive collection → DNS and application-layer edge-case analysis →
> evidence independence and contradiction analysis → strict role classification →
> false-positive elimination → owner-verified confirmation.
> NO technique guarantees origin discovery. Private origins and outbound-only
> tunnels may have no publicly discoverable address.