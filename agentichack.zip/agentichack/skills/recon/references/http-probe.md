# HTTP Probe (via Caido Proxy)

## Prerequisites
Caido must be running headless on `http://localhost:8080` before this stage.

```bash
# Verify Caido is running
curl -s http://localhost:8080/health || { echo "Caido not running! Start with: caido-cli serve --headless --port 8080 &"; exit 1; }
```

## Command (All Traffic via Caido)

```bash
cat recon/subdomains_in_scope.txt | httpx -json -o recon/httpx.json \
  -proxy "http://localhost:8080" \
  -status-code -title -tech-detect -content-type -web-server -location \
  -headers -csp -cdn -follow-redirects \
  -ports 80,443,8080,8443,3000,5000,8000,8008,8088,8888 \
  -threads 200 -timeout 10 -retries 2 \
  -random-agent -probe
```

### Also Output Human-Readable
```bash
cat recon/subdomains_in_scope.txt | httpx \
  -proxy "http://localhost:8080" \
  -status-code -title -tech-detect -cdn -follow-redirects \
  -ports 80,443,8080,8443,3000,5000,8000,8008,8088,8888 \
  -threads 200 -timeout 10 -retries 2 \
  -o recon/httpx_live.txt
```

## Extraction per Host (for surface.json)

| Field | Source | Why It Matters |
|-------|--------|----------------|
| `status_code` | httpx | 200/301/401/403 determine attack surface; 403 → bypass targets |
| `tech` | tech-detect | Framework hints: Express/Django/Rails/Spring/Next.js → stack-specific bug classes |
| `content_type` | content-type | JSON/XML endpoints → injection/XXE/SSRF signals |
| `webserver` | web-server | nginx/Apache/haproxy → desync signals; IIS → ViewState/padding oracle |
| `title` | title | Default pages (Welcome to nginx, Apache2) → low value |
| `location` | location | Redirect chains → open redirect / OAuth bypass |
| `headers` | -headers | Security headers (CSP, HSTS, X-Frame) → bypass context |
| `csp` | -csp | CSP policy → XSS bypass difficulty |

## Stack → Primary Bug Class Map

| Tech Signal | Hunt First | Hunt Second |
|-------------|------------|-------------|
| Ruby on Rails | Mass assignment | IDOR (`:id` routes) |
| Django | IDOR (ModelViewSet) | SSTI (mark_safe) |
| Flask | SSTI (render_template_string) | SSRF (requests lib) |
| Laravel | Mass assignment ($fillable) | IDOR (Eloquent) |
| Express/Node.js | Prototype pollution | Debug endpoints (`/_debug`, `/__debug__`) |
| Spring Boot | Actuator endpoints (`/actuator/*`) | SSTI (Thymeleaf) |
| ASP.NET | ViewState deserialization | Open redirect (ReturnUrl) |
| Next.js | SSRF via Server Actions | Debug data (`/_next/data/`, `/_next/static/chunks/`) |
| GraphQL | Introspection → auth bypass | IDOR via `node(id:)` |
| WordPress | Plugin SQLi | REST API auth bypass |

## 403/401 Bypass Candidates
- Status 403: header injection (`X-Forwarded-For`, `X-Original-URL`, `X-Rewrite-URL`), method swap, path encoding
- Status 401: JWT none/alg confusion, missing PKCE, auth bypass on sibling endpoints

## Output
Write parsed `httpx.json` to `recon/surface.json` with normalized structure:
```json
{
  "hosts": [
    {
      "url": "https://api.target.com",
      "status": 200,
      "tech": ["Express", "Node.js"],
      "content_type": "application/json",
      "webserver": "nginx",
      "signals": ["json_api", "potential_idor", "potential_pp"]
    }
  ]
}
```