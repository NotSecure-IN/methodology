# Subdomain Deep Mapping

## Input Parsing

User provides target as:
```
https://www.notsecure.in/vdp
```

Parse to extract:
```bash
# Extract root domain from VDP URL
INPUT="https://www.notsecure.in/vdp"
ROOT_DOMAIN=$(echo "$INPUT" | sed -E 's|https?://||' | cut -d'/' -f1 | sed -E 's|^www\.||')
# Result: notsecure.in

# Derive program name from domain or GitHub
PROGRAM_NAME="NotSecure-IN"
VDP_URL="$INPUT"
GITHUB_ORG="NotSecure-IN"
```

## Scope Definition (from program page)

```bash
# In-scope (wildcards)
*.notsecure.in
*.notsec.in
*.notsecure.com

# Out-of-scope
dev.notsecure.in

# GitHub org for source code recon
github.com/NotSecure-IN/
```

Store in `scope.md` and `scope.sqlite`.

---

## Tools & Commands

### Passive Enumeration (Maximum Coverage)

```bash
TARGET="notsecure.in"
SUBDOMAINS_FILE="recon/subdomains.txt"
> "$SUBDOMAINS_FILE"

# 1. crt.sh - Certificate Transparency (no API key)
curl -s "https://crt.sh/?q=%.${TARGET}&output=json" \
  | jq -r '.[].name_value' \
  | sed 's/\*\.//g' \
  | sort -u >> "$SUBDOMAINS_FILE"

# 2. crt.sh alternative (crt.name)
curl -s "https://crt.name/v1/search?apex=${TARGET}" \
  | jq -r '.[]' | sort -u >> "$SUBDOMAINS_FILE"

# 3. Chaos API (ProjectDiscovery - best coverage, free tier)
curl -s "https://dns.projectdiscovery.io/dns/${TARGET}/subdomains" \
  -H "Authorization: ${CHAOS_API_KEY}" \
  | jq -r '.[]' >> "$SUBDOMAINS_FILE"

# 4. subfinder (multi-source passive)
subfinder -d ${TARGET} -silent | anew "$SUBDOMAINS_FILE"

# 5. subdominator (fast, rust-based)
subdominator -d ${TARGET} -silent | anew "$SUBDOMAINS_FILE"

# 6. assetfinder
assetfinder --subs-only ${TARGET} | anew "$SUBDOMAINS_FILE"

# 7. Wayback Machine / Archive.org
curl -s "http://web.archive.org/cdx/search/cdx?url=*.${TARGET}&output=txt&fl=original&collapse=urlkey" \
  | sed 's#https\?://##' | cut -d/ -f1 | sort -u >> "$SUBDOMAINS_FILE"

# 8. AnubisDB
curl -s "https://anubisdb.com/anubis/subdomains/${TARGET}" \
  | tr -d '[]" ' | tr ',' '\n' | sort -u >> "$SUBDOMAINS_FILE"

# 9. VirusTotal (requires API key)
curl -s -H "x-apikey: ${VT_API_KEY}" \
  "https://www.virustotal.com/api/v3/domains/${TARGET}/subdomains?limit=40" \
  | jq -r '.data[].id' | sort -u >> "$SUBDOMAINS_FILE"

# 10. ThreatCrowd
curl -s "https://www.threatcrowd.org/searchApi/v2/domain/report/?domain=${TARGET}" \
  | jq -r '.subdomains[]' | sort -u >> "$SUBDOMAINS_FILE"

# 11. GitHub source code recon (from github.com/NotSecure-IN/)
# Clone or search repos for subdomain references
gh repo list NotSecure-IN --limit 100 --json nameWithOwner -q '.[].nameWithOwner' | while read repo; do
    gh api repos/$repo/contents --jq '.[] | select(.name | endswith(".js") or endswith(".json") or endswith(".yaml") or endswith(".yml")) | .download_url' | xargs -I {} curl -s {} | grep -oE '[a-zA-Z0-9.-]+\.notsecure\.(in|com)' | anew "$SUBDOMAINS_FILE"
done

# Deduplicate
sort -u "$SUBDOMAINS_FILE" -o "$SUBDOMAINS_FILE"
SUBCOUNT=$(wc -l < "$SUBDOMAINS_FILE")
echo "[+] Total unique subdomains: $SUBCOUNT"

# Store in SQLite
sqlite3 recon/scope.sqlite "INSERT OR IGNORE INTO subdomains (target_id, subdomain, source) 
SELECT id, '$sub', 'subfinder' FROM targets WHERE root_domain='$TARGET';" # repeat for each source
```

---

## Scope Filtering (Critical)

After enumeration, filter subdomains against scope:

```bash
# Load in-scope patterns from SQLite
IN_SCOPE=$(sqlite3 recon/scope.sqlite "SELECT pattern FROM scope_in WHERE target_id=(SELECT id FROM targets WHERE root_domain='$TARGET');")
OUT_SCOPE=$(sqlite3 recon/scope.sqlite "SELECT pattern FROM scope_out WHERE target_id=(SELECT id FROM targets WHERE root_domain='$TARGET');")

# Filter subdomains
# 1. Must match at least one in-scope pattern
# 2. Must NOT match any out-of-scope pattern

# Convert wildcards to regex
# *.notsecure.in → ^[^.]+\.notsecure\.in$
# Exact domains pass through

python3 << 'EOF'
import re, sqlite3, sys

db = "recon/scope.sqlite"
conn = sqlite3.connect(db)
c = conn.cursor()
target_id = c.execute("SELECT id FROM targets WHERE root_domain=?", ("notsecure.in",)).fetchone()[0]

in_patterns = [row[0] for row in c.execute("SELECT pattern FROM scope_in WHERE target_id=?", (target_id,))]
out_patterns = [row[0] for row in c.execute("SELECT pattern FROM scope_out WHERE target_id=?", (target_id,))]

def wildcard_to_regex(pattern):
    return '^' + pattern.replace('.', r'\.').replace('*', '[^.]+') + '$'

in_regexes = [wildcard_to_regex(p) for p in in_patterns]
out_regexes = [wildcard_to_regex(p) for p in out_patterns]

def in_scope(sub):
    return any(re.match(r, sub) for r in in_regexes) and not any(re.match(r, sub) for r in out_regexes)

with open("recon/subdomains.txt") as f:
    for line in f:
        sub = line.strip()
        if in_scope(sub):
            print(sub)
EOF
> recon/subdomains_in_scope.txt
```

---

## DNS Resolution + CNAME Chains (Bug Bounty Optimized)

### Step 1: Fresh Resolvers for Maximum Coverage

```bash
# Download fresh resolvers
wget -q -O resolvers.txt https://raw.githubusercontent.com/trickest/resolvers/main/resolvers.txt

# Test and filter fast resolvers (remove localhost)
massdns -r resolvers.txt -t A ${TARGET} -o S -w fast_resolvers.txt 2>/dev/null
cat fast_resolvers.txt | grep -v "127.0.0.1" | head -2000 > resolvers_fresh.txt
```

### Step 2: Multi-Stage DNS Resolution

```bash
# High-throughput resolution with puredns
puredns resolve recon/subdomains_in_scope.txt -r resolvers_fresh.txt -w recon/resolved_temp.txt --rate-limit 2000 --bin massdns
cat recon/resolved_temp.txt | sort -u > recon/resolved.txt

# Store resolved in SQLite
while read sub; do
    sqlite3 recon/scope.sqlite "INSERT OR IGNORE INTO dns_records (subdomain_id, record_type, value)
    SELECT id, 'A', '$sub' FROM subdomains WHERE subdomain='$sub' AND target_id=(SELECT id FROM targets WHERE root_domain='$TARGET');"
done < recon/resolved.txt
```

### Step 3: Multi-Threaded CNAME Extraction

```bash
# Detailed CNAME records with response
dnsx -l recon/resolved.txt -cname -resp -silent -r resolvers_fresh.txt -threads 200 -o recon/cname_detailed.txt

# Quick CNAME extraction for verification
dnsx -l recon/resolved.txt -cname -resp -silent -o recon/cname_records.txt

# Parse CNAME chains and store in SQLite
python3 << 'EOF'
import sqlite3, re

db = "recon/scope.sqlite"
conn = sqlite3.connect(db)
c = conn.cursor()
target_id = c.execute("SELECT id FROM targets WHERE root_domain=?", ("notsecure.in",)).fetchone()[0]

with open("recon/cname_detailed.txt") as f:
    for line in f:
        parts = line.strip().split()
        if len(parts) >= 3 and parts[1] == "CNAME":
            subdomain = parts[0]
            cname_target = parts[2].rstrip('.')
            
            # Get subdomain_id
            sub_id = c.execute("SELECT id FROM subdomains WHERE target_id=? AND subdomain=?", (target_id, subdomain)).fetchone()
            if sub_id:
                sub_id = sub_id[0]
                
                # Detect provider
                provider = "unknown"
                takeover_candidate = 0
                fingerprint = ""
                
                if "s3.amazonaws.com" in cname_target:
                    provider = "aws_s3"
                    takeover_candidate = 1
                    fingerprint = "The specified bucket does not exist"
                elif "github.io" in cname_target:
                    provider = "github_pages"
                    takeover_candidate = 1
                    fingerprint = "There isn't a GitHub Pages site here."
                elif "azurewebsites.net" in cname_target:
                    provider = "azure"
                    takeover_candidate = 1
                    fingerprint = "The app you are looking for is not found"
                elif "herokuapp.com" in cname_target:
                    provider = "heroku"
                    takeover_candidate = 1
                    fingerprint = "No such app"
                elif "netlify.app" in cname_target or "netlify.com" in cname_target:
                    provider = "netlify"
                    takeover_candidate = 1
                    fingerprint = "Not Found - Request ID:"
                elif "vercel.app" in cname_target or "vercel.com" in cname_target:
                    provider = "vercel"
                    takeover_candidate = 1
                    fingerprint = "DEPLOYMENT_NOT_FOUND."
                # Add more providers...
                
                c.execute("""INSERT OR REPLACE INTO cname_chains 
                    (subdomain_id, cname_target, chain_depth, is_dangling, provider, takeover_candidate, fingerprint)
                    VALUES (?, ?, 1, 0, ?, ?, ?)""",
                    (sub_id, cname_target, provider, takeover_candidate, fingerprint))
                conn.commit()
EOF
```

### Step 4: Advanced HTTP Discovery

```bash
# Bug bounty focused: multiple ports, CDN detection, redirects
cat recon/resolved.txt | httpx -silent -status-code -title -tech-detect -cdn -follow-redirects \
  -ports 80,443,8080,8443,3000,5000,8000,8008,8088,8888 \
  -threads 200 -timeout 10 -retries 2 -o recon/httpx_live.txt

# Extract URLs
cat recon/httpx_live.txt | awk '{print $1}' > recon/httpx_urls.txt

# Store in SQLite
while read line; do
    url=$(echo "$line" | awk '{print $1}')
    status=$(echo "$line" | awk '{print $2}')
    title=$(echo "$line" | cut -d' ' -f3- | sed 's/\[.*\]//')
    tech=$(echo "$line" | grep -oE '\[.*\]' | tr '\n' ',' | sed 's/,$//')
    webserver=$(echo "$line" | grep -oE 'Server: [^ ]+' | cut -d' ' -f2)
    cdn=$(echo "$line" | grep -oE 'CDN: [^ ]+' | cut -d' ' -f2)
    
    subdomain=$(echo "$url" | sed -E 's|https?://||' | cut -d'/' -f1)
    sub_id=$(sqlite3 recon/scope.sqlite "SELECT id FROM subdomains WHERE target_id=(SELECT id FROM targets WHERE root_domain='$TARGET') AND subdomain='$subdomain';")
    
    if [[ -n "$sub_id" ]]; then
        sqlite3 recon/scope.sqlite "INSERT INTO http_services (subdomain_id, url, status_code, title, tech, webserver, cdn)
        VALUES ($sub_id, '$url', $status, '$title', '$tech', '$webserver', '$cdn');"
    fi
done < recon/httpx_live.txt
```

### Step 5: Wildcard Detection + Filtering

```bash
# Detect wildcard DNS
dnsx -l recon/subdomains.txt -wildcard -silent -r resolvers_fresh.txt | tee recon/wildcards.txt

# Filter: only test resolved IPs that differ from wildcard IP
```

---

## Signals to Record in surface.json & SQLite

| Signal | Action | SQLite Table |
|--------|--------|--------------|
| CNAME → S3/GitHub Pages/Heroku/Fastly/Zendesk/Shopify/Azure | Subdomain takeover candidate | `cname_chains` (takeover_candidate=1) |
| Wildcard DNS (`*.target.com`) | Filter noise: only test resolved IPs that differ from wildcard IP | `dns_records` |
| Multiple A records | Load balancer → test HTTP desync (CL.TE/TE.CL) | `dns_records` |
| CNAME → internal domain | Potential SSRF pivot via internal hostname | `cname_chains` |
| Subdomain with `dev|staging|test|admin|internal` | High-value target — prioritize | `subdomains` (flag in notes) |
| HTTP service with interesting tech | Map to bug classes via Router | `http_services` |

---

## Subfinder Config (for better coverage)

```yaml
# ~/.config/subfinder/config.yaml
virustotal: ["YOUR_VT_KEY"]
securitytrails: ["YOUR_ST_KEY"]
censys_apiid: "YOUR_CENSYS_ID"
censys_secret: "YOUR_CENSYS_SECRET"
shodan: ["YOUR_SHODAN_KEY"]
```

---

## Database Maintenance

```bash
# Backup database
cp recon/scope.sqlite recon/scope.sqlite.backup.$(date +%s)

# Vacuum for performance
sqlite3 recon/scope.sqlite "VACUUM;"

# Export for reporting
sqlite3 recon/scope.sqlite ".dump" > recon/scope_dump.sql

# Query examples
sqlite3 recon/scope.sqlite "SELECT subdomain, cname_target, provider FROM cname_chains WHERE takeover_candidate=1;"
sqlite3 recon/scope.sqlite "SELECT url, status_code, tech FROM http_services WHERE status_code=200;"
sqlite3 recon/scope.sqlite "SELECT pattern FROM scope_in UNION SELECT pattern FROM scope_out;"
```