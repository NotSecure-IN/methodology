# Content Discovery & Parameter Mining (via Caido Proxy)

## Prerequisites
Caido must be running headless on `http://localhost:8080`.

## Crawl (katana via Caido)

```bash
# Standard crawl with JS parsing via Caido
cat recon/httpx_urls.txt | katana -d 3 -jc -kf all -silent \
  -proxy "http://localhost:8080" \
  -o recon/urls.txt

# Aggressive: form submission, deeper
katana -list recon/httpx_urls.txt -d 5 -jc -f qp -kf all -silent \
  -proxy "http://localhost:8080" \
  -o recon/urls.txt
```

## Historical URLs (via Caido)

```bash
# gau (GetAllUrls) - faster, includes subdomains via Caido
gau ${TARGET} --subs --proxy "http://localhost:8080" | anew recon/urls.txt

# gauplus (if available) - more sources
gauplus -d ${TARGET} -subs --proxy "http://localhost:8080" -o recon/gauplus.txt
cat recon/gauplus.txt | anew recon/urls.txt

# Wayback Machine (direct - no proxy needed for archive.org)
echo ${TARGET} | waybackurls | anew recon/urls.txt
```

## Parameter Mining (arjun)

```bash
# From URL list
arjun -i recon/urls.txt -oT recon/params.txt -t 20 --rate-limit 50

# Single target deep
arjun -u "https://target.com/api" -m GET POST -oT recon/api-params.txt
```

## Classification with gf (tomnomnom/gf)

```bash
# Install: go install github.com/tomnomnom/gf@latest
# Patterns: ~/.gf/*.json

cat recon/urls.txt | gf xss         | tee recon/xss-candidates.txt
cat recon/urls.txt | gf ssrf        | tee recon/ssrf-candidates.txt
cat recon/urls.txt | gf idor        | tee recon/idor-candidates.txt
cat recon/urls.txt | gf sqli        | tee recon/sqli-candidates.txt
cat recon/urls.txt | gf redirect    | tee recon/redirect-candidates.txt
cat recon/urls.txt | gf lfi         | tee recon/lfi-candidates.txt
cat recon/urls.txt | gf rce         | tee recon/rce-candidates.txt
cat recon/urls.txt | gf ssti        | tee recon/ssti-candidates.txt
cat recon/urls.txt | gf debug_logic | tee recon/debug-candidates.txt
cat recon/urls.txt | gf secrets     | tee recon/secrets-candidates.txt
cat recon/urls.txt | gf upload-fields | tee recon/upload-candidates.txt
cat recon/urls.txt | gf cors        | tee recon/cors-candidates.txt
```

## Manual Grep for High-Value Patterns

```bash
# API endpoints
grep -E "/api/|/v1/|/v2/|/v3/|/graphql|/rest/|/gql" recon/urls.txt | tee recon/api-endpoints.txt

# File upload
grep -E "upload|file|attachment|document|image|avatar|photo|media" recon/urls.txt | tee recon/uploads.txt

# Admin/internal
grep -E "/admin|/internal|/debug|/test|/staging|/dev|/management|/console" recon/urls.txt | tee recon/admin-paths.txt

# Auth endpoints
grep -E "/oauth|/login|/auth|/sso|/saml|/oidc|/callback|/token" recon/urls.txt | tee recon/auth-paths.txt

# User-controlled CSS surface (CSS injection)
grep -iE "theme|profile|signature|customize|email|invoice|pdf|render|markdown" recon/urls.txt | tee recon/css-injection-candidates.txt

# Parameters worth testing
grep -E "[?&](id|user|file|path|url|redirect|next|src|token|key|api_key|user_id|order_id|account_id)=" recon/urls.txt | tee recon/interesting-params.txt
```

## Output for surface.json

Add to each host in surface.json:
```json
{
  "endpoints": [
    {"url": "https://api.target.com/users/123", "params": ["id"], "class": "idor"},
    {"url": "https://target.com/upload", "params": ["file"], "class": "upload"}
  ],
  "api_endpoints": [...],
  "interesting_params": [...]
}
```