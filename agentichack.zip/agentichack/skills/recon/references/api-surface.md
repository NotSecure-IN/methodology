# API Surface Mapping (via Caido Proxy)

## Prerequisites
Caido must be running headless on `http://localhost:8080`.

## GraphQL (via Caido)

### Introspection (if enabled)
```bash
# Query via Caido proxy
curl -x "http://localhost:8080" -s -X POST "https://target.com/graphql" \
  -H "Content-Type: application/json" \
  -d '{"query": "{ __schema { types { name fields { name type { name } } } } }"}'
```

### Test Even If Introspection Disabled
- Common operation names: `query`, `mutation`, `me`, `user`, `users`, `admin`, `login`, `register`
- Field guessing: `id`, `email`, `password`, `role`, `isAdmin`, `token`, `secret`

### GraphQL-Specific Signals
| Signal | Finding |
|--------|---------|
| `__schema` query works | Introspection enabled → Info (chain required) |
| `node(id: "base64")` resolves | IDOR via node() → High if cross-user |
| Batch queries accepted | Rate limit bypass for OTP/brute force |
| Field-level auth missing | Mass assignment via GraphQL mutations |

## REST API Discovery (via Caido)

```bash
# Version enumeration via Caido
for v in v1 v2 v3 v4 api; do
  curl -x "http://localhost:8080" -s -o /dev/null -w "%{http_code} /$v\n" "https://target.com/$v/users"
done

# Swagger/OpenAPI via Caido
curl -x "http://localhost:8080" -s "https://target.com/swagger.json" | jq .
curl -x "http://localhost:8080" -s "https://target.com/openapi.json" | jq .
curl -x "http://localhost:8080" -s "https://target.com/api-docs" | jq .
curl -x "http://localhost:8080" -s "https://target.com/api/swagger.json" | jq .

# Common paths via Caido
for p in /api /api/v1 /api/v2 /rest /gql /graphql; do
  curl -x "http://localhost:8080" -s -o /dev/null -w "%{http_code} $p\n" "https://target.com$p"
done
```

## Mass Assignment Parameter Discovery

```bash
# From JS analysis / source / Swagger
# Test these params on every PUT/PATCH/POST via Caido:
# role, isAdmin, admin, isOwner, plan, credit, verified, email_verified
# balance, permissions, group_id, subscription_tier, status, is_active
# user_type, account_type, privilege, access_level, tenant_id, org_id
```

## API-Specific Signals for surface.json

```json
{
  "api": {
    "graphql": {
      "introspection": true,
      "node_idor": true,
      "batch_allowed": true
    },
    "rest": {
      "versions": ["v1", "v2"],
      "swagger": true,
      "mass_assignment_params": ["role", "isAdmin", "plan"]
    }
  }
}
```

## Test Checklist per API Endpoint

- [ ] IDOR (numeric/UUID swap, method swap, version diff)
- [ ] Mass assignment (add `role: admin` to body)
- [ ] Auth bypass (remove token, try sibling endpoints)
- [ ] Rate limit (OTP, login, password reset)
- [ ] SQLi/NoSQLi (error, boolean, time-based)
- [ ] SSRF (webhook, url, avatar_url params)
- [ ] XXE (XML content-type)
- [ ] Prototype pollution (`__proto__`, `constructor.prototype`)