# Pre-Submit Checklist (60 Seconds)

```
[ ] Q1–Q7 all YES
[ ] Q8 identity check complete (if auth-related)
[ ] Not on always-rejected list
[ ] Chain requirement satisfied (if applicable)
[ ] Raw HTTP request + response saved
[ ] CVSS vector written
[ ] Impact is one sentence, no jargon
[ ] Title follows formula: [Class] in [endpoint] allows [actor] to [impact]
[ ] Steps to Reproduce: copy-pasteable HTTP request
[ ] Evidence: screenshot/video of actual impact (not just 200 status)
[ ] Severity matches CVSS AND program's severity definitions
[ ] Remediation: 1-2 sentences of concrete fix
[ ] NEVER used "could potentially" or "may allow"
[ ] Deduplication check: searched Hacktivity, GitHub issues, changelog
[ ] Report < 600 words — triagers skim long reports
```