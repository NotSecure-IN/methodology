# 7-Question Gate

Answer sequentially. Any **NO** → **KILL**.

| # | Question | If NO |
|---|---|---|
| Q1 | Can an attacker use this **right now** with a real HTTP request (or browser action for client-side)? | KILL |
| Q2 | Is the impact on the program's accepted list? | KILL |
| Q3 | Is the root cause in an in-scope production asset? | KILL |
| Q4 | Is it reproducible? (same result on second run) | KILL |
| Q5 | Is it a duplicate? | KILL |
| Q6 | Is there impact **without a chain**? | DOWNGRADE / check `chain-table.md` |
| Q7 | Is evidence (request + response / browser proof) saved? | KILL |

**Hard rule:** If Q1 cannot produce a raw HTTP request (or browser proof for client-side), the finding dies here.

**Client-side note:** For tabnabbing/reverse tabnabbing, Q1 = "Can attacker cause victim to open link and navigate opener?" Evidence = Playwright proof + navigation marker.

**Desync note:** For HTTP desync, Q1 = "Can attacker send crafted HTTP request that causes request smuggling?" Evidence = Turbo Intruder timing logs + differential response analysis.

**Cache Poisoning note:** For WCP/WCD, Q1 = "Can attacker cause cache to store and serve malicious/sensitive response?" Evidence = clean retrieval request returning poisoned/deceptive content + cross-session proof.

**Prototype Pollution note:** For Prototype Pollution, Q1 = "Can attacker inject property into prototype via input?" Evidence = Playwright proof (client) or Turbo Intruder timing/differential analysis (server) showing polluted prototype.

---

## Identity Check (Q8) — Mandatory for Auth-Related Findings

For any finding made under an authenticated hunt:

```
1. Session ID:        [session hash from audit.jsonl]
2. Identity:          [low-priv user A / high-priv user B / API key / etc.]
3. Anonymous repro:   Does the same request work with NO auth header?
4. Cross-identity:    Does it work under session B with the same data scope?
5. Stale-cred repro:  Does a logged-out / expired session still get the data?
```

**If you cannot answer → treat as unproven. Blank answers auto-fail on auth-related findings.**

**Tabnabbing note:** For reverse tabnabbing, identity check = victim must be authenticated in opener tab for phishing impact.