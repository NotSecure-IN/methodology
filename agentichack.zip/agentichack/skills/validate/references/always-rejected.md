# Always Rejected (Never Submit)

Submitting these destroys your validity ratio. N/A hurts. Don't.

```
Missing CSP / HSTS / X-Frame-Options / other security headers
Missing SPF / DKIM / DMARC
GraphQL introspection alone (no auth bypass, no IDOR)
Banner / version disclosure without a working CVE exploit
Clickjacking on non-sensitive pages (no sensitive action in PoC)
Traditional tabnabbing without proof of exploitability
Reverse tabnabbing without proof of navigation capability
Missing noopener without proof of opener relationship
JSON body accepts `__proto__` without proof of pollution
Query string accepts `__proto__` without proof of pollution
URL fragment accepts `__proto__` without proof of pollution
postMessage accepts `__proto__` without proof of pollution
File upload accepts `__proto__` without proof of pollution
GraphQL accepts `__proto__` without proof of pollution
CSV injection (no actual code execution shown)
CORS wildcard (*) without credential exfil PoC
Logout CSRF
Self-XSS (only exploits own account)
Open redirect alone (no ATO chain, no OAuth code theft)
OAuth client_secret in mobile app (disclosed, expected)
SSRF with DNS callback only (no internal service access)
Host header injection alone (no password reset poisoning PoC)
Rate limit on non-critical forms (login page Cloudflare, search, contact)
Session not invalidated on logout
Concurrent sessions allowed
Internal IP address in error message
Mixed content (HTTP resources on HTTPS page)
SSL weak cipher suites
Missing HttpOnly / Secure cookie flags alone
Broken external links
Pre-account takeover (usually — requires very specific conditions)
Autocomplete on password fields
```