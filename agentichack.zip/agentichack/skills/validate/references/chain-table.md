# Chain Requirement Table

| Finding | Valid Alone? | Chain Required |
|---|---|---|
| Reflected XSS | Yes (if session-impacting) | No |
| Open Redirect | No | Yes → XSS/OAuth token theft |
| CORS misconfig | No | Yes → data exfiltration |
| CSRF | Yes (if state-changing) | No |
| Info leak | No | Yes → credential/host discovery |
| Clickjacking | No | Yes → sensitive action + PoC |
| SSRF (DNS only) | No | Yes → internal service access |
| Host header injection | No | Yes → password reset poisoning |
| Prompt injection | No | Yes → IDOR/exfil/RCE |
| S3 bucket listing | No | Yes → live API keys in JS |
| Self-XSS | No | Yes → CSRF to trigger on victim |
| Subdomain takeover | No | Yes → OAuth redirect_uri registered |
| GraphQL introspection | No | Yes → auth bypass / IDOR on node() |
| Rate limit bypass | No | Yes → OTP/reset token brute success |
| Reflected XSS on logout | No | Yes → CSRF on victim's active session |
| HTTP Desync (CL.TE/TE.CL) | Yes (request capture) | No → but chain with cache poisoning/XSS for Critical |
| Reverse Tabnabbing | Yes (if phishing) | No → but chain with phishing/XSS for higher impact |
| Traditional Tabnabbing | No | Yes → phishing/session hijack |
| Cache Poisoning (WCP) | Yes (stored XSS/redirect) | No → but chain with XSS/redirect for Critical |
| Cache Deception (WCD) | Yes (data exposure) | No → but chain with CSRF/API for High |
| Cache-Key Injection | Yes (ACL bypass) | No → chain with CPDoS/XSS for Critical |
| CPDoS | Yes (availability) | No → chain with DoS for High |
| Prototype Pollution (Client) | Yes (DOM XSS) | No → chain with XSS/Redirect for Critical |
| Prototype Pollution (Server) | Yes (JSON spaces/Status) | No → chain with RCE/XSS for Critical |