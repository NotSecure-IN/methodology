# Header Injection

## Vectors
- `Host` header manipulation
- `X-Forwarded-Host`, `X-Original-URL`, `X-Rewrite-URL`
- CRLF: `%0d%0a` in any header value

## Confirmation
Inject `X-Forwarded-Host: canary.com` → check if reflected in redirect/email link.
CRLF: inject `%0d%0aSet-Cookie:nsproof=1` → check for injected header.
