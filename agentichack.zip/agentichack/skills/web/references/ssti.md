# SSTI

## Fingerprint
Polyglot: `${{<%[%'"}}%\` → look for template error.
Engine-specific: `{{7*7}}` (Twig/Jinja), `${7*7}` (Freemarker), `<%= 7*7 %>` (ERB).

## Confirmation
Evaluated result (`49`) in response = confirmed.
Escalate to RCE only if sandbox escape is proven with a benign command (`id`).
