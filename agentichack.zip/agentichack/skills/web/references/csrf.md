# CSRF

## Confirmation
1. Identify state-changing request.
2. Remove CSRF token, replay with victim session cookie.
3. If action succeeds → **CSRF confirmed**.
4. Test `SameSite=None` cookies and JSON content-type CSRF.
