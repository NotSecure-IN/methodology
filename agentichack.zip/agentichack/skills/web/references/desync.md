# HTTP Desync

## Confirmation (Timing, Safe First)
1. Baseline: send normal request, record response time.
2. CL.TE probe: `Content-Length` valid, `Transfer-Encoding: chunked` with incomplete chunk.
3. If back-end hangs waiting for next chunk → response delayed seconds → **CL.TE candidate**.
4. Reverse roles for TE.CL.
5. **Confirmed** only if differential reproduces and baseline control stays fast.

## Do Not
- Do not smuggle into other users' requests.
- Do not claim desync from a single slow response — baseline must be fast.
