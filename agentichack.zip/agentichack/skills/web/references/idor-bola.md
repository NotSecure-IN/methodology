# IDOR / BOLA

## Confirmation
1. Create two accounts (A and B).
2. As A, request resource belonging to B (`/user/B/email`, `{"id":B}`).
3. If B's data returned → **IDOR confirmed**.
4. For BOLA: test sibling endpoints (`/api/v1/user` vs `/api/v1/admin`).
