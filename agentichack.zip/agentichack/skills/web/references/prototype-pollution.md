# Prototype Pollution

## Server-Side Detection Oracle (Benign)
Inject `{"__proto__":{"json spaces":10}}` into JSON body.
Then make a **fresh** request to a JSON endpoint.
If response JSON becomes indented → **pollution confirmed**.

Alternative oracles: `status` code override, `charset` override, `exposedHeaders`.
Note: `json spaces` patched in Express 4.18.0+; prefer status/header oracles on newer stacks.

## Client-Side Detection
In page context after candidate injection:

```js
Object.prototype.polluted === 'NSPROOF'
```

If true → client-side PP confirmed.

## Gadget Hunting
Only after pollution is confirmed via oracle. Trace polluted property to sink
(`innerHTML`, `script.src`, `document.location`).
