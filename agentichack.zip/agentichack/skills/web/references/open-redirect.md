# Open Redirect

## Confirmation
Inject external URL (`https://evil.com`) into redirect parameter.
Check `Location` header in response.
Bypass: `//evil.com`, `https:evil.com`, `\/\/evil.com`.
