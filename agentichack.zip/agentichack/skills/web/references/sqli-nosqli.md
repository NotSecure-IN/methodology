# SQLi / NoSQLi

## SQLi Confirmation
- Error-based: inject `'` and look for DB error.
- Time-based: `'||pg_sleep(5)--` → response delay ≥5s vs baseline.
- Boolean: `' AND 1=1--` vs `' AND 1=2--` differential.

## NoSQLi Confirmation
JSON body: `{"$ne":null}`, `{"$regex":".*"}`, `{"$where":"sleep(5000)"}`.
Compare response against baseline.
