---
name: web
description: >
  Signal table for web vulnerability classes. Load only after recon is
  complete. Each row maps an observable signal to a plausible class, a
  one-line confirmation test, and the reference file to open.
license: MIT
compatibility: opencode>=1.5.0
metadata:
  framework: agentichack
  version: "1.0.0"
  tags: "agentichack,router,web,signal-table"
  allowed-tools: "read,skill"
---

# Web Signal Table

| # | Observable Signal | Plausible Class | One-line Test | Load |
|---|---|---|---|---|
| 1 | `Server: nginx` + conflicting CL/TE | Desync (CL.TE/TE.CL) | CL.TE timing probe: delayed response >5s vs baseline | `desync.md` |
| 2 | JSON body + JS has `merge`/`clone` | Server-side PP | `{"__proto__":{"json spaces":10}}` → JSON indented? | `prototype-pollution.md` |
| 3 | JS sink + user-controlled source | Client-side PP / DOM XSS | `Object.prototype.polluted` check in page | `prototype-pollution.md` |
| 4 | XML/SOAP content-type | XXE | External entity → OOB or file read canary | `xxe.md` |
| 5 | SVG/DOCX/XLSX/PPTX upload | XXE (File Upload) | Upload SVG/DOCX with external entity → OOB callback | `xxe.md` |
| 6 | SAML/XML endpoint | XXE (SAML) | SAML assertion with external entity → OOB callback | `xxe.md` |
| 7 | XML feed/sitemap import | XXE (Feed) | Import sitemap/RSS with external entity → OOB callback | `xxe.md` |
| 8 | XML config import | XXE (Config) | Import XML config with external entity → OOB callback | `xxe.md` |
| 9 | Error-based XXE | XXE (Error) | External entity in DOCTYPE → file content in error | `xxe.md` |
| 10 | XInclude processing | XXE (XInclude) | `xi:include` with external href → OOB callback | `xxe.md` |
| 11 | Parameter entity | XXE (Param) | Parameter entity `%remote;` → OOB callback | `xxe.md` |
| 12 | Blind XXE (OOB) | XXE (Blind) | Parameter entity `%remote;` → OOB DNS/HTTP callback | `xxe.md` |
| 13 | Error-based XXE | XXE (Error) | Entity in DOCTYPE → file content in error response | `xxe.md` |
| 14 | XInclude processing | XXE (XInclude) | `xi:include` with external href → OOB callback | `xxe.md` |
| 15 | Parameter entity | XXE (Param) | Parameter entity `%remote;` → OOB callback | `xxe.md` |
| 16 | Blind XXE (OOB) | XXE (Blind) | Parameter entity `%remote;` → OOB DNS/HTTP callback | `xxe.md` |
| 17 | Error-based XXE | XXE (Error) | Entity in DOCTYPE → file content in error response | `xxe.md` |
| 5 | Reflected param unencoded | XSS | Unique canary → unencoded echo | `xss.md` |
| 6 | DB error / boolean diff / time delay | SQLi/NoSQLi | Error probe or time diff ≥5s with baseline | `sqli-nosqli.md` |
| 7 | Input in template (`{{7*7}}`) | SSTI | Polyglot → `49` evaluation | `ssti.md` |
| 8 | `X-Forwarded-Host` reflected | Header Injection | CRLF `%0d%0a` → response splitting | `header-injection.md` |
| 9 | ACAO reflects Origin | CORS misconfig | Arbitrary Origin + credentials → leak test | `cors.md` |
| 10 | Object ID in path/JSON | IDOR/BOLA | Second session ID swap → cross-user data | `idor-bola.md` |
| 11 | State change no CSRF token | CSRF | Cross-origin form/fetch | `csrf.md` |
| 12 | `?next=`/`?redirect=` | Open Redirect | External URL → `Location` check | `open-redirect.md` |
| 13 | `target="_blank"` without `rel="noopener"` | Tabnabbing / Reverse Tabnabbing | Playwright: `window.opener !== null` + navigation test | `tabnabbing.md` |
| 14 | `window.open()` without `noopener` | Tabnabbing / Reverse Tabnabbing | Playwright: popup opener check + navigation | `tabnabbing.md` |
| 15 | User-controlled external links in UGC | Tabnabbing / Reverse Tabnabbing | Input-to-sink trace + Playwright validation | `tabnabbing.md` |
| 16 | Header reflected unkeyed (X-Forwarded-Host, etc.) | Cache Poisoning | Param Miner: unkeyed header → clean retrieval | `cache-poisoning.md` |
| 17 | Query param ignored by cache (utm_, fbclid, etc.) | Cache Poisoning | WCVS: ignored param + clean retrieval | `cache-poisoning.md` |
| 18 | Static extension on dynamic route (.css, .js) | Cache Deception | WCD: auth baseline + static suffix + unauth retrieval | `cache-poisoning.md` |
| 19 | Path delimiter discrepancy (; ? # %00) | Cache Deception | Cache static vs origin dynamic | `cache-poisoning.md` |
| 20 | Path normalization discrepancy (../ %2f %2e) | Cache Deception | Cache static vs origin dynamic | `cache-poisoning.md` |
| 21 | Cache key collision (underscore, &, :) | Cache-Key Injection | Two requests → same key + different origin | `cache-poisoning.md` |
| 22 | Fat GET / Method Override ignored by cache | Cache Poisoning | Body/override on GET + cache key ignore | `cache-poisoning.md` |
| 23 | CORS Origin ignored by cache | Cache Poisoning | Origin reflected + cache ignores Origin | `cache-poisoning.md` |
| 24 | JSON body accepts `__proto__` / `constructor.prototype` | Prototype Pollution (Server) | `{"__proto__":{"json spaces":10}}` → indented JSON? | `prototype-pollution.md` |
| 25 | Query param `__proto__` / `constructor.prototype` accepted | Prototype Pollution (Server) | `?__proto__[polluted]=test` → pollutes Object.prototype? | `prototype-pollution.md` |
| 26 | URL fragment `__proto__` / `constructor.prototype` | Prototype Pollution (Client) | `#__proto__[polluted]=test` → pollutes Object.prototype? | `prototype-pollution.md` |
| 27 | `postMessage` with `__proto__` payload | Prototype Pollution (Client) | `postMessage({__proto__:{polluted:1}})` → pollutes? | `prototype-pollution.md` |
| 28 | File upload accepts YAML/JSON with `__proto__` | Prototype Pollution (Server) | Upload YAML with `__proto__` → pollutes? | `prototype-pollution.md` |
| 29 | GraphQL variables accept `__proto__` in nested objects | Prototype Pollution (Server) | GraphQL var with `__proto__` → pollutes? | `prototype-pollution.md` |
| 30 | JS sink + `__proto__` source (DOM XSS) | Prototype Pollution (Client) | `Object.prototype.polluted` check in page | `prototype-pollution.md` |
