# Broken Auth / Access Control 🔐

> #2 most paid class. The sibling function rule: if 9 endpoints have auth, the 10th that doesn't is your bug.
> **Needs auth loaded** — testing which sibling routes a logged-in user can reach that shouldn't be reachable.

## The Sibling Rule
```
/api/admin/users  → has auth middleware
/api/admin/export → often MISSING it
/api/admin/delete → often MISSING it
/api/admin/reset  → often MISSING it
```

## Patterns
```javascript
// Missing middleware on sibling
router.get('/admin/users', authenticate, authorize('admin'), getUsers);
router.get('/admin/export', getExport);  // No middleware!

// Client-side role check only
if (user.role === 'admin') showAdminButton();
// Backend: app.post('/api/admin/delete', deleteUser); // no server check!
```

## Horizontal → Vertical Escalation
```
1. Find endpoint accessible by low-priv user
2. Test if it accepts privileged params (role, isAdmin, permissions)
3. Combine: low-priv user calls endpoint with admin params
```

## Testing Checklist
```
[ ] Map all endpoints per role (admin, user, guest)
[ ] Test sibling endpoints: /admin/*, /internal/*, /management/*
[ ] Test HTTP method variations on privileged endpoints
[ ] Check for client-side only authorization
[ ] Test parameter pollution for role escalation
[ ] Test old API versions (/v1/, /v2/)
```

## Real Paid Examples
- **HackerOne TrustHub**: `POST /graphql` with `TrustHubQuery` — no auth, regular user reads all vendors (CVSS 8.7 High)