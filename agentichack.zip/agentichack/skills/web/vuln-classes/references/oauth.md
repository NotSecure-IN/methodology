# OAuth / OIDC Bugs

## Missing PKCE (Coinbase Pattern)
```
Test: GET /oauth2/auth?...&client_id=X (without code_challenge parameter)
Result: If 302 redirect (not error) = PKCE not enforced
Impact: Auth code interception → ATO
```

## State Parameter Bypass (CSRF on OAuth)
```
Start OAuth → don't authorize → capture URL → send to victim
Victim authorizes → their auth code tied to YOUR session → ATO
```

## Open Redirect Bypass Techniques (for OAuth Chaining, 11 Techniques)

| Technique | Example | Why it works |
|---|---|---|
| @ symbol | `https://legit.com@evil.com` | Browser navigates to evil.com |
| Subdomain abuse | `https://legit.com.evil.com` | evil.com controls subdomain |
| Protocol tricks | `javascript:alert(1)` | XSS via redirect |
| Double encoding | `%252f%252fevil.com` | Decodes to `//evil.com` |
| Backslash | `https://legit.com\@evil.com` | Parsers normalize `\` to `/` |
| Protocol-relative | `//evil.com` | Uses current page's protocol |
| Null byte | `https://legit.com%00.evil.com` | Some parsers truncate at null |
| Unicode IDN | `https://legіt.com` (Cyrillic і) | Visually identical, different domain |
| Data URL | `data:text/html,<script>...` | Direct payload |
| Fragment abuse | `https://legit.com#@evil.com` | Inconsistent parsing |
| Redirect + OAuth | `target.com/callback?redirect_uri=..` | Redirect endpoint |

## Redirect_uri Validation Bypasses
```
1. Exact match bypass: register evil.com as redirect_uri if wildcard allowed
2. Path traversal: redirect_uri=https://target.com/../../evil.com
3. Subdomain takeover: takeover sub.target.com → register as redirect_uri
4. Open redirect on target.com → chain to OAuth code theft
```

## PKCE Downgrade
```
1. Start OAuth with PKCE (code_challenge)
2. Intercept auth code
3. Exchange without code_verifier (some servers accept)
4. If token issued → PKCE not enforced on token endpoint
```

## Testing Checklist
```
[ ] Test PKCE enforcement (start without code_challenge)
[ ] Test state parameter (missing, static, predictable)
[ ] Test redirect_uri validation (wildcard, subdomain, path traversal)
[ ] Test PKCE downgrade (exchange without verifier)
[ ] Test implicit/hybrid flow token leakage in URL fragment
[ ] Test refresh token rotation (reuse old refresh token)
```