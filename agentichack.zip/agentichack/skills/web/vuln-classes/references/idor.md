# IDOR — Insecure Direct Object Reference 🔐

> #1 most paid web2 class — 30% of all submissions that get paid.
> **Needs two sessions** (A=attacker, B=victim) — load both and diff audit-log `session_id` hashes to confirm cross-tenant access.

## Root Cause
```python
# VULNERABLE — no ownership check
@app.route('/api/orders/<order_id>')
def get_order(order_id):
    order = db.query("SELECT * FROM orders WHERE id = ?", order_id)
    return jsonify(order)

# SECURE
@app.route('/api/orders/<order_id>')
def get_order(order_id):
    order = db.query("SELECT * FROM orders WHERE id = ? AND user_id = ?",
                     order_id, current_user.id)
```

## Variants
| Variant | Description | Test |
|---------|-------------|------|
| V1: Numeric ID swap | `/api/user/123/profile` → change to 124 | Increment/decrement IDs |
| V2: UUID swap | Enumerate UUID via email invite/other endpoint | Find victim UUID, replay |
| V3: Indirect IDOR | `POST /api/export?report_id=456` exports other's report | Test all params accepting IDs |
| V4: Parameter add | `?user_id=other` makes backend use it | Add `user_id`, `account_id`, `org_id` |
| V5: HTTP method swap | PUT protected, DELETE not | Test GET/PUT/PATCH/DELETE on same path |
| V6: Old API version | `/v1/users/123` lacks auth that `/v2/` has | Test all API versions |
| V7: GraphQL node | `{ node(id: "base64(User:456)") { email } }` | Introspect → test node() |
| V8: WebSocket | WS sends `{"action":"get_history","userId":"UUID"}` | Intercept WS, modify userId |

## Testing Checklist
```
[ ] Two accounts (A=attacker, B=victim)
[ ] Log in as A, perform all actions, note all IDs
[ ] Replay A's requests with A's token but B's IDs
[ ] Test EVERY HTTP method (GET, PUT, DELETE, PATCH)
[ ] Check API v1 vs v2
[ ] Check GraphQL node() queries
[ ] Check WebSocket messages for client-supplied IDs
[ ] Test parameter pollution: add user_id/account_id to body
```

## IDOR Chain Escalation
| Chain | Result |
|-------|--------|
| IDOR + Read PII | Medium |
| IDOR + Write (modify other's data) | High |
| IDOR + Admin endpoint | Critical (privilege escalation) |
| IDOR + Account takeover path | Critical |
| IDOR + Chatbot reads other user's data | High |
| IDOR + Mass assignment | Critical (self-promote to admin) |

## Real Paid Examples
- **HackerOne TrustHub**: `POST /graphql` with `TrustHubQuery` — no auth, regular user reads all vendors (CVSS 8.7 High)
- **Vienna Chatbot**: WebSocket `get_history` accepts arbitrary UUID — no ownership check (P2)