# Subdomain Takeover — Definitive Advanced Methodology

> **Base payout**: $200–$3K | **Chain escalation**: $5K–$25K+ (cookies, OAuth, CSP, S3 secrets)
> **Sources**: [edoverflow/can-i-take-over-xyz](https://github.com/EdOverflow/can-i-take-over-xyz) (100+ services) + [haccer/subjack](https://github.com/haccer/subjack) (NS/A/MX/SRV/AXFR takeovers)

---

## Complete Provider Fingerprint Database (from can-i-take-over-xyz)

### Vulnerable Services (Verified)

| Service | CNAME Domains | Fingerprint (Regex) | Type | Notes |
|---------|---------------|---------------------|------|-------|
| **AWS/Elastic Beanstalk** | `elasticbeanstalk.com` | `NXDOMAIN` | DNS | Create EB env |
| **AWS/S3** | `s3.amazonaws.com` | `The specified bucket does not exist` | HTTP | Create bucket |
| **AWS/CloudFront** | — | `ViewerCertificateException` | — | **Not vulnerable** (use S3 instead) |
| **AWS/Load Balancer (ELB)** | `elb.amazonaws.com` | `NXDOMAIN` | DNS | **Not vulnerable** |
| **Microsoft Azure** | `cloudapp.net`, `cloudapp.azure.com`, `azurewebsites.net`, `blob.core.windows.net`, `azure-api.net`, `azurehdinsight.net`, `azureedge.net`, `azurecontainer.io`, `database.windows.net`, `azuredatalakestore.net`, `search.windows.net`, `azurecr.io`, `redis.cache.windows.net`, `servicebus.windows.net`, `visualstudio.com` | `NXDOMAIN` | DNS | Create App Service |
| **GitHub Pages** | — | `There isn't a GitHub Pages site here.` | HTTP | Edge case — needs repo + CNAME file |
| **GitLab Pages** | — | — | — | **Not vulnerable** |
| **Heroku** | — | `No such app` | HTTP | Edge case — create app |
| **Bitbucket** | `bitbucket.io` | `Repository not found` | HTTP | Create repo |
| **Netlify** | — | `Not Found - Request ID:` | HTTP | Edge case |
| **Vercel** | — | `DEPLOYMENT_NOT_FOUND.` | HTTP | Edge case |
| **Firebase** | — | — | — | **Not vulnerable** |
| **Surge.sh** | `na-west1.surge.sh` | `project not found` | HTTP | Create project |
| **Pantheon** | — | `404 error unknown site!` | HTTP | Create site |
| **Readme.io** | `readme.io` | `The creators of this project are still working on making everything perfect!` | HTTP | Create project |
| **Readthedocs** | — | `The link you have followed or the URL that you entered does not exist.` | HTTP | Create project |
| **Shopify** | — | `Sorry, this shop is currently unavailable.` | HTTP | Edge case |
| **WordPress.com** | `wordpress.com` | `Do you want to register .*\.wordpress.com\?` | HTTP | Register blog |
| **Strikingly** | `s.strikinglydns.com` | `PAGE NOT FOUND.` | HTTP | Create site |
| **Ghost** | `ghost.io` | `Site unavailable\|Failed to resolve DNS path for this host` | HTTP | Create site |
| **Tumblr** | — | `Whatever you were looking for doesn't currently exist at this address` | HTTP | Edge case |
| **Wix** | — | `Looks Like This Domain Isn't Connected To A Website Yet!` | HTTP | Edge case |
| **Webflow** | — | `The page you are looking for doesn't exist or has been moved.` | HTTP | Edge case |
| **Freshdesk** | — | `We couldn't find servicedesk.victim.tld` | HTTP | **Not vulnerable** |
| **Help Scout** | `helpscoutdocs.com` | `No settings were found for this company:` | HTTP | Create account |
| **Help Juice** | `helpjuice.com` | `We could not find what you're looking for.` | HTTP | Create account |
| **Helprace** | `helprace.com` | `HTTP_STATUS=301` | HTTP | Status 301 = vulnerable |
| **Zendesk** | — | `Help Center Closed` | HTTP | **Not vulnerable** |
| **Statuspage** | — | — | — | **Not vulnerable** (DNS verification required) |
| **Fastly** | — | `Fastly error: unknown domain:` | HTTP | **Not vulnerable** |
| **Intercom** | — | `Uh oh. That page doesn't exist.` | HTTP | Edge case |
| **Discourse** | `trydiscourse.com` | `NXDOMAIN` | DNS | Create instance |
| **Anima** | `animaapp.io` | `The page you were looking for does not exist.` | HTTP | Create project |
| **Cargo Collective** | — | `404 Not Found` | HTTP | Create project |
| **Campaign Monitor** | — | `Trying to access your account?` | HTTP | Create account |
| **Canny** | — | `Company Not Found\|There is no such company` | HTTP | Create account |
| **GetResponse** | — | `With GetResponse Landing Pages` | HTTP | Create account |
| **JetBrains/YouTrack** | `youtrack.cloud` | `is not a registered InCloud YouTrack` | HTTP | Create instance |
| **LaunchRock** | `launchrock.com` | `HTTP_STATUS=500` | HTTP | Status 500 = vulnerable |
| **Ngrok** | `ngrok.io` | `Tunnel .*\.ngrok.io not found` | HTTP | Create tunnel |
| **Uptimerobot** | `stats.uptimerobot.com` | `page not found` | HTTP | Create monitor |
| **SurveySparrow** | `surveysparrow.com` | `Account not found.` | HTTP | Create account |
| **Uberflip** | `read.uberflip.com` | `The URL you've accessed does not provide a hub.` | HTTP | Create hub |
| **SmartJobBoard** | `52.16.160.97` | `This job board website is either expired or its domain name is invalid.` | HTTP | Create board |
| **Short.io** | — | `Link does not exist` | HTTP | Create link |
| **HatenaBlog** | `hatenablog.com` | `404 Blog is not found` | HTTP | Create blog |
| **Agile CRM** | `agilecrm.com` | `Sorry, this page is no longer available.` | HTTP | Create account |
| **Airee.ru** | `airee.ru` | `Ошибка 402. Сервис Айри.рф не оплачен` | HTTP | Russian service |
| **Gemfury** | `furyns.com` | `404: This page could not be found.` | HTTP | Create repo |
| **Google Cloud Storage** | — | `<Code>NoSuchBucket</Code>` | HTTP/XML | **Not vulnerable** |
| **Google Sites** | — | `The requested URL was not found on this server` | HTTP | **Not vulnerable** |
| **Kinsta** | — | `No Site For Domain` | HTTP | **Not vulnerable** |
| **Digital Ocean** | — | `Domain uses DO name servers with no records in DO.` | DNS | Create DO record |
| **Worksites** | `worksites.net`, `69.164.223.206` | `Hello! Sorry, but the website you're looking for doesn't exist.` | HTTP | Create site |

### Non-Vulnerable / Edge Case Services (Do Not Waste Time)

| Service | Status | Reason |
|---------|--------|--------|
| Akamai, CloudFront, Key CDN | Not vulnerable | CDN only |
| Firebase, Instapage, Kinsta, SendGrid, Squarespace, Unbounce, WP Engine | Not vulnerable | No takeover path |
| GitLab, GitHub (mostly), Netlify, Vercel, Fastly, HubSpot | Edge case | Requires specific config |
| Intercom, Tumblr, Wix, Webflow, WordPress (org), Shopify, Statuspage, Zendesk, Freshdesk | Edge case / Not vulnerable | Verification / ownership required |

---

## Advanced Takeover Vectors (from subjack)

### 1. NS Delegation Takeover (`-ns` flag)
**Expired NS domains** — Register expired nameserver → full DNS control
**Dangling NS delegations** — NS records point to deleted cloud DNS zones

| Provider | NS Pattern |
|----------|------------|
| AWS Route 53 | `ns-*.awsdns-*` |
| Google Cloud DNS | `ns-cloud-*.googledomains.com` |
| Azure DNS | `ns*-*.azure-dns.*` |
| DigitalOcean | `ns*.digitalocean.com` |
| Vultr | `ns*.vultr.com` |
| Linode | `ns*.linode.com` |

```bash
subjack -w subdomains.txt -ns -o ns_takeovers.json
```

### 2. Stale A Record Takeover (`-ar` flag)
**A records pointing to released cloud IPs** — Spin up instance on same provider until IP match

| Provider | Detection |
|----------|-----------|
| AWS, GCP, Azure, DigitalOcean, Linode, Vultr, Oracle | ICMP/TCP check |

```bash
sudo subjack -w subdomains.txt -ar -o stale_a.json
```

### 3. Zone Transfer / AXFR (`-axfr` flag)
**Misconfigured nameservers** leaking entire zone + NS bruteforce (`ns1`, `ns2`, `dns-0`, `ns-backup`)

```bash
subjack -w subdomains.txt -axfr -o axfr_results.json
```

### 4. Email Takeover (`-mail` flag)
**SPF include takeover** — Expired domain in `include:` directive → send authenticated email
**MX record takeover** — Expired mail server → intercept all inbound email (password resets, 2FA)

```bash
subjack -w subdomains.txt -mail -o email_takeovers.json
```

### 5. SRV Record Takeover (`-srv` flag)
**SRV records pointing to expired domains** — SIP, XMPP, LDAP, Kerberos, IMAP, CalDAV (~28 queries/domain)

```bash
subjack -w subdomains.txt -srv -o srv_takeovers.json
```

### 6. CNAME Chain Takeover (automatic)
**Multi-level CNAME chains** (up to 10 deep) — intermediate targets may be claimable even if first hop isn't

---

## Definitive 12-Step Pipeline

### STEP 0: Preparation & Tool Validation

```bash
# Validate all tools available
for tool in subfinder subdominator assetfinder puredns dnsx httpx nuclei subjack massdns jq anew xargs curl dig openssl interactsh-client; do
    command -v "$tool" >/dev/null || echo "MISSING: $tool"
done

# Fresh resolvers (trickest)
wget -q -O resolvers.txt https://raw.githubusercontent.com/trickest/resolvers/main/resolvers.txt
massdns -r resolvers.txt -t A example.com -o S -w fast_resolvers.txt 2>/dev/null
cat fast_resolvers.txt | grep -v "127.0.0.1" | head -2000 > resolvers_fresh.txt
```

### STEP 1: Maximum Coverage Passive Enumeration

```bash
TARGET="target.com"
SUBDOMAINS="recon/subdomains.txt"
> "$SUBDOMAINS"

# 10+ sources
crt.sh: curl -s "https://crt.sh/?q=%.${TARGET}&output=json" | jq -r '.[].name_value' | sed 's/\*\.//g' | sort -u
crt.name: curl -s "https://crt.name/v1/search?apex=${TARGET}" | jq -r '.[]' | sort -u
Chaos: curl -s -H "Authorization: ${CHAOS_API_KEY}" "https://dns.projectdiscovery.io/dns/${TARGET}/subdomains" | jq -r '.[]'
subfinder: subfinder -d "${TARGET}" -silent
subdominator: subdominator -d "${TARGET}" -silent
assetfinder: assetfinder --subs-only "${TARGET}"
Wayback: curl -s "http://web.archive.org/cdx/search/cdx?url=*.${TARGET}&output=txt&fl=original&collapse=urlkey" | sed 's#https\?://##' | cut -d/ -f1 | sort -u
AnubisDB: curl -s "https://anubisdb.com/anubis/subdomains/${TARGET}" | tr -d '[]" ' | tr ',' '\n' | sort -u
VirusTotal: curl -s -H "x-apikey: ${VT_API_KEY}" "https://www.virustotal.com/api/v3/domains/${TARGET}/subdomains?limit=40" | jq -r '.data[].id'
ThreatCrowd: curl -s "https://www.threatcrowd.org/searchApi/v2/domain/report/?domain=${TARGET}" | jq -r '.subdomains[]'

# All to SUBDOMAINS, deduplicate
sort -u "$SUBDOMAINS" -o "$SUBDOMAINS"
```

### STEP 2: High-Throughput DNS Resolution

```bash
RESOLVED="recon/resolved.txt"
puredns resolve "$SUBDOMAINS" -r resolvers_fresh.txt -w recon/resolved_temp.txt --rate-limit 2000 --bin massdns
cat recon/resolved_temp.txt | sort -u > "$RESOLVED"
```

### STEP 3: Multi-Port HTTP Discovery + CDN Detection

```bash
LIVE="recon/httpx_live.txt"
cat "$RESOLVED" | httpx -silent -status-code -title -tech-detect -cdn -follow-redirects \
  -ports 80,443,8080,8443,3000,5000,8000,8008,8088,8888 \
  -threads 200 -timeout 10 -retries 2 -o "$LIVE"

cat "$LIVE" | awk '{print $1}' > recon/httpx_urls.txt
```

### STEP 4: Deep CNAME Chain Extraction

```bash
CNAME_DETAILED="recon/cname_detailed.txt"
dnsx -l "$RESOLVED" -cname -resp -silent -r resolvers_fresh.txt -threads 200 -o "$CNAME_DETAILED"

# Quick CNAME for verification
dnsx -l "$RESOLVED" -cname -resp -silent -o recon/cname_records.txt
```

### STEP 5: Automated Multi-Tool Scanning (Parallel)

```bash
# Update nuclei templates
nuclei -update-templates -silent

# Download can-i-take-over-xyz fingerprints
wget -q https://raw.githubusercontent.com/EdOverflow/can-i-take-over-xyz/master/fingerprints.json -O fingerprints_can_i_takeover.json

# Parallel scanning
nuclei -l "$RESOLVED" -t ~/nuclei-templates/takeovers/ -o recon/nuclei_takeovers.txt -silent -rate-limit 150 -retries 2 -timeout 10 &
subjack -w "$RESOLVED" -t 150 -timeout 20 -ssl -c fingerprints_can_i_takeover.json -o recon/subjack_takeovers.json -v &
subjack -w "$RESOLVED" -ns -o recon/ns_takeovers.json -ssl &
subjack -w "$RESOLVED" -ar -o recon/stale_a.json -ssl &
subjack -w "$RESOLVED" -mail -o recon/email_takeovers.json -ssl &
subjack -w "$RESOLVED" -srv -o recon/srv_takeovers.json -ssl &
subjack -w "$RESOLVED" -axfr -o recon/axfr_takeovers.json -ssl &

wait
```

### STEP 6: Service-Specific Deep Checks (via Caido)

```bash
# AWS S3 — extract bucket names, test all endpoints via Caido
cat "$CNAME_DETAILED" | grep -i "s3" | awk '{print $NF}' | \
  sed -E 's/\.s3[^.]*\.amazonaws\.com//; s/\.s3-website[^.]*\.amazonaws\.com//' | sort -u > recon/potential_buckets.txt

cat recon/potential_buckets.txt | xargs -P 20 -I {} bash -c '
bucket={}
for ep in s3.amazonaws.com s3-website-us-east-1.amazonaws.com s3-website-us-west-2.amazonaws.com s3-website-eu-west-1.amazonaws.com; do
    curl -x "http://localhost:8080" -s -I "http://$bucket.$ep" 2>/dev/null | grep -qi "x-amz-bucket-region\|x-amz-request-id" && echo "LIVE_BUCKET: $bucket ($ep)"
    curl -x "http://localhost:8080" -s "http://$bucket.$ep" 2>/dev/null | grep -qi "NoSuchBucket" && echo "S3_TAKEOVER: $bucket.$ep"
done
' > recon/s3_analysis.txt

# Azure App Service via Caido
cat "$RESOLVED" | xargs -P 30 -I {} bash -c '
sub={}
cname=$(dig +short CNAME "$sub" 2>/dev/null | head -1)
if echo "$cname" | grep -q "azurewebsites.net"; then
    resp=$(curl -x "http://localhost:8080" -s -m 10 "https://$sub" 2>/dev/null)
    if echo "$resp" | grep -q "The app you are looking for is not found"; then
        echo "AZURE_TAKEOVER: $sub -> $cname"
    fi
fi
' > recon/azure_checks.txt

# Google Cloud Storage via Caido
cat "$CNAME_DETAILED" | grep -i "storage.googleapis.com" | awk '{print $NF}' | \
  sed 's/\.storage\.googleapis\.com//' | sort -u > recon/gcs_buckets.txt

cat recon/gcs_buckets.txt | xargs -P 20 -I {} bash -c '
bucket={}
curl -x "http://localhost:8080" -s "https://storage.googleapis.com/$bucket" 2>/dev/null | grep -q "NoSuchBucket" && echo "GCS_TAKEOVER: $bucket"
' > recon/gcs_checks.txt
```

### STEP 7: Header & TLS Analysis (via Caido)

```bash
cat recon/httpx_urls.txt | xargs -P 40 -I {} bash -c '
url={}
domain=$(echo "$url" | sed -E "s|https?://||" | cut -d/ -f1)
headers=$(curl -x "http://localhost:8080" -I -s -k -L -m 10 -H "User-Agent: Mozilla/5.0" "$url" 2>/dev/null)

# Service headers
echo "$headers" | grep -qi "server:.*cloudfront" && echo "[HEADER_CLOUDFRONT] $url"
echo "$headers" | grep -qi "x-amz-cf-id" && echo "[HEADER_CLOUDFRONT_CF] $url"
echo "$headers" | grep -qi "x-github-request-id" && echo "[HEADER_GITHUB] $url"
echo "$headers" | grep -qi "x-azure-ref" && echo "[HEADER_AZURE] $url"
echo "$headers" | grep -qi "x-netlify" && echo "[HEADER_NETLIFY] $url"
echo "$headers" | grep -qi "x-vercel-id" && echo "[HEADER_VERCEL] $url"
echo "$headers" | grep -qi "x-heroku" && echo "[HEADER_HEROKU] $url"
echo "$headers" | grep -qi "x-pantheon" && echo "[HEADER_PANTHEON] $url"
echo "$headers" | grep -qi "surge.sh" && echo "[HEADER_SURGE] $url"
echo "$headers" | grep -qi "readme.io" && echo "[HEADER_README] $url"

# TLS cert analysis (direct - openssl doesn't use HTTP proxy)
if [[ "$url" == https* ]]; then
    cert_subj=$(echo | timeout 5 openssl s_client -connect "$domain:443" 2>/dev/null | openssl x509 -noout -subject 2>/dev/null)
    echo "$cert_subj" | grep -qi "cloudfront" && echo "[TLS_CLOUDFRONT] $url"
    echo "$cert_subj" | grep -qi "azure" && echo "[TLS_AZURE] $url"
    echo "$cert_subj" | grep -qi "heroku" && echo "[TLS_HEROKU] $url"
fi
' > recon/header_tls_analysis.txt
```

### STEP 8: Pattern Matching with Complete Fingerprints (via Caido)

```bash
# Build master fingerprint list from can-i-take-over-xyz
cat fingerprints_can_i_takeover.json | jq -r '.[] | select(.vulnerable==true) | "\(.service)|\(.fingerprint)|\(.cname|join(","))"' > recon/master_fingerprints.txt

# Custom HTTP response analysis via Caido
cat recon/httpx_urls.txt | xargs -P 50 -I {} bash -c '
url={}
resp=$(curl -x "http://localhost:8080" -s -k -L -H "User-Agent: Mozilla/5.0" -m 15 "$url" 2>/dev/null)
status=$(curl -x "http://localhost:8080" -s -k -o /dev/null -w "%{http_code}" "$url" 2>/dev/null)

# Match against known fingerprints
while IFS="|" read -r service fingerprint cnames; do
    if [[ -n "$fingerprint" && "$fingerprint" != "NXDOMAIN" ]]; then
        echo "$resp" | grep -qiE "$fingerprint" && echo "[$service] $url (Status: $status)"
    fi
done < recon/master_fingerprints.txt
' > recon/custom_fingerprint_matches.txt
```

### STEP 9: Intelligent Consolidation & Prioritization

```bash
# Merge all findings
cat recon/nuclei_takeovers.txt recon/subjack_takeovers.json recon/ns_takeovers.json recon/stale_a.json \
    recon/email_takeovers.json recon/srv_takeovers.json recon/axfr_takeovers.json \
    recon/s3_analysis.txt recon/azure_checks.txt recon/gcs_checks.txt \
    recon/header_tls_analysis.txt recon/custom_fingerprint_matches.txt \
    2>/dev/null | grep -v -E "Not Vulnerable|^$|^\[INFO\]" | sort -u > recon/all_raw_findings.txt

# Deduplicate (case-insensitive)
awk '!seen[tolower($0)]++' recon/all_raw_findings.txt > recon/all_findings_dedup.txt

# Prioritization: Critical > High > Medium > Info
cat recon/all_findings_dedup.txt | awk '
/S3_TAKEOVER|AZURE_TAKEOVER|GCS_TAKEOVER|NS_TAKEOVER|STALE_A|SPF_TAKEOVER|MX_TAKEOVER/ { print "🔥 " $0; next }
/TAKEOVER|CLOUDFRONT|GITHUB|HEROKU|NETLIFY|VERCEL|SURGE|PANTHEON|README/ { print "⚠️ " $0; next }
{ print "🔍 " $0 }
' > recon/prioritized_findings.txt

# Extract URLs for verification
grep -oE 'https?://[^ ]+' recon/prioritized_findings.txt | sort -u > recon/targets_to_verify.txt
```

### STEP 10: Manual Verification with Evidence (via Caido)

```bash
cat recon/targets_to_verify.txt | xargs -P 10 -I {} bash -c '
url={}
echo "=== Testing: $url ==="
resp=$(curl -x "http://localhost:8080" -s -k -L -H "User-Agent: Mozilla/5.0" -m 15 "$url" 2>/dev/null)
status=$(curl -x "http://localhost:8080" -s -k -o /dev/null -w "%{http_code}" "$url" 2>/dev/null)

echo "Status: $status"
echo "Response (first 20 lines):"
echo "$resp" | head -20
echo "Headers:"
curl -x "http://localhost:8080" -I -s -k -m 10 "$url" 2>/dev/null | head -15
echo "---"

# Save evidence
if echo "$resp" | grep -qiE "NoSuchBucket|BucketNotFound|not found|No such app|Repository not found|project not found|Deployment not found|The app you are looking for"; then
    evidence_file="evidence_$(echo -n "$url" | md5sum | cut -d" " -f1).html"
    echo "$resp" > "$evidence_file"
    echo "EVIDENCE_SAVED: $evidence_file"
fi
' > recon/manual_verification.txt
```

### STEP 11: Canary Token Proof (interactsh via Caido)

```bash
# Start interactsh via Caido proxy
interactsh-client -v -json -o canary.log -proxy "http://localhost:8080" &
CANARY_PID=$!
sleep 3

CANARY_DOMAIN=$(grep -oE "[a-z0-9]+\.interact\.sh" canary.log | head -1)
echo "Canary domain: $CANARY_DOMAIN"

# Deploy canary to all targets (multiple vectors) via Caido
cat recon/targets_to_verify.txt | xargs -P 5 -I {} bash -c '
url={}
# Path-based via Caido
curl -x "http://localhost:8080" -s -m 10 "$url/$CANARY_DOMAIN" >/dev/null 2>&1
# POST body via Caido
curl -x "http://localhost:8080" -s -m 10 -X POST "$url" -d "canary=$CANARY_DOMAIN" >/dev/null 2>&1
# Query param via Caido
curl -x "http://localhost:8080" -s -m 10 "$url/?token=$CANARY_DOMAIN" >/dev/null 2>&1
# Custom header via Caido
curl -x "http://localhost:8080" -s -m 10 -H "X-Canary: $CANARY_DOMAIN" "$url" >/dev/null 2>&1
# Referer via Caido
curl -x "http://localhost:8080" -s -m 10 -H "Referer: https://$CANARY_DOMAIN" "$url" >/dev/null 2>&1
echo "Canary deployed: $url"
'

echo "Waiting 60s for callbacks..."
sleep 60

# Check interactions
if grep -q "interaction" canary.log 2>/dev/null; then
    echo "✅ CANARY TRIGGERED - CONFIRMED TAKEOVERS:"
    grep "interaction" canary.log | jq -r '"\(.protocol) \(.client_ip) \(.full_id)"' | sort -u
    echo "canary_triggered=true" > recon/canary_status.txt
else
    echo "canary_triggered=false" > recon/canary_status.txt
fi

kill $CANARY_PID 2>/dev/null
```

### STEP 12: Professional Bug Bounty Report

```bash
{
  echo "# SUBDOMAIN TAKEOVER REPORT — $(date -u)"
  echo ""
  echo "## Executive Summary"
  echo "- **Target**: ${TARGET}"
  echo "- **Total Subdomains**: $(cat "$SUBDOMAINS" | wc -l)"
  echo "- **Resolved Subdomains**: $(cat "$RESOLVED" | wc -l)"
  echo "- **Live HTTP Services**: $(cat "$LIVE" | wc -l)"
  echo "- **CNAME Records Analyzed**: $(cat "$CNAME_DETAILED" | wc -l)"
  echo "- **Total Findings**: $(cat recon/prioritized_findings.txt | wc -l)"
  echo "- **Critical (🔥)**: $(grep -c "🔥" recon/prioritized_findings.txt)"
  echo "- **High (⚠️)**: $(grep -c "⚠️" recon/prioritized_findings.txt)"
  echo "- **Canary Triggered**: $(cat recon/canary_status.txt 2>/dev/null | cut -d= -f2)"
  echo ""
  echo "## Critical Findings 🔥"
  grep "🔥" recon/prioritized_findings.txt | sed 's/🔥 /- /'
  echo ""
  echo "## High Priority Findings ⚠️"
  grep "⚠️" recon/prioritized_findings.txt | sed 's/⚠️ /- /'
  echo ""
  echo "## All Findings 🔍"
  grep "🔍" recon/prioritized_findings.txt | sed 's/🔍 /- /'
  echo ""
  echo "## Impact Escalation Analysis"
  echo "| Subdomain | Takeover Type | Cookie Scope | OAuth redirect_uri | CSP Allowlist | Severity |"
  echo "|-----------|---------------|--------------|-------------------|---------------|----------|"
  # For each critical finding, check chain potential via Caido
  while read finding; do
      sub=$(echo "$finding" | grep -oE 'https?://[^ ]+' | head -1 | sed -E 's|https?://||')
      if [[ -n "$sub" ]]; then
          cookie=$(curl -x "http://localhost:8080" -s -I "https://$sub" 2>/dev/null | grep -i "set-cookie" | grep -i "domain=.target.com" | head -1)
          echo "| $sub | $(echo "$finding" | cut -d] -f1 | tr -d "[") | ${cookie:+"YES" } | CHECK_MANUALLY | CHECK_MANUALLY | CRITICAL |"
      fi
  done < <(grep "🔥" recon/prioritized_findings.txt)
  echo ""
  echo "## Evidence Files"
  ls evidence_*.html 2>/dev/null | head -10 | while read f; do echo "- \`$f\`"; done
  echo ""
  echo "## Verification Methodology"
  echo "1. Passive enumeration: 10+ sources (crt.sh, Chaos, subfinder, subdominator, assetfinder, Wayback, AnubisDB, VT, ThreatCrowd)"
  echo "2. DNS resolution: puredns + massdns (2000 req/s, fresh resolvers)"
  echo "3. HTTP discovery: httpx (10 ports, CDN detection, 200 threads)"
  echo "4. CNAME extraction: dnsx (200 threads, fresh resolvers)"
  echo "5. Multi-tool scanning: nuclei + subjack (CNAME, NS, A, MX, SPF, SRV, AXFR)"
  echo "6. Service-specific deep checks: S3 (4 endpoints), Azure, GCS"
  echo "7. Header/TLS analysis: Server headers, X-* headers, cert subject"
  echo "8. Fingerprint matching: can-i-take-over-xyz (100+ services)"
  echo "9. Manual verification: curl with evidence preservation"
  echo "10. Canary tokens: interactsh (path, POST, query, header, referer)"
  echo ""
  echo "## Remediation"
  echo "1. Remove dangling CNAME records for decommissioned services"
  echo "2. Audit all subdomain DNS records quarterly"
  echo "3. Use DNS monitoring for new CNAME changes"
  echo "4. Implement cookie domain restrictions (avoid .target.com)"
  echo "5. Restrict OAuth redirect_uri to exact matches"
  echo "6. Audit CSP allowlists for external domains"
} > recon/takeover_report.md

# Quick summary for triage
{
  echo "QUICK SUMMARY — $(date -u)"
  grep "🔥" recon/prioritized_findings.txt | sed 's/🔥 /CRITICAL: /'
  echo "---"
  echo "Total: $(cat recon/prioritized_findings.txt | wc -l) | Critical: $(grep -c "🔥" recon/prioritized_findings.txt) | High: $(grep -c "⚠️" recon/prioritized_findings.txt)"
} > recon/quick_summary.txt
```

---

## Complete Fingerprint Quick Reference (for grep)

```bash
# Copy-paste these patterns for manual verification

# S3
NoSuchBucket|The specified bucket does not exist|BucketNotFound|InvalidBucketName

# Azure App Service
The app you are looking for is not found|No Such Account

# GitHub Pages
There isn.t a GitHub Pages site here

# Heroku
No such app

# Netlify
Not Found - Request ID:

# Vercel
DEPLOYMENT_NOT_FOUND

# Surge.sh
project not found

# Pantheon
404 error unknown site!

# Readme.io
The creators of this project are still working on making everything perfect

# Readthedocs
The link you have followed or the URL that you entered does not exist

# Shopify
Sorry, this shop is currently unavailable

# WordPress.com
Do you want to register .*\.wordpress\.com

# Strikingly
PAGE NOT FOUND

# Ghost
Site unavailable|Failed to resolve DNS path for this host

# Tumblr
Whatever you were looking for doesn't currently exist at this address

# Wix
Looks Like This Domain Isn't Connected To A Website Yet

# Webflow
The page you are looking for doesn't exist or has been moved

# Bitbucket
Repository not found

# Help Scout
No settings were found for this company

# Help Juice
We could not find what you're looking for

# Helprace
HTTP_STATUS=301

# Firebase
(Not vulnerable - skip)

# Fastly
Fastly error: unknown domain: (Not vulnerable)

# CloudFront
ViewerCertificateException (Not vulnerable)

# Google Cloud Storage
NoSuchBucket (Not vulnerable)

# Google Sites
The requested URL was not found on this server (Not vulnerable)

# Digital Ocean
Domain uses DO name servers with no records in DO (NXDOMAIN)

# Statuspage
(Not vulnerable - DNS verification required)

# Zendesk
Help Center Closed (Not vulnerable)

# Freshdesk
We couldn't find servicedesk (Not vulnerable)

# Generic 404/400 (verify manually)
404 Not Found|400 Bad Request
```

---

## Impact Escalation Matrix

| Finding | Chain Required | Final Severity | Payout Range |
|---------|---------------|----------------|--------------|
| Basic takeover (serve HTML) | None | Low/Medium | $200–$1K |
| + Cookie `domain=.target.com` | Steal session | **High** | $1K–$5K |
| + OAuth `redirect_uri` allowlist | Register as callback | **Critical** | $5K–$25K |
| + CSP allowlist | Bypass CSP for XSS | **Critical** | $5K–$25K |
| + S3 bucket with JS bundles | Extract API keys/secrets | **High** | $2K–$10K |
| + NS takeover | Full DNS control | **Critical** | $10K–$50K |
| + Stale A record (AWS/GCP/Azure) | Instance spin-up | **Critical** | $10K–$50K |
| + SPF include takeover | Email spoofing | **High** | $2K–$10K |
| + MX record takeover | Email interception | **Critical** | $10K–$50K |

---

## Testing Checklist (Complete)

```
[ ] Tool validation: subfinder subdominator assetfinder puredns dnsx httpx nuclei subjack massdns jq anew xargs curl dig openssl interactsh-client
[ ] Fresh resolvers: trickest + massdns filter (2000 fast, no 127.0.0.1)
[ ] Passive enum: 10 sources (crt.sh, crt.name, Chaos, subfinder, subdominator, assetfinder, Wayback, AnubisDB, VT, ThreatCrowd)
[ ] puredns resolution: rate-limit 2000, deduplicated
[ ] httpx: 10 ports, CDN detection, 200 threads, follow redirects
[ ] CNAME extraction: dnsx 200 threads, fresh resolvers
[ ] nuclei: takeover templates, rate-limit 150
[ ] subjack: CNAME + NS + A + MX/SPF + SRV + AXFR (all parallel)
[ ] Service-specific: S3 (4 endpoints), Azure, GCS
[ ] Header/TLS: Server, X-*, cert subject
[ ] Fingerprint matching: can-i-take-over-xyz (100+ services)
[ ] Consolidation: dedup, prioritize (🔥🔥⚠️🔍)
[ ] Manual verification: curl -L -m15, evidence HTML saved
[ ] Canary tokens: interactsh (path, POST, query, header, referer)
[ ] Professional report: executive summary, evidence, methodology, remediation
[ ] Chain escalation documented: cookies, OAuth, CSP, secrets
```

---

## Required Tools & Versions

```bash
# Core
go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
go install -v github.com/haccer/subjack@latest
go install -v github.com/projectdiscovery/puredns/v2/cmd/puredns@latest
go install -v github.com/projectdiscovery/dnsx/cmd/dnsx@latest
go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest
go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest
go install -v github.com/projectdiscovery/interactsh/cmd/interactsh-client@latest
go install -v github.com/tomnomnom/assetfinder@latest
go install -v github.com/tomnomnom/anew@latest
go install -v github.com/tomnomnom/gf@latest

# System packages
# massdns, jq, curl, dig, openssl, xargs, md5sum
```

---

## References

- [can-i-take-over-xyz](https://github.com/EdOverflow/can-i-take-over-xyz) — 100+ service fingerprints
- [subjack](https://github.com/haccer/subjack) — Advanced takeover vectors (NS, A, MX, SPF, SRV, AXFR)
- [HackerOne Guide to Subdomain Takeovers](https://www.hackerone.com/blog/Guide-Subdomain-Takeovers)
- [Detectify Labs: Hostile Subdomain Takeover](https://labs.detectify.com/2014/10/21/hostile-subdomain-takeover-using-herokugithubdesk-more/)
- [0xpatrik: Subdomain Takeover](https://0xpatrik.com/subdomain-takeover-ns/)