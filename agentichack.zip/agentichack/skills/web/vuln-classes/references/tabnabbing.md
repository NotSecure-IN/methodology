# Tabnabbing & Reverse Tabnabbing — Vulnerability Class Reference

> Complete detection, validation, and exploitation reference for tabnabbing and reverse tabnabbing vulnerabilities.
> CWE-1022: Use of Web Link to Untrusted Target with window.opener Access.
> All HTTP traffic via Caido proxy (`-x "http://localhost:8080"`).
> Browser validation mandatory via Playwright.

---

## Root Cause

Application fails to properly isolate browsing contexts when opening external/untrusted destinations, allowing the child context to retain a reference to the parent via `window.opener` and potentially navigate it.

```html
<!-- VULNERABLE — missing rel="noopener" -->
<a href="https://external.example" target="_blank">Open</a>

<!-- VULNERABLE — explicit opener request -->
<a href="https://external.example" target="_blank" rel="opener">Open</a>

<!-- VULNERABLE — JavaScript without noopener -->
<script>
  window.open(userControlledUrl, "_blank"); // No noopener
</script>

<!-- SECURE — proper isolation -->
<a href="https://external.example" target="_blank" rel="noopener noreferrer">Open</a>

<!-- SECURE — JavaScript with proper isolation -->
<script>
  window.open(externalUrl, "_blank", "noopener,noreferrer");
</script>
```

---

## Variants

| Variant | Description | Detection |
|---------|-------------|-----------|
| **V1: Reverse Tabnabbing (HTML)** | `<a target="_blank">` without `rel="noopener"` | DOM inspection + Playwright validation |
| **V2: Reverse Tabnabbing (JS)** | `window.open(url, "_blank")` without `noopener` | Static analysis + dynamic validation |
| **V3: Explicit Opener Request** | `rel="opener"` explicitly requesting opener access | Attribute inspection |
| **V4: User-Controlled Destination** | Attacker controls `href`/`url` parameter | Input-to-sink tracing |
| **V5: Traditional Tabnabbing** | Background tab changes content after delay | Visibility API monitoring |
| **V6: Named Browsing Context** | Reused window name allows cross-tab communication | `window.open(url, "name")` inspection |

---

## Testing Checklist (via Caido + Playwright)

### Phase 1: Static Discovery (via Caido)

```bash
# 1. Crawl application for external links
curl -x "http://localhost:8080" -s "https://target.com/" | \
  grep -oE '<a[^>]*target=["\']_blank' | head -20

# 2. Find window.open calls in JS
curl -x "http://localhost:8080" -s "https://target.com/main.js" | \
  grep -n "window\.open"

# 3. Extract all links with target attributes
curl -x "http://localhost:8080" -s "https://target.com/" | \
  grep -oE '<a[^>]*target=["\']_blank[^>]*href=["\'][^"\']*'
```

### Phase 2: DOM Inspection (Playwright)

```javascript
// tabnabbing-discovery.js
const { chromium } = require('playwright');

async function discoverLinks() {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();

  await page.goto('https://target.com/');

  // Extract all links with target attributes
  const links = await page.evaluate(() => {
    const anchors = [...document.querySelectorAll('a[target], area[target], form[target]')];
    return anchors.map(a => ({
      href: a.href,
      target: a.target,
      rel: a.rel,
      text: a.innerText?.substring(0, 100),
      tagName: a.tagName
    }));
  });

  console.log('Found links:', links.length);
  links.forEach(l => console.log(JSON.stringify(l)));

  await browser.close();
  return links;
}

discoverLinks();
```

### Phase 3: Security Attribute Analysis

```bash
# Check for missing noopener/noreferrer
curl -x "http://localhost:8080" -s "https://target.com/" | \
  grep -oE '<a[^>]*target=["\']_blank[^>]*>' | \
  grep -v 'rel="noopener' | \
  grep -v 'rel="noreferrer'
```

### Phase 4: Dynamic Validation (Playwright)

```javascript
// tabnabbing-validation.js
const { chromium, firefox, webkit } = require('playwright');

const TEST_ORIGIN = 'https://target.com/';
const ATTACKER_DEST = 'https://attacker.example/tabnabbing-child.html';

async function testBrowser(browserType, name) {
  const browser = await browserType.launch({ headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();

  console.log(`\n=== ${name} ===`);

  // Navigate to page with vulnerable link
  await page.goto(TEST_ORIGIN);

  // Find and click vulnerable link
  const vulnerableLink = await page.$('a[target="_blank"]:not([rel*="noopener"])');
  
  if (!vulnerableLink) {
    console.log('No vulnerable links found');
    await browser.close();
    return { vulnerable: false };
  }

  // Set up popup handler
  const popupPromise = page.waitForEvent('popup');
  await vulnerableLink.click();
  const popup = await popupPromise;

  // Check opener relationship in popup
  const openerCheck = await popup.evaluate(() => ({
    openerNull: window.opener === null,
    openerOrigin: window.opener ? window.opener.location.origin : null,
    canNavigate: false
  }));

  console.log('Opener check:', openerCheck);

  // Test navigation capability (only with controlled destination)
  if (openerCheck.openerNull === false) {
    try {
      await popup.evaluate(() => {
        window.opener.location.href = 'https://test-owned.example/tabnabbing-marker';
      });
      console.log('NAVIGATION SUCCESSFUL - Reverse tabnabbing confirmed!');
      return { vulnerable: true, navigation: true };
    } catch (e) {
      console.log('Navigation blocked:', e.message);
      return { vulnerable: true, navigation: false };
    }
  }

  await browser.close();
  return { vulnerable: false };
}

(async () => {
  await testBrowser(chromium, 'Chromium');
  await testBrowser(firefox, 'Firefox');
  await testBrowser(webkit, 'WebKit');
})();
```

---

## Advanced Techniques

### 1. User-Controlled Destination Testing

```javascript
// Test if attacker can inject malicious link
async function testUserControlledDestinations(page) {
  // Find user-generated content areas
  const ugcSelectors = [
    '.comment', '.post', '.bio', '.profile', 
    '.description', '.review', '.message',
    '[contenteditable]', 'textarea'
  ];

  for (const selector of ugcSelectors) {
    const elements = await page.$$(selector);
    for (const el of elements) {
      // Check if attacker can inject link with target="_blank"
      const html = await el.evaluate(e => e.innerHTML);
      if (html.includes('target="_blank') || html.includes("target='_blank'")) {
        console.log('UGC allows target="_blank":', await el.evaluate(e => e.outerHTML));
      }
    }
  }
}
```

### 2. Named Browsing Context Testing

```javascript
// Test named window reuse
async function testNamedContext(page) {
  // First open
  await page.evaluate(() => {
    window.open('https://attacker.example', 'sharedWindow');
  });

  // Second open with same name - should reuse context
  await page.evaluate(() => {
    window.open('https://legitimate.example', 'sharedWindow');
  });

  // Check if attacker can communicate with reused context
  // via postMessage or opener reference
}
```

### 3. Traditional Tabnabbing Detection

```javascript
// Monitor for delayed content changes in background tabs
async function detectTraditionalTabnabbing(page) {
  await page.evaluate(() => {
    // Monitor all tabs for content changes
    const observer = new MutationObserver(mutations => {
      for (const m of mutations) {
        if (m.type === 'childList' || m.type === 'characterData') {
          const target = m.target.closest('body');
          if (target) {
            console.log('Content changed in background tab:', document.title);
          }
        }
      }
    });
    
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true
    });

    // Monitor visibility changes
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') {
        console.log('Tab became visible:', document.title, document.location.href);
      }
    });
  });
}
```

---

## Browser Validation Matrix

| Browser | Version | Implicit noopener | Explicit rel="opener" | Tested |
|---------|---------|-------------------|----------------------|--------|
| Chrome | 130+ | ✅ | ⚠️ Allows opener | [ ] |
| Firefox | 131+ | ✅ | ⚠️ Allows opener | [ ] |
| Safari | 17+ | ✅ | ⚠️ Allows opener | [ ] |
| Edge | 130+ | ✅ | ⚠️ Allows opener | [ ] |

---

## Chain Escalation

| Finding | Chain | Severity |
|---------|-------|----------|
| Reverse tabnabbing + phishing page | Credential theft | High |
| Reverse tabnabbing + open redirect | Silent redirect | Medium |
| Reverse tabnabbing + XSS on child | Full compromise | Critical |
| Traditional tabnabbing + session | Session hijacking | Medium |
| Tabnabbing + OAuth flow | Account takeover | High |

---

## False Positive Elimination

| Observation | Why Not Vulnerable | Required Validation |
|-------------|-------------------|---------------------|
| `target="_blank"` alone | Modern browsers apply implicit noopener | Test actual opener relationship |
| `window.opener` non-null | Browser allows but navigation blocked | Test actual navigation |
| Scanner reports missing rel | Browser applies implicit noopener | Test in real browser |
| Same-origin test | Different from cross-origin | Test cross-origin |
| Legacy browser only | Not in supported range | Check supported versions |

---

## Reporting

### Title
```
Reverse Tabnabbing Through Untrusted External Link Allows Navigation of Original Application Tab
```

### Evidence Required
1. Vulnerable link/component location
2. Playwright validation output per browser
3. Opener relationship proof (`window.opener !== null`)
4. Navigation capability proof (controlled destination)
5. Attacker prerequisites (user-controlled destination, etc.)

### Severity Assessment

| Level | Criteria |
|-------|----------|
| **Critical** | Reverse tabnabbing + XSS on child + credential theft |
| **High** | Reverse tabnabbing + credential phishing + attacker-controlled destination |
| **Medium** | Reverse tabnabbing + open redirect / phishing risk |
| **Low** | Missing noopener but implicit protection works |
| **Info** | Missing explicit rel but implicit protection confirmed |

### Remediation

```html
<!-- Always use noopener noreferrer for external links -->
<a href="https://external.example" 
   target="_blank" 
   rel="noopener noreferrer">
   External Link
</a>

<!-- JavaScript -->
window.open(url, "_blank", "noopener,noreferrer");

<!-- CSP cannot replace noopener - different protection layers -->
```

---

## Quick Reference

### Key Playwright Commands

```javascript
// Check opener
window.opener === null

// Test navigation
window.opener.location.href = 'https://marker.example/'

// Monitor mutations
new MutationObserver(...).observe(document.body, { childList: true, subtree: true })

// Visibility API
document.visibilityState
document.addEventListener('visibilitychange', ...)
```

### Key curl Commands (via Caido)

```bash
# Find vulnerable links
curl -x "http://localhost:8080" -s "https://target.com/" | \
  grep -oE '<a[^>]*target=["\']_blank[^>]*>' | \
  grep -v 'rel="noopener' | grep -v 'rel="noreferrer'

# Find window.open in JS
curl -x "http://localhost:8080" -s "https://target.com/app.js" | \
  grep -n "window\.open"
```

### Caido Integration

```bash
# All tools via Caido proxy
curl -x "http://localhost:8080" ...
playwright # launch with Caido proxy context
```