---
name: web/vuln-classes
description: >
  Complete reference for 29 Web2 bug classes with root causes, detection patterns,
  bypass tables, exploit techniques, and real paid examples. Covers IDOR, auth bypass,
  XSS (postMessage), SSRF (11 IP bypass), SQLi, business logic, race conditions,
  OAuth/OIDC, file upload (10 bypass), GraphQL, LLM/AI, API misconfig, ATO (9 paths),
  SSTI, subdomain takeover, cloud misconfig, HTTP smuggling, cache poisoning,
  MFA bypass (7 patterns), SAML, error disclosure, CSS injection, LFI/RCE,
  insecure deserialization, dependency confusion, padding oracle, tabnabbing,
  prototype pollution, XXE injection.
license: MIT
compatibility: opencode>=1.5.0
metadata:
  framework: agentichack
  version: "1.0.0"
  tags: "agentichack,web,vuln-classes,web2"
  allowed-tools: "read,skill"
---

# Web2 Vulnerability Classes — 26 Classes

> **Auth-required classes (🔐):** Need at least one logged-in session loaded.
> For IDOR/BOLA/priv-esc: load TWO sessions (low-priv + high-priv) and diff.

🔐 IDOR • Broken Auth/Access Control • Mass Assignment • OAuth/OIDC • JWT
🔐 GraphQL field-level auth • LLM/AI chatbot IDOR • MFA bypass • ATO chains • SSRF behind login

> MFA workflow-skip and SAML signature-stripping probes stay **unauthenticated** — that's the attack premise.

---

## Class Index

| # | Class | Auth | Typical Severity | Chain Multiplier |
|---|-------|------|------------------|------------------|
| 1 | IDOR | 🔐 | Medium→Critical | ×3–10 |
| 2 | Broken Auth/Access Control | 🔐 | High→Critical | ×2–5 |
| 3 | XSS (Stored/DOM/postMessage) | | Medium→Critical | ×2–10 |
| 4 | SSRF | | Low→Critical | ×10–100 |
| 5 | Business Logic | | Medium→Critical | ×5–20 |
| 6 | Race Conditions | | High→Critical | ×5–20 |
| 7 | SQL Injection | | High→Critical | ×2–10 |
| 8 | OAuth/OIDC Bugs | | High→Critical | ×5–20 |
| 9 | File Upload | | High→Critical | ×5–20 |
| 10 | GraphQL-Specific | 🔐 | High→Critical | ×3–10 |
| 11 | LLM/AI Features | | Info→Critical | ×10–50 |
| 12 | API Security Misconfig | 🔐 | High→Critical | ×3–10 |
| 13 | ATO (9 Paths) | | High→Critical | — |
| 14 | SSTI | | High→Critical | ×5–20 |
| 15 | Subdomain Takeover | | Low→Critical | ×10–50 |
| 16 | Cloud/Infra Misconfig | | Medium→Critical | ×10–100 |
| 17 | HTTP Request Smuggling | | High→Critical | ×10–20 |
| 18 | Cache Poisoning/Deception | | High→Critical | ×10–50 |
| 19 | MFA/2FA Bypass (7 patterns) | | Medium→Critical | ×5–20 |
| 20 | SAML/SSO Attacks | | High→Critical | ×10–50 |
| 21 | Error Disclosure/Debug Endpoints | | Info→Critical | ×5–20 |
| 22 | CSS Injection | | Medium→High | ×3–10 |
| 23 | LFI/RCE | | High→Critical | — |
| 24 | Insecure Deserialization | | High→Critical | ×5–20 |
| 25 | Dependency Confusion | | High→Critical | ×10–50 |
| 26 | Padding Oracle & Crypto Misuse | | High→Critical | ×5–20 |
| 27 | Tabnabbing & Reverse Tabnabbing | | Info→High | ×2–10 |
| 28 | Prototype Pollution | | Medium→Critical | ×5–20 |
| 29 | XXE Injection | | High→Critical | ×10–50 |

---

## Usage

Load this skill when:
- Hunting a specific vuln class
- Studying what makes bugs pay
- Need bypass tables or exploit payloads
- Confirming a signal from the Router

Each class has: Root Cause, Variants, Testing Checklist, Bypass Tables, Chain Escalation, Real Paid Examples.